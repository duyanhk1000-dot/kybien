import assert from 'assert';
import { xianxiaQuestService, isRealmTierSatisfied } from '../services/xianxia/xianxiaQuestService.js';
import { xianxiaBestiaryService } from '../services/xianxia/xianxiaBestiaryService.js';
import { PlayerInventorySlot } from '../types/xianxia.js';

export async function runXianxiaQuestTests() {
  console.log('\n--- 📜 KIỂM THỬ HỆ THỐNG NHIỆM VỤ TU TIÊN (XIANXIA QUEST SYSTEM) ---');

  const testUser = 'tester_dao_huu_001';
  xianxiaQuestService.resetPlayerProgress(testUser);

  // 1. Kiểm tra tải dữ liệu nhiệm vụ mẫu
  const allQuests = xianxiaQuestService.getAllQuests();
  assert.ok(allQuests.length >= 13, `Phải có ít nhất 13 nhiệm vụ (có ${allQuests.length})`);
  console.log(`✅ [1/10] Tải thành công ${allQuests.length} nhiệm vụ từ quests.json.`);

  // 2. Kiểm tra phân loại đầy đủ 3 Chính Tuyến và 10 Cày Cuốc
  const mainQuests = allQuests.filter(q => q.category === 'CHINH_TUYEN');
  const sideQuests = allQuests.filter(q => q.category === 'CAY_CUOC');
  assert.strictEqual(mainQuests.length, 3, 'Phải có đúng 3 nhiệm vụ chính tuyến');
  assert.strictEqual(sideQuests.length, 10, 'Phải có đúng 10 nhiệm vụ cày cuốc');
  console.log('✅ [2/10] Phân bổ chính xác 3 nhiệm vụ Chính Tuyến và 10 nhiệm vụ Cày Cuốc.');

  // 3. Kiểm tra sự tồn tại của 10 cơ chế nhiệm vụ đặc thù
  const expectedTypes = [
    'KILL_MONSTER',
    'TALK_NPC',
    'DELIVER_ITEM',
    'GATHER_ITEM',
    'LOOT_DROP',
    'GATHER_INTEL',
    'DELIVER_MESSAGE',
    'TRACK_PERSON',
    'ANSWER_QUIZ',
    'MAKE_CHOICE',
  ];
  for (const expType of expectedTypes) {
    const found = sideQuests.some(q => q.objectives.some(o => o.type === expType));
    assert.ok(found, `Phải có nhiệm vụ chứa cơ chế ${expType}`);
  }
  console.log('✅ [3/10] Xác minh đầy đủ 10 cơ chế nhiệm vụ theo yêu cầu: Trảm yêu, Đàm đạo, Giao đồ, Tìm đồ, Săn đồ, Nghe ngóng, Đưa tin, Truy tìm người, Khảo nghiệm, Lựa chọn đạo tâm.');

  // 4. Kiểm tra sức mạnh quái vật Chính Tuyến bắt buộc người chơi phải cày cuốc
  const thoLang = xianxiaBestiaryService.getMonsterById('monster_tho_lang');
  const uMinhLang = xianxiaBestiaryService.getMonsterById('monster_u_minh_lang');
  const bossLangVuong = xianxiaBestiaryService.getMonsterById('boss_u_minh_lang_vuong');

  assert.ok(thoLang && uMinhLang && bossLangVuong, 'Các quái vật chính tuyến phải tồn tại trong bestiary');
  // So sánh chỉ số
  assert.ok(uMinhLang.attack >= 35 && uMinhLang.defense >= 15, 'U Minh Lang phải có ATK >= 35, DEF >= 15');
  assert.ok(bossLangVuong.attack >= 70 && bossLangVuong.defense >= 40 && bossLangVuong.max_health >= 900, 'Lang Vương phải là Boss cực mạnh');
  
  // Tính toán logic chặn cấp độ: Người chơi Phàm Nhân cơ bản (ATK 10, DEF 5, HP 100)
  const basePlayerAtk = 10;
  const dmgAgainstUMinh = Math.max(1, basePlayerAtk - uMinhLang.defense); // 10 - 18 <= 0 -> 1 dmg
  assert.strictEqual(dmgAgainstUMinh, 1, 'Người chơi Phàm Nhân chưa cày đồ chỉ gây 1 sát thương lên U Minh Lang');
  const dmgTakenFromUMinh = Math.max(1, uMinhLang.attack - 5); // 38 - 5 = 33 dmg
  const hitsToDie = Math.ceil(100 / dmgTakenFromUMinh); // 100 / 33 = 4 hits
  assert.ok(hitsToDie <= 4, 'Người chơi chưa cày cuốc sẽ bị U Minh Lang hạ gục chỉ sau tối đa 4 đòn đánh');
  console.log('✅ [4/10] Xác minh độ khó quái Chính Tuyến: U Minh Lang và Boss Lang Vương có chỉ số áp đảo, bắt buộc cày cuốc nâng cấp.');

  // 5. Kiểm tra điều kiện mở khóa & Chặn cấp độ (Gating)
  const initialQuests = xianxiaQuestService.getQuestsForPlayer(testUser, {
    realm: 'PHAM_NHAN',
    level: 1,
  });
  const main1 = initialQuests.find(q => q.id === 'main_01_khoi_dau_tien_duyen');
  const main2 = initialQuests.find(q => q.id === 'main_02_bong_ma_u_minh');
  const main3 = initialQuests.find(q => q.id === 'main_03_tram_diet_lang_vuong');

  assert.strictEqual(main1?.status, 'AVAILABLE', 'Chính tuyến 1 phải AVAILABLE lúc đầu');
  assert.strictEqual(main2?.status, 'LOCKED', 'Chính tuyến 2 phải LOCKED khi chưa làm Chính tuyến 1');
  assert.strictEqual(main3?.status, 'LOCKED', 'Chính tuyến 3 phải LOCKED');

  // Thử nhận Main 2 khi chưa đủ điều kiện -> Bị từ chối
  const rejectMain2 = xianxiaQuestService.acceptQuest(testUser, 'main_02_bong_ma_u_minh', {
    realm: 'PHAM_NHAN',
    level: 1,
  });
  assert.strictEqual(rejectMain2.success, false, 'Không thể nhận Main 2 khi chưa đạt Luyện Khí 1 và chưa xong Main 1');
  console.log('✅ [5/10] Hệ thống khóa cấp độ và nhiệm vụ tiền đề hoạt động chính xác.');

  // 6. Luồng hoàn thành Chính Tuyến 1 -> Mở khóa Chính Tuyến 2
  const acceptMain1 = xianxiaQuestService.acceptQuest(testUser, 'main_01_khoi_dau_tien_duyen', {
    realm: 'PHAM_NHAN',
    level: 1,
  });
  assert.strictEqual(acceptMain1.success, true);
  assert.ok(acceptMain1.narrative_lines && acceptMain1.narrative_lines.length > 0, 'Phải có lời thoại typewriter');

  // Tiêu diệt 1 Thổ Lang
  xianxiaQuestService.recordMonsterKill(testUser, 'monster_tho_lang', 1);
  const progMain1 = xianxiaQuestService.getPlayerQuestProgress(testUser, 'main_01_khoi_dau_tien_duyen');
  assert.strictEqual(progMain1?.status, 'READY_TO_TURN_IN', 'Đã hạ 1 Thổ Lang, sẵn sàng trả nhiệm vụ');

  const turninMain1 = xianxiaQuestService.turnInQuest(testUser, 'main_01_khoi_dau_tien_duyen', []);
  assert.strictEqual(turninMain1.success, true);
  assert.strictEqual(turninMain1.rewards_claimed?.exp, 100);
  assert.strictEqual(turninMain1.rewards_claimed?.title, 'Sơ Nhập Tiên Đồ');

  // Giờ người chơi tu luyện lên Luyện Khí Tầng 1, Level 2 -> Main 2 phải trở thành AVAILABLE
  const questsAfterMain1 = xianxiaQuestService.getQuestsForPlayer(testUser, {
    realm: 'LUYEN_KHI_1',
    level: 2,
  });
  const main2Available = questsAfterMain1.find(q => q.id === 'main_02_bong_ma_u_minh');
  assert.strictEqual(main2Available?.status, 'AVAILABLE', 'Main 2 đã mở khóa sau khi xong Main 1 và lên Luyện Khí 1');
  console.log('✅ [6/10] Hoàn thành Chính Tuyến 1, nhận danh hiệu và mở khóa Chính Tuyến 2 thành công.');

  // 7. Kiểm thử tương tác đàm đạo (Talk NPC), thám thính (Gather Intel), đưa tin (Deliver Msg), tìm người (Track Person)
  // 7a. Đàm đạo thế giới (side_02_dam_dao_the_gioi)
  xianxiaQuestService.acceptQuest(testUser, 'side_02_dam_dao_the_gioi', { realm: 'PHAM_NHAN', level: 1 });
  const talkRes = xianxiaQuestService.interactObjective(testUser, 'side_02_dam_dao_the_gioi', 'TALK_NPC', 'npc_tieu_dao_tu');
  assert.strictEqual(talkRes.success, true);
  assert.strictEqual(talkRes.progress?.status, 'READY_TO_TURN_IN');
  const turninTalk = xianxiaQuestService.turnInQuest(testUser, 'side_02_dam_dao_the_gioi', []);
  assert.strictEqual(turninTalk.rewards_claimed?.cultivation, 60, 'Nhận 60 Tu Vi từ đàm đạo');

  // 7b. Thám thính Suối Linh Tuyền (side_06_nghe_ngong_tin_tuc)
  xianxiaQuestService.acceptQuest(testUser, 'side_06_nghe_ngong_tin_tuc', { realm: 'PHAM_NHAN', level: 1 });
  const intelRes = xianxiaQuestService.interactObjective(testUser, 'side_06_nghe_ngong_tin_tuc', 'GATHER_INTEL', 'place_linh_tuyen_thuy_thach');
  assert.strictEqual(intelRes.success, true);
  assert.strictEqual(xianxiaQuestService.turnInQuest(testUser, 'side_06_nghe_ngong_tin_tuc', []).success, true);

  // 7c. Chuyển thư khẩn (side_07_dua_tin_khan)
  xianxiaQuestService.acceptQuest(testUser, 'side_07_dua_tin_khan', { realm: 'PHAM_NHAN', level: 1 });
  const msgRes = xianxiaQuestService.interactObjective(testUser, 'side_07_dua_tin_khan', 'DELIVER_MESSAGE', 'npc_hac_y_lu_nhan');
  assert.strictEqual(msgRes.success, true);
  assert.strictEqual(xianxiaQuestService.turnInQuest(testUser, 'side_07_dua_tin_khan', []).success, true);

  // 7d. Truy tìm tán tu (side_08_truy_tim_tan_tu)
  xianxiaQuestService.acceptQuest(testUser, 'side_08_truy_tim_tan_tu', { realm: 'PHAM_NHAN', level: 1 });
  const trackRes = xianxiaQuestService.interactObjective(testUser, 'side_08_truy_tim_tan_tu', 'TRACK_PERSON', 'place_mieu_hoang_phe');
  assert.strictEqual(trackRes.success, true);
  assert.strictEqual(xianxiaQuestService.turnInQuest(testUser, 'side_08_truy_tim_tan_tu', []).success, true);
  console.log('✅ [7/10] Các nhiệm vụ Đàm đạo NPC, Thám thính dị tượng, Chuyển mật thư, Truy tìm người mất tích hoạt động hoàn hảo.');

  // 8. Kiểm thử giao đồ (Deliver Item) có khấu trừ túi đồ
  xianxiaQuestService.acceptQuest(testUser, 'side_03_giao_dan_duoc', { realm: 'PHAM_NHAN', level: 1 });
  // Thử nộp khi không có Hồi Xuân Đan trong túi -> Thất bại
  const emptyInv: PlayerInventorySlot[] = [];
  const turninFailDeliver = xianxiaQuestService.turnInQuest(testUser, 'side_03_giao_dan_duoc', emptyInv);
  assert.strictEqual(turninFailDeliver.success, false, 'Không thể nộp nhiệm vụ giao đồ khi không đủ vật phẩm');

  // Thêm 3 Hồi Xuân Đan vào túi đồ
  const playerInv: PlayerInventorySlot[] = [{ item_id: 'item_hoi_xuan_dan', quantity: 3 }];
  // Kiểm tra cập nhật tiến độ
  xianxiaQuestService.getQuestsForPlayer(testUser, { realm: 'PHAM_NHAN', level: 1, inventory: playerInv });
  const turninSuccessDeliver = xianxiaQuestService.turnInQuest(testUser, 'side_03_giao_dan_duoc', playerInv);
  assert.strictEqual(turninSuccessDeliver.success, true);
  assert.strictEqual(playerInv[0].quantity, 1, 'Phải khấu trừ đúng 2 viên Hồi Xuân Đan (3 - 2 = 1)');
  console.log('✅ [8/10] Nhiệm vụ Giao đồ kiểm tra túi đồ nghiêm ngặt và khấu trừ số lượng chính xác.');

  // 9. Kiểm thử Trắc nghiệm (Quiz) và Quyết định Đạo Tâm (Narrative Choice)
  // 9a. Trắc nghiệm khảo nghiệm (side_09_van_dap_tien_mon)
  xianxiaQuestService.acceptQuest(testUser, 'side_09_van_dap_tien_mon', { realm: 'PHAM_NHAN', level: 1 });
  // Trả lời sai (Index 0: Hồi Xuân Đan)
  const wrongQuiz = xianxiaQuestService.submitQuiz(testUser, 'side_09_van_dap_tien_mon', 'obj_side_09_quiz', 0);
  assert.strictEqual(wrongQuiz.success, false, 'Đáp án sai phải bị từ chối');
  // Trả lời đúng (Index 1: Trúc Cơ Đan)
  const rightQuiz = xianxiaQuestService.submitQuiz(testUser, 'side_09_van_dap_tien_mon', 'obj_side_09_quiz', 1);
  assert.strictEqual(rightQuiz.success, true, 'Đáp án đúng phải được chấp nhận');
  assert.strictEqual(xianxiaQuestService.turnInQuest(testUser, 'side_09_van_dap_tien_mon', []).success, true);

  // 9b. Quyết định Đạo Tâm (side_10_lua_chon_dao_tam)
  const userCompassion = 'tester_compassion';
  xianxiaQuestService.resetPlayerProgress(userCompassion);
  xianxiaQuestService.acceptQuest(userCompassion, 'side_10_lua_chon_dao_tam', { realm: 'PHAM_NHAN', level: 1 });
  // Chọn A (Từ bi tha thứ)
  const choiceResA = xianxiaQuestService.submitChoice(
    userCompassion,
    'side_10_lua_chon_dao_tam',
    'obj_side_10_choice',
    'choice_compassion'
  );
  assert.strictEqual(choiceResA.success, true);
  const turninChoiceA = xianxiaQuestService.turnInQuest(userCompassion, 'side_10_lua_chon_dao_tam', []);
  assert.strictEqual(turninChoiceA.success, true);
  assert.strictEqual(turninChoiceA.rewards_claimed?.karma, 25, 'Lựa chọn từ bi tăng 25 điểm Công Đức (Thiện Tâm)');

  // Thử nghiệm nhánh B (Nghiêm trị) với người chơi khác
  const userStrict = 'tester_strict';
  xianxiaQuestService.resetPlayerProgress(userStrict);
  xianxiaQuestService.acceptQuest(userStrict, 'side_10_lua_chon_dao_tam', { realm: 'PHAM_NHAN', level: 1 });
  const choiceResB = xianxiaQuestService.submitChoice(
    userStrict,
    'side_10_lua_chon_dao_tam',
    'obj_side_10_choice',
    'choice_strict_law'
  );
  assert.strictEqual(choiceResB.success, true);
  const turninChoiceB = xianxiaQuestService.turnInQuest(userStrict, 'side_10_lua_chon_dao_tam', []);
  assert.strictEqual(turninChoiceB.rewards_claimed?.silver, 70, 'Lựa chọn nghiêm minh nhận 30 + 40 = 70 Bạc');
  console.log('✅ [9/10] Khảo nghiệm trắc nghiệm và Lựa chọn Đạo Tâm rẽ nhánh đa dạng đạt chuẩn 100%.');

  // 10. Hoàn thành toàn bộ chuỗi Chính Tuyến tới Boss Lang Vương
  // User tester_dao_huu_001 nhận Main 2
  xianxiaQuestService.acceptQuest(testUser, 'main_02_bong_ma_u_minh', { realm: 'LUYEN_KHI_1', level: 2 });
  xianxiaQuestService.recordMonsterKill(testUser, 'monster_u_minh_lang', 1);
  const turninMain2 = xianxiaQuestService.turnInQuest(testUser, 'main_02_bong_ma_u_minh', []);
  assert.strictEqual(turninMain2.success, true);
  assert.strictEqual(turninMain2.rewards_claimed?.title, 'Trảm Lang Hiệp Giả');

  // Tiến vào Main 3 (Yêu cầu Luyện Khí Tầng 3, Level 4)
  const questsAfterMain2 = xianxiaQuestService.getQuestsForPlayer(testUser, {
    realm: 'LUYEN_KHI_3',
    level: 4,
  });
  const main3Available = questsAfterMain2.find(q => q.id === 'main_03_tram_diet_lang_vuong');
  assert.strictEqual(main3Available?.status, 'AVAILABLE');

  xianxiaQuestService.acceptQuest(testUser, 'main_03_tram_diet_lang_vuong', { realm: 'LUYEN_KHI_3', level: 4 });
  xianxiaQuestService.recordMonsterKill(testUser, 'boss_u_minh_lang_vuong', 1);
  const turninMain3 = xianxiaQuestService.turnInQuest(testUser, 'main_03_tram_diet_lang_vuong', []);
  assert.strictEqual(turninMain3.success, true);
  assert.strictEqual(turninMain3.rewards_claimed?.items?.[0].item_id, 'item_truc_co_dan');
  assert.strictEqual(turninMain3.rewards_claimed?.title, 'Trảm Yêu Đại Tông Sư');
  console.log('✅ [10/10] Chuỗi Chính Tuyến đỉnh phong hạ gục Boss Lang Vương và nhận Trúc Cơ Đan hoàn tất mỹ mãn!');

  console.log('🎉 TOÀN BỘ 10 MỤC KIỂM THỬ HỆ THỐNG NHIỆM VỤ ĐÃ ĐẠT 100%!\n');
}
