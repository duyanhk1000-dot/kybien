import fs from 'fs';
import path from 'path';
import {
  Quest,
  PlayerQuestProgress,
  QuestStatus,
  RealmTier,
  PlayerInventorySlot,
  QuestActionResponse,
  QuestReward,
} from '../../types/xianxia.js';

const REALM_ORDER: RealmTier[] = [
  'PHAM_NHAN',
  'LUYEN_KHI_1',
  'LUYEN_KHI_2',
  'LUYEN_KHI_3',
  'LUYEN_KHI_4',
  'LUYEN_KHI_5',
  'LUYEN_KHI_6',
  'LUYEN_KHI_7',
  'LUYEN_KHI_8',
  'LUYEN_KHI_9',
  'TRUC_CO_SO_KY',
];

export function isRealmTierSatisfied(current: RealmTier, required?: RealmTier): boolean {
  if (!required) return true;
  const currentIndex = REALM_ORDER.indexOf(current);
  const requiredIndex = REALM_ORDER.indexOf(required);
  return currentIndex >= requiredIndex;
}

export class XianxiaQuestService {
  private quests: Map<string, Quest> = new Map();
  // Lưu trữ tiến độ nhiệm vụ của từng người chơi: Map<userId, Map<questId, PlayerQuestProgress>>
  private playerProgress: Map<string, Map<string, PlayerQuestProgress>> = new Map();
  // Lưu trữ lựa chọn narrative/moral của người chơi
  private playerChoices: Map<string, Map<string, { choiceId: string; consequence: string; karma_delta?: number; silver_delta?: number; cultivation_delta?: number }>> = new Map();

  constructor() {
    this.loadData();
  }

  public loadData(): void {
    const questCandidates = [
      path.resolve(__dirname, '../../data/xianxia/quests.json'),
      path.resolve(__dirname, '../../../src/data/xianxia/quests.json'),
      path.resolve(process.cwd(), 'src/data/xianxia/quests.json'),
      path.resolve(process.cwd(), 'dist/data/xianxia/quests.json'),
      path.resolve(process.cwd(), 'backend/src/data/xianxia/quests.json'),
    ];

    const questPath = questCandidates.find(p => fs.existsSync(p));
    if (questPath) {
      try {
        const raw = JSON.parse(fs.readFileSync(questPath, 'utf-8')) as { quests: Quest[] };
        this.quests.clear();
        for (const q of raw.quests) {
          this.quests.set(q.id, q);
        }
      } catch (err) {
        console.error('[XianxiaQuestService] Lỗi khi đọc quests.json:', err);
      }
    } else {
      console.warn('[XianxiaQuestService] Cảnh báo: Không tìm thấy quests.json');
    }
  }

  public getAllQuests(): Quest[] {
    return Array.from(this.quests.values());
  }

  public getQuestById(id: string): Quest | null {
    return this.quests.get(id) || null;
  }

  private getUserMap(userId: string): Map<string, PlayerQuestProgress> {
    if (!this.playerProgress.has(userId)) {
      this.playerProgress.set(userId, new Map());
    }
    return this.playerProgress.get(userId)!;
  }

  public getPlayerQuestProgress(userId: string, questId: string): PlayerQuestProgress | null {
    return this.getUserMap(userId).get(questId) || null;
  }

  /**
   * Tính toán danh sách nhiệm vụ và trạng thái hiển thị cho người chơi
   */
  public getQuestsForPlayer(
    userId: string,
    playerContext: { realm: RealmTier; level: number; inventory?: PlayerInventorySlot[] }
  ): (Quest & { status: QuestStatus; current_objectives: { [id: string]: number } })[] {
    const userMap = this.getUserMap(userId);
    const results: (Quest & { status: QuestStatus; current_objectives: { [id: string]: number } })[] = [];

    for (const quest of this.quests.values()) {
      const existing = userMap.get(quest.id);
      let status: QuestStatus = 'AVAILABLE';
      let objectivesProgress: { [id: string]: number } = {};

      if (existing) {
        status = existing.status;
        objectivesProgress = { ...existing.objectives_progress };

        // Nếu đang IN_PROGRESS và có DELIVER_ITEM hoặc GATHER_ITEM, kiểm tra cập nhật số lượng thực tế từ túi đồ
        if (status === 'IN_PROGRESS' && playerContext.inventory) {
          let allMet = true;
          for (const obj of quest.objectives) {
            if (obj.type === 'DELIVER_ITEM' || obj.type === 'GATHER_ITEM') {
              const invItem = playerContext.inventory.find(i => i.item_id === obj.target_id);
              const count = invItem ? invItem.quantity : 0;
              objectivesProgress[obj.id] = Math.min(count, obj.required_count);
            }
            if ((objectivesProgress[obj.id] || 0) < obj.required_count) {
              allMet = false;
            }
          }
          if (allMet) {
            status = 'READY_TO_TURN_IN';
            existing.status = 'READY_TO_TURN_IN';
          }
        }
      } else {
        // Kiểm tra điều kiện mở khóa nhiệm vụ
        const realmMet = isRealmTierSatisfied(playerContext.realm, quest.requirements.min_realm);
        const levelMet = !quest.requirements.min_level || playerContext.level >= quest.requirements.min_level;
        let prereqMet = true;
        if (quest.requirements.prerequisite_quest_id) {
          const prereqProg = userMap.get(quest.requirements.prerequisite_quest_id);
          prereqMet = !!prereqProg && prereqProg.status === 'COMPLETED';
        }

        if (!realmMet || !levelMet || !prereqMet) {
          status = 'LOCKED';
        } else {
          status = 'AVAILABLE';
        }
      }

      results.push({
        ...quest,
        status,
        current_objectives: objectivesProgress,
      });
    }

    return results;
  }

  /**
   * Tiếp nhận nhiệm vụ
   */
  public acceptQuest(
    userId: string,
    questId: string,
    playerContext: { realm: RealmTier; level: number; inventory?: PlayerInventorySlot[] }
  ): QuestActionResponse {
    const quest = this.getQuestById(questId);
    if (!quest) {
      return { success: false, message: `Không tìm thấy nhiệm vụ ID ${questId}` };
    }

    const userMap = this.getUserMap(userId);
    const existing = userMap.get(questId);
    if (existing && existing.status !== 'LOCKED' && existing.status !== 'AVAILABLE') {
      return {
        success: false,
        message: `Nhiệm vụ "${quest.title}" đang được thực hiện hoặc đã hoàn thành.`,
      };
    }

    // Kiểm tra điều kiện
    if (!isRealmTierSatisfied(playerContext.realm, quest.requirements.min_realm)) {
      return {
        success: false,
        message: `Cảnh giới chưa đủ! Yêu cầu tối thiểu ${quest.requirements.min_realm}`,
      };
    }
    if (quest.requirements.min_level && playerContext.level < quest.requirements.min_level) {
      return {
        success: false,
        message: `Cấp độ chưa đủ! Yêu cầu cấp ${quest.requirements.min_level}`,
      };
    }
    if (quest.requirements.prerequisite_quest_id) {
      const prereq = userMap.get(quest.requirements.prerequisite_quest_id);
      if (!prereq || prereq.status !== 'COMPLETED') {
        const prereqQuest = this.getQuestById(quest.requirements.prerequisite_quest_id);
        return {
          success: false,
          message: `Cần hoàn thành nhiệm vụ tiền đề: "${prereqQuest ? prereqQuest.title : quest.requirements.prerequisite_quest_id}"`,
        };
      }
    }

    // Khởi tạo tiến độ ban đầu
    const objectivesProgress: { [id: string]: number } = {};
    let allMet = true;

    for (const obj of quest.objectives) {
      objectivesProgress[obj.id] = 0;
      // Nếu là DELIVER_ITEM hoặc GATHER_ITEM, kiểm tra vật phẩm có sẵn trong túi đồ
      if ((obj.type === 'DELIVER_ITEM' || obj.type === 'GATHER_ITEM') && playerContext.inventory) {
        const item = playerContext.inventory.find(i => i.item_id === obj.target_id);
        const count = item ? item.quantity : 0;
        objectivesProgress[obj.id] = Math.min(count, obj.required_count);
      }
      if (objectivesProgress[obj.id] < obj.required_count) {
        allMet = false;
      }
    }

    const initialStatus: QuestStatus = allMet ? 'READY_TO_TURN_IN' : 'IN_PROGRESS';

    const newProgress: PlayerQuestProgress = {
      quest_id: questId,
      status: initialStatus,
      objectives_progress: objectivesProgress,
      accepted_at: Date.now(),
    };

    userMap.set(questId, newProgress);

    return {
      success: true,
      message: `Đã tiếp nhận nhiệm vụ: ${quest.title}`,
      quest,
      progress: newProgress,
      narrative_lines: quest.dialogue_intro,
    };
  }

  /**
   * Tương tác hoàn thành mục tiêu nhiệm vụ (Nói chuyện, nghe tin tức, tìm người, đưa tin)
   */
  public interactObjective(
    userId: string,
    questId: string,
    actionType: 'TALK_NPC' | 'GATHER_INTEL' | 'TRACK_PERSON' | 'DELIVER_MESSAGE',
    targetId: string
  ): QuestActionResponse {
    const quest = this.getQuestById(questId);
    if (!quest) return { success: false, message: 'Nhiệm vụ không tồn tại.' };

    const userMap = this.getUserMap(userId);
    const progress = userMap.get(questId);
    if (!progress || progress.status !== 'IN_PROGRESS') {
      return { success: false, message: 'Nhiệm vụ chưa được tiếp nhận hoặc đã hoàn tất.' };
    }

    let updated = false;
    let customNarrative: string[] = [];

    for (const obj of quest.objectives) {
      if (obj.type === actionType && (!obj.target_id || obj.target_id === targetId)) {
        progress.objectives_progress[obj.id] = obj.required_count;
        updated = true;

        if (actionType === 'TALK_NPC') {
          customNarrative = [
            `Ngươi tiến lại gần ${obj.target_name || 'NPC'}, lắng nghe lời chỉ dạy tâm huyết.`,
            `Từng câu chữ khai sáng tâm trí, linh đài thanh tịnh!`,
          ];
        } else if (actionType === 'GATHER_INTEL') {
          customNarrative = [
            `Ngươi chăm chú lắng nghe dị biến tại ${obj.target_name || 'khu vực'}.`,
            `Ghi nhận thành công manh mối huyền bí của Cổ Động!`,
          ];
        } else if (actionType === 'TRACK_PERSON') {
          customNarrative = [
            `Lần theo dấu vết máu và tàn tích, ngươi phát hiện thiếu niên Tán Tu đang ẩn nấp an toàn!`,
            `Đã hộ tống nạn nhân thoát khỏi vòng vây của yêu thú hung hãn.`,
          ];
        } else if (actionType === 'DELIVER_MESSAGE') {
          customNarrative = [
            `Ngươi trao tận tay phong mật thư cho ${obj.target_name || 'người nhận'}.`,
            `Người nhận gật đầu tán thưởng sự nhanh nhẹn và dũng cảm của ngươi!`,
          ];
        }
      }
    }

    if (!updated) {
      return { success: false, message: 'Không tìm thấy mục tiêu tương tác phù hợp.' };
    }

    // Kiểm tra xem tất cả mục tiêu đã hoàn tất chưa
    const allDone = quest.objectives.every(
      obj => (progress.objectives_progress[obj.id] || 0) >= obj.required_count
    );
    if (allDone) {
      progress.status = 'READY_TO_TURN_IN';
    }

    return {
      success: true,
      message: 'Hoàn thành mục tiêu!',
      quest,
      progress,
      narrative_lines: customNarrative.length > 0 ? customNarrative : quest.dialogue_in_progress,
    };
  }

  /**
   * Trả lời câu hỏi khảo nghiệm (Quiz)
   */
  public submitQuiz(
    userId: string,
    questId: string,
    objectiveId: string,
    selectedIndex: number
  ): QuestActionResponse {
    const quest = this.getQuestById(questId);
    if (!quest) return { success: false, message: 'Nhiệm vụ không tồn tại.' };

    const userMap = this.getUserMap(userId);
    const progress = userMap.get(questId);
    if (!progress || progress.status !== 'IN_PROGRESS') {
      return { success: false, message: 'Nhiệm vụ chưa được tiếp nhận hoặc đã hoàn tất.' };
    }

    const obj = quest.objectives.find(o => o.id === objectiveId && o.type === 'ANSWER_QUIZ');
    if (!obj) {
      return { success: false, message: 'Không tìm thấy mục tiêu khảo nghiệm trắc nghiệm.' };
    }

    if (selectedIndex !== obj.quiz_correct_index) {
      return {
        success: false,
        message: 'Đáp án chưa chính xác! Lão Dược Sư lắc đầu: "Hãy suy nghĩ kỹ lại về dược điển tu chân."',
        narrative_lines: [
          'Trần Dược Sư thở dài: "Kiến thức đan đạo sai một ly đi một dặm, ăn nhầm độc dược sẽ nổ nát đan điền!"',
          'Hãy đọc kỹ lại câu hỏi và thử lại.',
        ],
      };
    }

    // Trả lời đúng
    progress.objectives_progress[obj.id] = 1;
    progress.quiz_completed = true;

    const allDone = quest.objectives.every(
      o => (progress.objectives_progress[o.id] || 0) >= o.required_count
    );
    if (allDone) {
      progress.status = 'READY_TO_TURN_IN';
    }

    return {
      success: true,
      message: 'Đáp án hoàn toàn chính xác!',
      quest,
      progress,
      narrative_lines: [
        'Trần Dược Sư mỉm cười vuốt râu: "Xuất sắc! Đúng là Trúc Cơ Đan!"',
        'Ngươi đã vượt qua bài khảo nghiệm dược lý một cách thuyết phục.',
      ],
    };
  }

  /**
   * Đưa ra lựa chọn Narrative/Moral Choice
   */
  public submitChoice(
    userId: string,
    questId: string,
    objectiveId: string,
    choiceOptionId: string
  ): QuestActionResponse {
    const quest = this.getQuestById(questId);
    if (!quest) return { success: false, message: 'Nhiệm vụ không tồn tại.' };

    const userMap = this.getUserMap(userId);
    const progress = userMap.get(questId);
    if (!progress || progress.status !== 'IN_PROGRESS') {
      return { success: false, message: 'Nhiệm vụ chưa được tiếp nhận hoặc đã hoàn tất.' };
    }

    const obj = quest.objectives.find(o => o.id === objectiveId && o.type === 'MAKE_CHOICE');
    if (!obj || !obj.choice_options) {
      return { success: false, message: 'Không tìm thấy mục tiêu lựa chọn.' };
    }

    const option = obj.choice_options.find(c => c.id === choiceOptionId);
    if (!option) {
      return { success: false, message: 'Lựa chọn không hợp lệ.' };
    }

    // Ghi nhận lựa chọn
    progress.objectives_progress[obj.id] = 1;
    progress.choice_selected = choiceOptionId;

    if (!this.playerChoices.has(userId)) {
      this.playerChoices.set(userId, new Map());
    }
    this.playerChoices.get(userId)!.set(questId, {
      choiceId: option.id,
      consequence: option.consequence,
      karma_delta: option.karma_delta,
      silver_delta: option.silver_delta,
      cultivation_delta: option.cultivation_delta,
    });

    const allDone = quest.objectives.every(
      o => (progress.objectives_progress[o.id] || 0) >= o.required_count
    );
    if (allDone) {
      progress.status = 'READY_TO_TURN_IN';
    }

    return {
      success: true,
      message: 'Đã đưa ra quyết định Đạo Tâm!',
      quest,
      progress,
      narrative_lines: [
        `Quyết định của đạo hữu: "${option.text}"`,
        option.consequence,
      ],
    };
  }

  /**
   * Ghi nhận tiêu diệt quái vật (trigger từ trận đánh)
   */
  public recordMonsterKill(userId: string, monsterId: string, count: number = 1): { updatedQuests: string[] } {
    const userMap = this.getUserMap(userId);
    const updatedQuests: string[] = [];

    for (const [questId, prog] of userMap.entries()) {
      if (prog.status !== 'IN_PROGRESS') continue;
      const quest = this.getQuestById(questId);
      if (!quest) continue;

      let changed = false;
      for (const obj of quest.objectives) {
        if (obj.type === 'KILL_MONSTER' && obj.target_id === monsterId) {
          const current = prog.objectives_progress[obj.id] || 0;
          prog.objectives_progress[obj.id] = Math.min(current + count, obj.required_count);
          changed = true;
        }
      }

      if (changed) {
        updatedQuests.push(questId);
        const allDone = quest.objectives.every(
          o => (prog.objectives_progress[o.id] || 0) >= o.required_count
        );
        if (allDone) {
          prog.status = 'READY_TO_TURN_IN';
        }
      }
    }

    return { updatedQuests };
  }

  /**
   * Ghi nhận nhặt được vật phẩm rơi (Loot Drop)
   */
  public recordLootAcquired(userId: string, itemId: string, quantity: number = 1): { updatedQuests: string[] } {
    const userMap = this.getUserMap(userId);
    const updatedQuests: string[] = [];

    for (const [questId, prog] of userMap.entries()) {
      if (prog.status !== 'IN_PROGRESS') continue;
      const quest = this.getQuestById(questId);
      if (!quest) continue;

      let changed = false;
      for (const obj of quest.objectives) {
        if ((obj.type === 'LOOT_DROP' || obj.type === 'GATHER_ITEM') && obj.target_id === itemId) {
          const current = prog.objectives_progress[obj.id] || 0;
          prog.objectives_progress[obj.id] = Math.min(current + quantity, obj.required_count);
          changed = true;
        }
      }

      if (changed) {
        updatedQuests.push(questId);
        const allDone = quest.objectives.every(
          o => (prog.objectives_progress[o.id] || 0) >= o.required_count
        );
        if (allDone) {
          prog.status = 'READY_TO_TURN_IN';
        }
      }
    }

    return { updatedQuests };
  }

  /**
   * Hoàn thành và nộp nhiệm vụ (Claim Rewards)
   */
  public turnInQuest(
    userId: string,
    questId: string,
    playerInventory: PlayerInventorySlot[]
  ): QuestActionResponse {
    const quest = this.getQuestById(questId);
    if (!quest) return { success: false, message: 'Nhiệm vụ không tồn tại.' };

    const userMap = this.getUserMap(userId);
    const progress = userMap.get(questId);
    if (!progress) {
      return { success: false, message: 'Chưa từng nhận nhiệm vụ này.' };
    }
    if (progress.status === 'COMPLETED') {
      return { success: false, message: 'Nhiệm vụ đã hoàn tất và nhận thưởng từ trước.' };
    }

    // Kiểm tra các mục tiêu
    for (const obj of quest.objectives) {
      // Nếu là DELIVER_ITEM, kiểm tra túi đồ thực tế
      if (obj.type === 'DELIVER_ITEM') {
        const item = playerInventory.find(i => i.item_id === obj.target_id);
        const currentCount = item ? item.quantity : 0;
        if (currentCount < obj.required_count) {
          return {
            success: false,
            message: `Chưa đủ vật phẩm để giao! Cần ${obj.required_count}x [${obj.target_name || obj.target_id}], hiện có ${currentCount}.`,
          };
        }
        progress.objectives_progress[obj.id] = obj.required_count;
      }

      // Nếu là GATHER_ITEM, kiểm tra túi đồ thực tế
      if (obj.type === 'GATHER_ITEM') {
        const item = playerInventory.find(i => i.item_id === obj.target_id);
        const currentCount = item ? item.quantity : 0;
        if (currentCount >= obj.required_count) {
          progress.objectives_progress[obj.id] = obj.required_count;
        }
      }

      const current = progress.objectives_progress[obj.id] || 0;
      if (current < obj.required_count) {
        return {
          success: false,
          message: `Mục tiêu "${obj.description}" chưa hoàn thành (${current}/${obj.required_count})!`,
        };
      }
    }

    // Khấu trừ vật phẩm nếu là DELIVER_ITEM
    for (const obj of quest.objectives) {
      if (obj.type === 'DELIVER_ITEM') {
        const item = playerInventory.find(i => i.item_id === obj.target_id);
        if (item) {
          item.quantity -= obj.required_count;
        }
      }
    }

    // Đánh dấu hoàn thành
    progress.status = 'COMPLETED';
    progress.completed_at = Date.now();

    // Tính toán phần thưởng thực tế (kèm hiệu ứng lựa chọn nếu có)
    const baseReward = { ...quest.rewards };
    const choiceData = this.playerChoices.get(userId)?.get(questId);
    if (choiceData) {
      if (choiceData.karma_delta) {
        baseReward.karma = (baseReward.karma || 0) + choiceData.karma_delta;
      }
      if (choiceData.silver_delta) {
        baseReward.silver = Math.max(0, baseReward.silver + choiceData.silver_delta);
      }
      if (choiceData.cultivation_delta) {
        baseReward.cultivation = baseReward.cultivation + choiceData.cultivation_delta;
      }
    }

    return {
      success: true,
      message: `Hoàn thành nhiệm vụ "${quest.title}"! Nhận thưởng thành công.`,
      quest,
      progress,
      rewards_claimed: baseReward,
      narrative_lines: quest.dialogue_turnin,
    };
  }

  /**
   * Reset tiến trình (cho kiểm thử hoặc làm mới)
   */
  public resetPlayerProgress(userId: string): void {
    this.playerProgress.delete(userId);
    this.playerChoices.delete(userId);
  }
}

export const xianxiaQuestService = new XianxiaQuestService();
