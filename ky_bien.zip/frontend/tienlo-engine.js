/**
 * TIÊN LỘ: VẠN GIỚI TRANH PHONG - ENGINE ĐIỀU HÀNH PHÍA TRÌNH DUYỆT (FRONTEND CLIENT)
 * Kết nối các phân hệ Backend REST API:
 * 1. World API (/api/xianxia/world)
 * 2. Bestiary API (/api/xianxia/bestiary)
 * 3. Events API (/api/xianxia/events)
 * 4. Crafting API (/api/xianxia/crafting)
 */

class TienLoEngine {
  constructor() {
    this.apiBase = window.location.origin;

    // Trạng thái nhân vật
    this.player = this.loadPlayerState();

    // Dữ liệu bộ nhớ đệm
    this.worldData = {
      zones: [],
      currentZone: null,
      currentPlace: null,
    };
    this.npcs = [];
    this.monsters = [];
    this.events = [];
    this.items = new Map();
    this.recipes = [];
    this.gatheringNodes = [];

    // Trạng thái sự kiện kỳ ngộ đang diễn ra
    this.activeEventData = null;

    // Bộ điều khiển hiệu ứng chữ hiện dần (Narrative Streamer)
    this.streamTimer = null;
    this.pendingLines = [];
    this.onStreamFinishCallback = null;

    // Quản lý nhiệm vụ tu chân
    this.quests = [];
    this.trackedQuest = null;

    // Quản lý Tiêu Cục Giang Hồ & Nhiệm Vụ Thám Hiểm
    this.agencyData = null;

    // Tab đang chọn
    this.activeMainTab = 'explore'; // 'explore' | 'map' | 'agency' | 'quests' | 'crafting' | 'gathering' | 'bestiary'
    this.bestiarySelectedZoneId = null;
  }

  // ====================================================
  // VIỆT HÓA THUẬT NGỮ TU CHÂN (XIANXIA LOCALIZATION)
  // ====================================================
  getRealmName(realm) {
    const realmMap = {
      PHAM_NHAN: 'Phàm Nhân',
      LUYEN_KHI_1: 'Luyện Khí Tầng 1',
      LUYEN_KHI_2: 'Luyện Khí Tầng 2',
      LUYEN_KHI_3: 'Luyện Khí Tầng 3',
      LUYEN_KHI_4: 'Luyện Khí Tầng 4',
      LUYEN_KHI_5: 'Luyện Khí Tầng 5',
      LUYEN_KHI_6: 'Luyện Khí Tầng 6',
      LUYEN_KHI_7: 'Luyện Khí Tầng 7',
      LUYEN_KHI_8: 'Luyện Khí Tầng 8',
      LUYEN_KHI_9: 'Luyện Khí Tầng 9',
      TRUC_CO_SO_KY: 'Trúc Cơ Sơ Kỳ',
      TRUC_CO_TRUNG_KY: 'Trúc Cơ Trung Kỳ',
      TRUC_CO_HAU_KY: 'Trúc Cơ Hậu Kỳ',
      KIM_DAN_SO_KY: 'Kim Đan Sơ Kỳ',
    };
    return realmMap[realm] || realm || 'Phàm Nhân';
  }

  getMissionKindName(kind) {
    const kindMap = {
      ESCORT: 'Áp Tiêu (Hộ Tống)',
      COURIER: 'Phi Tiêu (Hỏa Tốc)',
      HUNT: 'Thảo Phạt Dị Thú',
      GATHERING: 'Quân Nhu Tiếp Tế',
      EVENT: 'Điều Tra Kỳ Ngộ',
    };
    return kindMap[kind] || kind;
  }

  getRankName(rankKey) {
    const rankMap = {
      TAP_DICH: 'Tạp Dịch Tiêu Sinh',
      SO_CAP: 'Sơ Cấp Tiêu Sư',
      TRUNG_CAP: 'Trung Cấp Tiêu Sư',
      CAO_CAP: 'Cao Cấp Tiêu Đầu',
      TONG_TIEU_DAU: 'Tổng Tiêu Đầu Thần Uy',
    };
    return rankMap[rankKey] || rankKey;
  }

  getItemTypeName(type) {
    const typeMap = {
      PILL: 'Đan Dược',
      HERB: 'Linh Thảo',
      ORE: 'Khoáng Thạch',
      EQUIPMENT: 'Trang Bị',
      MATERIAL: 'Tài Nguyên',
      TALISMAN: 'Phù Lục',
      BAG: 'Trữ Vật Đại',
      SPECIAL: 'Kỳ Vật',
    };
    return typeMap[type] || type || 'Bảo Vật';
  }

  getMonsterTierName(tier) {
    const tierMap = {
      TIER_1_BEAST: 'Dã Thú',
      TIER_2_ELITE: '⭐ Tinh Anh',
      TIER_3_BOSS: '👑 Yêu Vương',
    };
    return tierMap[tier] || tier || 'Dị Thú';
  }

  // ====================================================
  // 1. QUẢN LÝ TRẠNG THÁI NGƯỜI CHƠI (LOCAL PERSISTENCE)
  // ====================================================
  getDefaultPlayer() {
    return {
      name: 'Vô Danh Tu Sĩ',
      title: 'Tán Tu Sơ Nhập Đạo',
      realm: 'PHAM_NHAN',
      health: 100,
      max_health: 100,
      fatigue: 100,
      max_fatigue: 100,
      cultivation: 0,
      cultivation_required: 100,
      physique: 12,       // Căn cốt / Thể chất
      comprehension: 14,  // Ngộ tính
      luck: 12,           // Khí vận / Cơ duyên
      karma: 0,           // Đạo tâm (-100 Ma đạo -> +100 Tiên đạo)
      silver: 100,        // Bạc
      zone_id: 'zone_thanh_ha_thon',
      place_id: 'place_dong_phu_tan_tu',
      inventory: [
        { item_id: 'item_hoi_xuan_dan', quantity: 2 },
        { item_id: 'item_thao_moc_linh_chi', quantity: 3 },
      ],
      logs: [
        {
          time: new Date().toLocaleTimeString(),
          text: 'Ngươi từ một phàm nhân bình dị bắt đầu bước chân vào con đường tu tiên vấn đạo!',
          type: 'info',
        },
      ],
    };
  }

  loadPlayerState() {
    try {
      const saved = localStorage.getItem('tien_lo_player_v1');
      if (saved) {
        const parsed = JSON.parse(saved);
        return Object.assign(this.getDefaultPlayer(), parsed);
      }
    } catch (e) {
      console.warn('Lỗi khi đọc trạng thái người chơi từ localStorage:', e);
    }
    return this.getDefaultPlayer();
  }

  savePlayerState() {
    try {
      localStorage.setItem('tien_lo_player_v1', JSON.stringify(this.player));
    } catch (e) {
      console.warn('Lỗi khi lưu người chơi:', e);
    }
  }

  resetPlayer() {
    if (confirm('Bạn có chắc muốn chuyển thế trùng sinh (xóa hết tiến trình và bắt đầu lại từ Phàm Nhân)?')) {
      this.player = this.getDefaultPlayer();
      this.savePlayerState();
      this.renderAll();
      this.notify('Chuyển thế trùng sinh thành công! Bắt đầu lại tiên lộ.', 'info');
    }
  }

  // ====================================================
  // 2. KHỞI TẠO & TẢI DỮ LIỆU TỪ BACKEND
  // ====================================================
  async init() {
    try {
      this.log('Đang kết nối thần thức với Thiên Đạo thế giới Tiên Lộ...', 'info');

      // Tải dữ liệu thế giới
      await this.fetchWorldData();

      // Tải danh mục vật phẩm, công thức, bãi thu thập, nhiệm vụ, tiêu cục
      await Promise.all([
        this.fetchItems(),
        this.fetchRecipes(),
        this.fetchGatheringNodes(),
        this.fetchBestiary(),
        this.fetchQuests(),
        this.fetchAgencyData(),
      ]);

      // Đồng bộ phân khu hiện tại
      this.syncCurrentLocation();

      // Vẽ giao diện
      this.renderAll();
      this.log('Kết nối thành công! Chúc Đạo Hữu sớm ngày chứng đắc đại đạo!', 'success');
    } catch (err) {
      console.error('Lỗi khi nạp dữ liệu ban đầu:', err);
      this.notify('Không thể kết nối Backend Server: ' + err.message, 'error');
    }
  }

  async fetchWorldData() {
    const res = await fetch(`${this.apiBase}/api/xianxia/world/zones`);
    const json = await res.json();
    if (json.success && Array.isArray(json.data)) {
      this.worldData.zones = json.data;
    }
  }

  async fetchItems() {
    const res = await fetch(`${this.apiBase}/api/xianxia/crafting/items`);
    const json = await res.json();
    if (json.success && Array.isArray(json.data)) {
      this.items.clear();
      for (const it of json.data) {
        this.items.set(it.id, it);
      }
    }
  }

  async fetchRecipes() {
    const res = await fetch(`${this.apiBase}/api/xianxia/crafting/recipes`);
    const json = await res.json();
    if (json.success && Array.isArray(json.data)) {
      this.recipes = json.data;
    }
  }

  async fetchGatheringNodes() {
    const res = await fetch(`${this.apiBase}/api/xianxia/crafting/nodes`);
    const json = await res.json();
    if (json.success && Array.isArray(json.data)) {
      this.gatheringNodes = json.data;
    }
  }

  async fetchBestiary() {
    const [npcRes, monRes] = await Promise.all([
      fetch(`${this.apiBase}/api/xianxia/bestiary/npcs`),
      fetch(`${this.apiBase}/api/xianxia/bestiary/monsters`),
    ]);
    const npcJson = await npcRes.json();
    const monJson = await monRes.json();
    if (npcJson.success) this.npcs = npcJson.data;
    if (monJson.success) this.monsters = monJson.data;
  }

  syncCurrentLocation() {
    let currentZone = this.worldData.zones.find(z => z.id === this.player.zone_id);
    if (!currentZone && this.worldData.zones.length > 0) {
      currentZone = this.worldData.zones[0];
      this.player.zone_id = currentZone.id;
    }
    this.worldData.currentZone = currentZone;

    const places = currentZone?.places || [];
    if (Array.isArray(places) && places.length > 0) {
      let currentPlace = places.find(p => p.id === this.player.place_id);
      if (!currentPlace) {
        currentPlace = places[0];
        this.player.place_id = currentPlace.id;
      }
      this.worldData.currentPlace = currentPlace;
    } else {
      this.worldData.currentPlace = null;
    }
  }

  // ====================================================
  // 3. DI CHUYỂN PHÂN KHU & ĐỊA ĐIỂM
  // ====================================================
  async travelToZone(targetZoneId) {
    const targetZone = this.worldData.zones.find(z => z.id === targetZoneId);
    if (!targetZone) {
      this.notify('Không tìm thấy thông tin phân khu đích!', 'error');
      return;
    }

    if (targetZoneId === this.player.zone_id) {
      const isAgencyDest = this.agencyData?.activeMission && this.agencyData.activeMission.destination_zone_id === targetZoneId;
      if (isAgencyDest) {
        this.notify(`Đạo hữu đã có mặt tại [${targetZone.name}]! Hãy mở bảng Tiêu Cục hoặc đàm đạo cùng NPC để bàn giao chuyến tiêu.`, 'success');
      } else {
        this.notify(`Đạo hữu hiện đang ở tại [${targetZone.name}], không cần di chuyển thêm!`, 'info');
      }
      return;
    }

    const currentZone = this.worldData.currentZone || this.worldData.zones.find(z => z.id === this.player.zone_id);
    const fatigueCost = targetZone.travel_fatigue_base || 5;

    if (this.player.fatigue < fatigueCost) {
      this.notify(`Thể lực không đủ (${this.player.fatigue}/${fatigueCost})! Hãy đả tọa nhập định hoặc uống đan dược trước khi khởi hành.`, 'warning');
      return;
    }

    try {
      // Xác thực điều kiện di chuyển với Backend
      const res = await fetch(`${this.apiBase}/api/xianxia/world/travel/validate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fromZoneId: this.player.zone_id,
          toZoneId: targetZoneId,
          playerRealm: this.player.realm,
          currentFatigue: this.player.fatigue,
        }),
      });
      const json = await res.json();
      if (!json.success || !json.data?.valid) {
        this.notify(json.data?.reason || json.message || 'Không thể di chuyển đến phân khu này!', 'error');
        return;
      }

      // Chuẩn bị Modal Hoạt Họa Hành Trình (Travel Journey Animation Modal)
      const modal = document.getElementById('travel-journey-modal');
      const iconEl = document.getElementById('travel-modal-icon');
      const titleEl = document.getElementById('travel-modal-title');
      const descEl = document.getElementById('travel-modal-desc');
      const progressEl = document.getElementById('travel-modal-progress');
      const statusEl = document.getElementById('travel-modal-status');

      const isEscort = this.agencyData?.activeMission && this.agencyData.activeMission.kind === 'ESCORT';
      const isCourier = this.agencyData?.activeMission && this.agencyData.activeMission.kind === 'COURIER';

      if (modal) {
        if (iconEl) iconEl.textContent = isEscort ? '🛡️' : isCourier ? '🐎' : '🧭';
        if (titleEl) titleEl.textContent = `Đang Khởi Hành Đến [${targetZone.name}]...`;
        if (descEl) {
          if (isEscort) {
            descEl.textContent = `Đoàn hộ tống đang vận chuyển [${this.agencyData.activeMission.cargo_name || 'Hàng hóa'}] từ [${currentZone?.name || 'Xuất phát'}] sang [${targetZone.name}]. Cẩn trọng yêu thú phục kích!`;
          } else if (isCourier) {
            descEl.textContent = `Phi tiêu hỏa tốc! Ngươi đang thúc ngựa phi nước đại mang mật thư sang [${targetZone.name}]...`;
          } else {
            descEl.textContent = `Ngươi vận chuyển linh lực ngự kiếm vượt ngàn dặm sơn xuyên từ [${currentZone?.name || 'Hiện tại'}] sang [${targetZone.name}]...`;
          }
        }
        if (statusEl) {
          statusEl.textContent = `Tiêu hao: ${json.data.fatigueCost || fatigueCost} Thể lực • Đang di chuyển...`;
        }
        if (progressEl) {
          progressEl.style.transition = 'none';
          progressEl.style.width = '0%';
        }
        modal.classList.add('open');

        // Bắt đầu thanh chạy tiến độ
        setTimeout(() => {
          if (progressEl) {
            progressEl.style.transition = 'width 1.2s cubic-bezier(0.16, 1, 0.3, 1)';
            progressEl.style.width = '100%';
          }
        }, 30);
      }

      // Giữ 1.25s cho trải nghiệm hoạt họa hành trình mượt mà
      await new Promise(r => setTimeout(r, 1250));

      if (modal) {
        modal.classList.remove('open');
      }

      // Cập nhật trạng thái người chơi
      const actualFatigueCost = json.data.fatigueCost || fatigueCost;
      this.player.fatigue = Math.max(0, this.player.fatigue - actualFatigueCost);
      this.player.zone_id = targetZoneId;
      this.syncCurrentLocation();
      this.savePlayerState();

      this.log(`Ngươi tiêu hao ${actualFatigueCost} thể lực, thuận lợi đặt chân đến [${targetZone.name}].`, 'info');

      // Cập nhật tiến độ nhiệm vụ tiêu cục thám hiểm (kiểm tra rủi ro cướp tiêu & hoàn tất lộ trình)
      await this.advanceAgencyMission('TRAVEL', { currentZoneId: targetZoneId });

      // Nếu đang trong chuyến áp tiêu/phi tiêu và đã đến đích
      if (this.agencyData?.activeMission && this.agencyData.activeMission.destination_zone_id === targetZoneId) {
        this.notify(`🎉 Đã áp tiêu đến nơi an toàn! Hãy bàn giao tại NPC hoặc mở bảng Tiêu Cục để nhận thưởng!`, 'success');
      } else {
        this.notify(`Đã đến [${targetZone.name}] bình an!`, 'success');
      }

      this.renderAll();
    } catch (err) {
      const modal = document.getElementById('travel-journey-modal');
      if (modal) modal.classList.remove('open');
      this.notify('Lỗi di chuyển: ' + err.message, 'error');
    }
  }

  selectPlace(placeId) {
    const place = this.worldData.currentZone?.places.find(p => p.id === placeId);
    if (!place) return;
    this.player.place_id = placeId;
    this.worldData.currentPlace = place;
    this.savePlayerState();
    this.log(`Ngươi dừng chân tại [${place.name}].`, 'info');
    this.renderAll();
  }

  // ====================================================
  // 4. THÁM HIỂM & GIẢI QUYẾT KỲ NGỘ
  // ====================================================
  async exploreCurrentZone() {
    const roamCost = this.worldData.currentZone?.fatigue_cost_roam || 5;
    if (this.player.fatigue < roamCost) {
      this.notify(`Thể lực quá thấp (${this.player.fatigue}/${roamCost}), hãy đả tọa nghỉ ngơi hoặc dùng Dưỡng Khí Đan!`, 'error');
      return;
    }

    try {
      this.player.fatigue -= roamCost;
      const res = await fetch(`${this.apiBase}/api/xianxia/events/explore`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          zoneId: this.player.zone_id,
          playerStats: this.getExplorationStats(),
        }),
      });

      const json = await res.json();
      if (!json.success) {
        this.notify(json.message || 'Thám hiểm chưa gặp duyên phận.', 'warning');
        this.renderPlayerStats();
        return;
      }

      this.activeEventData = json.data;
      this.renderActiveEventModal();
      this.savePlayerState();
      this.renderPlayerStats();

      // Đồng bộ tiến độ thám hiểm Tiêu Cục
      this.advanceAgencyMission('ROAM');
    } catch (err) {
      this.notify('Lỗi khi thám hiểm: ' + err.message, 'error');
    }
  }

  getExplorationStats() {
    return {
      realm: this.player.realm,
      health: this.player.health,
      max_health: this.player.max_health,
      fatigue: this.player.fatigue,
      max_fatigue: this.player.max_fatigue,
      physique: this.player.physique,
      comprehension: this.player.comprehension,
      luck: this.player.luck,
      karma: this.player.karma,
      silver: this.player.silver,
      inventory_items: this.player.inventory.map(s => s.item_id),
    };
  }

  async resolveActiveEvent(choiceId) {
    if (!this.activeEventData) return;
    const eventId = this.activeEventData.event.id;

    try {
      const res = await fetch(`${this.apiBase}/api/xianxia/events/resolve`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          eventId,
          choiceId,
          playerStats: this.getExplorationStats(),
        }),
      });

      const json = await res.json();
      if (!json.success) {
        this.notify(json.message || 'Lựa chọn không thể thực hiện.', 'error');
        return;
      }

      const result = json.data;
      this.applyEventEffects(result);
      await this.advanceAgencyMission('EVENT', { eventId });
      this.renderEventResult(result);
    } catch (err) {
      this.notify('Lỗi khi chọn nhánh sự kiện: ' + err.message, 'error');
    }
  }

  applyEventEffects(result) {
    const fx = result.effects;

    // EXP & Tu vi
    if (fx.cultivation_gained > 0) {
      this.addCultivation(fx.cultivation_gained);
    }

    // Tiền bạc
    this.player.silver = Math.max(0, this.player.silver + fx.silver_change);

    // Máu & Thể lực
    this.player.health = Math.min(this.player.max_health, Math.max(1, this.player.health + fx.health_change));
    this.player.fatigue = Math.min(this.player.max_fatigue, Math.max(0, this.player.fatigue + fx.fatigue_change));

    // Đạo tâm
    this.player.karma = Math.min(100, Math.max(-100, this.player.karma + fx.karma_change));

    // Vật phẩm nhận được
    for (const item of fx.items_gained) {
      this.addItemToInventory(item.item_id, item.quantity);
      this.log(`Nhận được [${item.item_name} x${item.quantity}]!`, 'success');
    }

    this.log(`[Kỳ Ngộ] ${result.narrative}`, result.success ? 'success' : 'warning');
    this.savePlayerState();
    this.renderPlayerStats();
    this.renderInventory();
  }

  // ====================================================
  // 5. THU THẬP & CHẾ TÁC TIÊN MÔN
  // ====================================================
  async gatherAtNode(nodeId) {
    try {
      const res = await fetch(`${this.apiBase}/api/xianxia/crafting/gather`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          nodeId,
          player: {
            realm: this.player.realm,
            fatigue: this.player.fatigue,
            silver: this.player.silver,
            luck: this.player.luck,
            inventory: this.player.inventory,
          },
        }),
      });

      const json = await res.json();
      if (!json.success) {
        this.notify(json.message || 'Thu thập thất bại!', 'error');
        return;
      }

      const resData = json.data;
      this.player.fatigue = Math.max(0, this.player.fatigue - resData.fatigue_spent);

      if (resData.success) {
        this.addCultivation(resData.cultivation_gained);
        for (const it of resData.items_gathered) {
          this.addItemToInventory(it.item_id, it.quantity);
          this.notifyLootAcquired(it.item_id, it.quantity);
          await this.advanceAgencyMission('GATHER', { itemId: it.item_id, quantity: it.quantity });
        }
        this.fetchQuests();
        this.notify(`Thu hoạch thành công từ [${resData.node_name}]!`, 'success');
      } else {
        this.notify(resData.narrative, 'warning');
      }

      this.log(resData.narrative, resData.success ? 'success' : 'warning');
      this.savePlayerState();
      this.renderPlayerStats();
      this.renderInventory();
      this.renderGatheringView();
    } catch (err) {
      this.notify('Lỗi thu thập: ' + err.message, 'error');
    }
  }

  async craftRecipe(recipeId) {
    try {
      const res = await fetch(`${this.apiBase}/api/xianxia/crafting/craft`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          recipeId,
          player: {
            realm: this.player.realm,
            fatigue: this.player.fatigue,
            silver: this.player.silver,
            comprehension: this.player.comprehension,
            inventory: this.player.inventory,
          },
        }),
      });

      const json = await res.json();
      if (!json.success) {
        this.notify(json.message || 'Không thể chế tác!', 'error');
        return;
      }

      const data = json.data;

      // Trừ nguyên liệu
      for (const mat of data.materials_consumed) {
        this.removeItemFromInventory(mat.item_id, mat.quantity);
      }

      // Trừ bạc và thể lực
      this.player.silver = Math.max(0, this.player.silver - data.silver_spent);
      this.player.fatigue = Math.max(0, this.player.fatigue - data.fatigue_spent);

      // Cộng tu vi
      this.addCultivation(data.cultivation_gained);

      // Nhận sản phẩm
      if (data.item_produced) {
        this.addItemToInventory(data.item_produced.item_id, data.item_produced.quantity);
      }

      this.log(data.narrative, data.success ? 'success' : 'warning');
      this.notify(data.narrative, data.success ? 'success' : 'warning');

      this.savePlayerState();
      this.renderPlayerStats();
      this.renderInventory();
      this.renderCraftingView();
    } catch (err) {
      this.notify('Lỗi chế tác: ' + err.message, 'error');
    }
  }

  // ====================================================
  // 6. SĂN BẮT YÊU THÚ & SÚC XẮC RƠI ĐỒ (BESTIARY)
  // ====================================================
  async huntMonster(monsterId) {
    const mon = this.monsters.find(m => m.id === monsterId);
    if (!mon) return;

    if (this.player.fatigue < 12) {
      this.notify('Thể lực quá thấp để săn yêu thú (cần 12 thể lực)!', 'error');
      return;
    }

    try {
      this.player.fatigue -= 12;
      const res = await fetch(`${this.apiBase}/api/xianxia/bestiary/monsters/${monsterId}/roll-loot`, {
        method: 'POST',
      });
      const json = await res.json();
      if (!json.success) {
        this.notify(json.message || 'Không thể khiêu chiến yêu thú!', 'error');
        return;
      }

      const loot = json.data;

      // Tính tổn thất chiến đấu mô phỏng
      const damageTaken = Math.max(5, Math.floor(mon.attack * 0.4));
      this.player.health = Math.max(1, this.player.health - damageTaken);

      // Nhận thưởng
      this.player.silver += loot.silver_gained;
      this.addCultivation(loot.cultivation_gained);

      for (const item of loot.dropped_items) {
        this.addItemToInventory(item.item_id, item.quantity);
        await this.notifyLootAcquired(item.item_id, item.quantity);
      }
      await this.notifyMonsterKill(monsterId);
      await this.advanceAgencyMission('HUNT', { monsterId, count: 1 });
      await this.fetchQuests();

      this.log(
        `[Trảm Yêu] Ngươi đại chiến và trảm sát [${mon.name}], nhận ${loot.exp_gained} EXP, ${loot.cultivation_gained} Tu vi, ${loot.silver_gained} Bạc (tổn thất ${damageTaken} HP).`,
        'success'
      );
      this.notify(`Trảm sát [${mon.name}] thành công! Rơi ${loot.dropped_items.length} bảo vật.`, 'success');

      this.savePlayerState();
      this.renderPlayerStats();
      this.renderInventory();
      this.renderBestiaryView();
    } catch (err) {
      this.notify('Lỗi khi săn yêu thú: ' + err.message, 'error');
    }
  }

  // ====================================================
  // 7. QUẢN LÝ TÚI ĐỒ & SỬ DỤNG VẬT PHẨM
  // ====================================================
  addItemToInventory(itemId, qty = 1) {
    const slot = this.player.inventory.find(s => s.item_id === itemId);
    if (slot) {
      slot.quantity += qty;
    } else {
      this.player.inventory.push({ item_id: itemId, quantity: qty });
    }
  }

  removeItemFromInventory(itemId, qty = 1) {
    const slotIndex = this.player.inventory.findIndex(s => s.item_id === itemId);
    if (slotIndex >= 0) {
      this.player.inventory[slotIndex].quantity -= qty;
      if (this.player.inventory[slotIndex].quantity <= 0) {
        this.player.inventory.splice(slotIndex, 1);
      }
    }
  }

  useItem(itemId) {
    const def = this.items.get(itemId);
    if (!def) return;

    if (def.type !== 'PILL') {
      this.notify('Chỉ đan dược mới có thể trực tiếp phục dụng!', 'info');
      return;
    }

    if (def.effects?.health_restore) {
      this.player.health = Math.min(this.player.max_health, this.player.health + def.effects.health_restore);
      this.log(`Phục dụng [${def.name}], hồi phục ${def.effects.health_restore} Khí Huyết.`, 'success');
    }

    if (def.effects?.fatigue_restore) {
      this.player.fatigue = Math.min(this.player.max_fatigue, this.player.fatigue + def.effects.fatigue_restore);
      this.log(`Phục dụng [${def.name}], hồi phục ${def.effects.fatigue_restore} Thể Lực.`, 'success');
    }

    if (def.effects?.cultivation_boost) {
      this.addCultivation(def.effects.cultivation_boost);
    }

    this.removeItemFromInventory(itemId, 1);
    this.savePlayerState();
    this.renderPlayerStats();
    this.renderInventory();
  }

  // ====================================================
  // 8. TIẾN HÓA CẢNH GIỚI & TU VI
  // ====================================================
  addCultivation(amount) {
    this.player.cultivation += amount;
    this.log(`Tu vi gia tăng +${amount} điểm.`, 'info');

    // Kiểm tra đột phá
    if (this.player.cultivation >= this.player.cultivation_required) {
      this.triggerBreakthrough();
    }
  }

  triggerBreakthrough() {
    const nextRealmMap = {
      PHAM_NHAN: { next: 'LUYEN_KHI_1', title: 'Luyện Khí Tầng 1', req: 180, hp: 130, fat: 110, p: 14, c: 15 },
      LUYEN_KHI_1: { next: 'LUYEN_KHI_2', title: 'Luyện Khí Tầng 2', req: 280, hp: 160, fat: 120, p: 16, c: 16 },
      LUYEN_KHI_2: { next: 'LUYEN_KHI_3', title: 'Luyện Khí Tầng 3', req: 400, hp: 200, fat: 130, p: 18, c: 18 },
      LUYEN_KHI_3: { next: 'LUYEN_KHI_4', title: 'Luyện Khí Tầng 4', req: 550, hp: 250, fat: 140, p: 20, c: 20 },
      LUYEN_KHI_4: { next: 'LUYEN_KHI_5', title: 'Luyện Khí Tầng 5', req: 750, hp: 300, fat: 150, p: 22, c: 22 },
      LUYEN_KHI_5: { next: 'LUYEN_KHI_6', title: 'Luyện Khí Tầng 6', req: 1000, hp: 360, fat: 160, p: 25, c: 24 },
      LUYEN_KHI_6: { next: 'LUYEN_KHI_7', title: 'Luyện Khí Tầng 7', req: 1300, hp: 420, fat: 170, p: 28, c: 26 },
      LUYEN_KHI_7: { next: 'LUYEN_KHI_8', title: 'Luyện Khí Tầng 8', req: 1700, hp: 500, fat: 180, p: 32, c: 28 },
      LUYEN_KHI_8: { next: 'LUYEN_KHI_9', title: 'Luyện Khí Tầng 9', req: 2200, hp: 600, fat: 200, p: 36, c: 30 },
      LUYEN_KHI_9: { next: 'TRUC_CO_SO_KY', title: 'Trúc Cơ Sơ Kỳ (Tiên Nhân)', req: 5000, hp: 1000, fat: 300, p: 50, c: 45 },
    };

    const nextInfo = nextRealmMap[this.player.realm];
    if (nextInfo) {
      this.player.cultivation -= this.player.cultivation_required;
      this.player.realm = nextInfo.next;
      this.player.title = nextInfo.title;
      this.player.cultivation_required = nextInfo.req;
      this.player.max_health = nextInfo.hp;
      this.player.health = nextInfo.hp;
      this.player.max_fatigue = nextInfo.fat;
      this.player.fatigue = nextInfo.fat;
      this.player.physique = nextInfo.p;
      this.player.comprehension = nextInfo.c;

      this.log(`🌟 [ĐỘT PHÁ THIÊN ĐẠO] Chúc mừng Đạo Hữu đột phá cảnh giới [${nextInfo.title}]!`, 'success');
      this.notify(`Đột phá đại thành! Chúc mừng đạt cảnh giới ${nextInfo.title}!`, 'success');
    }
  }

  meditateRest() {
    if (this.player.fatigue >= this.player.max_fatigue && this.player.health >= this.player.max_health) {
      this.notify('Khí huyết và thể lực đang sung mãn, không cần đả tọa!', 'info');
      return;
    }

    this.player.fatigue = Math.min(this.player.max_fatigue, this.player.fatigue + 30);
    this.player.health = Math.min(this.player.max_health, this.player.health + 20);
    this.addCultivation(10);
    this.log('Ngươi khoanh chân nhập định, hấp thu linh khí thiên địa hồi phục 30 Thể lực, 20 Khí huyết.', 'info');
    this.savePlayerState();
    this.renderPlayerStats();
  }

  // ====================================================
  // 9. RENDER GIAO DIỆN (UI BINDING)
  // ====================================================
  renderAll() {
    this.renderPlayerStats();
    this.renderZoneNavigator();
    this.renderLocationPlaces();
    this.renderMainContent();
    this.renderInventory();
    this.renderChronicleLogs();
    this.renderAgencyMissionTrackerHud();
  }

  renderPlayerStats() {
    const p = this.player;
    document.getElementById('stat-player-name').textContent = p.name;
    document.getElementById('stat-player-title').textContent = p.title;
    document.getElementById('stat-player-realm').textContent = this.getRealmName(p.realm);

    // HP Bar
    const hpPct = Math.min(100, Math.floor((p.health / p.max_health) * 100));
    document.getElementById('stat-hp-text').textContent = `${p.health} / ${p.max_health}`;
    document.getElementById('stat-hp-bar').style.width = `${hpPct}%`;

    // Fatigue Bar
    const fatPct = Math.min(100, Math.floor((p.fatigue / p.max_fatigue) * 100));
    document.getElementById('stat-fatigue-text').textContent = `${p.fatigue} / ${p.max_fatigue}`;
    document.getElementById('stat-fatigue-bar').style.width = `${fatPct}%`;

    // Cultivation Bar
    const cultPct = Math.min(100, Math.floor((p.cultivation / p.cultivation_required) * 100));
    document.getElementById('stat-cult-text').textContent = `${p.cultivation} / ${p.cultivation_required} (${cultPct}%)`;
    document.getElementById('stat-cult-bar').style.width = `${cultPct}%`;

    // Attributes
    document.getElementById('stat-physique').textContent = p.physique;
    document.getElementById('stat-comprehension').textContent = p.comprehension;
    document.getElementById('stat-luck').textContent = p.luck;
    document.getElementById('stat-silver').textContent = p.silver;

    // Karma
    const karmaText = p.karma > 20 ? `Chính Đạo (+${p.karma})` : p.karma < -20 ? `Ma Đạo (${p.karma})` : `Trung Lập (${p.karma})`;
    document.getElementById('stat-karma').textContent = karmaText;
  }

  renderZoneNavigator() {
    const container = document.getElementById('zone-nav-container');
    if (!container) return;

    const z = this.worldData.currentZone;
    if (!z) return;

    document.getElementById('current-zone-name').textContent = z.name;
    document.getElementById('current-zone-desc').textContent = z.description;
    document.getElementById('current-zone-roam-cost').textContent = `Hao tổn thể lực thám hiểm: ${z.fatigue_cost_roam}`;

    // Nút di chuyển liên phân khu
    let html = '<div class="travel-title">Lộ Trình Liên Phân Khu:</div><div class="travel-buttons">';
    for (const otherZone of this.worldData.zones) {
      if (otherZone.id === z.id) continue;
      const isConnected = z.connected_zones.includes(otherZone.id);
      html += `
        <button class="btn-travel ${isConnected ? '' : 'disabled'}" 
                onclick="window.engine.travelToZone('${otherZone.id}')">
          → ${otherZone.name} (${otherZone.travel_fatigue_base || 5} Thể lực)
        </button>
      `;
    }
    html += '</div>';
    container.innerHTML = html;
  }

  renderLocationPlaces() {
    const list = document.getElementById('location-places-list');
    if (!list) return;

    const z = this.worldData.currentZone;
    if (!z || !z.places) return;

    let html = '';
    for (const place of z.places) {
      const isSelected = place.id === this.player.place_id;
      html += `
        <div class="place-card ${isSelected ? 'active' : ''}" onclick="window.engine.selectPlace('${place.id}')">
          <div class="place-name">${isSelected ? '📍 ' : ''}${place.name}</div>
          <div class="place-desc">${place.description}</div>
          <div class="place-services">
            ${place.services.map(s => `<span class="service-tag">${s.name}</span>`).join('')}
          </div>
        </div>
      `;
    }
    list.innerHTML = html;
  }

  renderMainContent() {
    switch (this.activeMainTab) {
      case 'map':
        this.renderMapView();
        break;
      case 'explore':
        this.renderExploreView();
        break;
      case 'crafting':
        this.renderCraftingView();
        break;
      case 'gathering':
        this.renderGatheringView();
        break;
      case 'bestiary':
        this.renderBestiaryView();
        break;
      case 'agency':
        this.renderAgencyView();
        break;
      case 'quests':
        this.renderQuestBoard();
        break;
    }
  }

  renderMapView() {
    const view = document.getElementById('main-tab-view');
    if (!view) return;

    const currentZoneId = this.player.zone_id;
    const zones = this.worldData.zones || [];

    const zoneCardsHtml = zones.map(z => {
      const isCurrent = z.id === currentZoneId;
      const isConnected = this.worldData.currentZone?.connected_zones?.includes(z.id);
      const minRealmName = this.getRealmName(z.min_realm);

      // Lấy danh sách quái vật thuộc phân khu này
      const zoneMonsters = (this.monsters || []).filter(m => m.zone_id === z.id);
      // Lấy danh sách NPC thuộc phân khu này
      const zoneNpcs = (this.npcs || []).filter(n => n.zone_id === z.id);
      // Lấy bãi thu thập
      const zoneNodes = (this.gatheringNodes || []).filter(n => n.zone_id === z.id);

      let actionBtn = '';
      if (isCurrent) {
        actionBtn = `
          <button class="btn-travel-map disabled" disabled>
            📍 Đang Dừng Chân Tại Đây
          </button>
        `;
      } else if (isConnected) {
        actionBtn = `
          <button class="btn-travel-map" onclick="window.engine.travelToZone('${z.id}')">
            🧭 Di Chuyển Đến Đây (-${z.travel_fatigue_base || 5} Thể Lực)
          </button>
        `;
      } else {
        actionBtn = `
          <button class="btn-travel-map disabled" disabled>
            🔒 Không Nối Liền Trực Tiếp
          </button>
        `;
      }

      return `
        <div class="map-region-card ${isCurrent ? 'active' : ''}">
          <div class="map-card-header">
            <div>
              <div class="map-region-title">${z.name}</div>
              <div class="map-req-badge">Cảnh giới: ${minRealmName}</div>
            </div>
            ${isCurrent ? '<span class="map-current-pill">📍 ĐANG Ở ĐÂY</span>' : ''}
          </div>

          <div class="map-region-desc">
            ${z.description}
          </div>

          <!-- Yêu Thú Xuất Hiện -->
          <div class="map-info-block">
            <div class="map-info-label">🐺 Dị Thú Phân Bố (${zoneMonsters.length}):</div>
            <div class="map-entity-tags">
              ${zoneMonsters.length > 0 
                ? zoneMonsters.map(m => `
                    <span class="map-tag monster">
                      ${this.getMonsterTierName(m.tier)} ${m.name}
                    </span>
                  `).join('')
                : '<span style="color: #94a3b8; font-size: 0.75rem;">Vùng an toàn, không có dã thú</span>'
              }
            </div>
          </div>

          <!-- NPC & Điểm Thu Thập -->
          <div class="map-info-block">
            <div class="map-info-label">🧙 Cư Dân &amp; Tài Nguyên:</div>
            <div class="map-entity-tags">
              ${zoneNpcs.map(n => `<span class="map-tag npc">🧙 ${n.name}</span>`).join('')}
              ${zoneNodes.map(nd => `<span class="map-tag node">${nd.type === 'HERB_PATCH' ? '🌿' : '⛏️'} ${nd.name}</span>`).join('')}
            </div>
          </div>

          <div style="margin-top: auto; padding-top: 10px;">
            ${actionBtn}
          </div>
        </div>
      `;
    }).join('');

    view.innerHTML = `
      <div class="world-map-container">
        <div class="world-map-header">
          <h3>🗺️ Toàn Cảnh Bản Đồ Bát Hoang Tu Chân Giới</h3>
          <p>
            Vùng đất Bát Hoang rộng lớn với ba phân khu nối liền: Thanh Hà Thôn trù phú yên bình, U Minh Trúc Lâm âm u u tịch, và Hắc Phong Nhai tử địa cuồng phong. Tu sĩ có thể di chuyển qua lại tự do giữa các khu vực nối liền để làm nhiệm vụ, áp tiêu và săn dị thú.
          </p>
        </div>

        <div class="world-map-grid">
          ${zoneCardsHtml}
        </div>
      </div>
    `;
  }

  async setTab(tab) {
    this.activeMainTab = tab;
    document.querySelectorAll('.tab-btn').forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('data-tab') === tab);
    });
    document.querySelectorAll('.nav-btn').forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('data-tab') === tab);
    });
    if (tab === 'agency') {
      await this.fetchAgencyData();
    } else if (tab === 'quests') {
      await this.fetchQuests();
    }
    this.renderMainContent();
  }

  renderExploreView() {
    const view = document.getElementById('main-tab-view');
    const z = this.worldData.currentZone;
    const p = this.worldData.currentPlace;

    view.innerHTML = `
      <div class="explore-hero">
        <div class="hero-header">
          <h3>Vấn Đạo Giang Hồ - Thám Hiểm Phân Khu</h3>
          <span class="location-badge">Hiện tại: ${z ? z.name : ''} / ${p ? p.name : ''}</span>
        </div>
        <p class="hero-desc">
          Càn khôn vô tận, tiên lộ mịt mờ. Bước chân ra khỏi động phủ khám phá sơn xuyên để tìm kiếm linh thảo, gặp gỡ tàn tích tiền nhân, kết duyên cùng kỳ hiệp hoặc trảm sát yêu thú hung bạo.
        </p>
        <div class="explore-actions">
          <button class="btn-primary-glow" onclick="window.engine.exploreCurrentZone()">
            🧭 Thám Hiểm Ngay (-${z?.fatigue_cost_roam || 5} Thể lực)
          </button>
          <button class="btn-secondary" onclick="window.engine.meditateRest()">
            🧘 Đả Tọa Nhập Định (Hồi phục HP & Thể lực)
          </button>
        </div>
      </div>

      <!-- Danh sách NPC tại địa điểm -->
      <div class="section-box">
        <h4>Nhân Vật / Cư Dân Đang Có Mặt</h4>
        <div class="npc-grid">
          ${this.renderNpcList()}
        </div>
      </div>
    `;
  }

  renderNpcList() {
    const currentZoneId = this.player.zone_id;
    const zoneNpcs = this.npcs.filter(n => n.zone_id === currentZoneId);
    if (zoneNpcs.length === 0) {
      return '<div class="empty-hint">Không có NPC nào trong khu vực này.</div>';
    }

    return zoneNpcs
      .map(n => {
        // Kiểm tra nhiệm vụ liên quan đến NPC này
        const readyQuests = this.quests.filter(q => q.turnin_npc_id === n.id && q.status === 'READY_TO_TURN_IN');
        const inProgressQuests = this.quests.filter(
          q => q.status === 'IN_PROGRESS' && q.objectives && q.objectives.some(o => o.target_id === n.id)
        );
        const availableQuests = this.quests.filter(q => q.giver_npc_id === n.id && q.status === 'AVAILABLE');
        const isAgencyDest =
          this.agencyData?.activeMission &&
          this.agencyData.activeMission.destination_zone_id === n.zone_id &&
          (this.agencyData.activeMission.status === 'READY_TO_REPORT' || this.agencyData.activeMission.status === 'READY_TO_DELIVER');

        let badgeHtml = '';
        if (readyQuests.length > 0) {
          badgeHtml = `<span style="background: rgba(16, 185, 129, 0.25); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.5); font-size: 0.7rem; padding: 2px 7px; border-radius: 4px; font-weight: 700;">🎁 Trả Nhiệm Vụ (${readyQuests.length})</span>`;
        } else if (inProgressQuests.length > 0) {
          badgeHtml = `<span style="background: rgba(59, 130, 246, 0.25); color: #93c5fd; border: 1px solid rgba(59, 130, 246, 0.5); font-size: 0.7rem; padding: 2px 7px; border-radius: 4px; font-weight: 700;">💬 Có Việc Trao Đổi</span>`;
        } else if (isAgencyDest) {
          badgeHtml = `<span style="background: rgba(16, 185, 129, 0.25); color: #6ee7b7; border: 1px solid rgba(16, 185, 129, 0.5); font-size: 0.7rem; padding: 2px 7px; border-radius: 4px; font-weight: 700;">🛡️ Giao Tiêu Thám Hiểm</span>`;
        } else if (availableQuests.length > 0) {
          badgeHtml = `<span style="background: rgba(245, 158, 11, 0.25); color: #fbbf24; border: 1px solid rgba(245, 158, 11, 0.5); font-size: 0.7rem; padding: 2px 7px; border-radius: 4px; font-weight: 700;">📜 Có Nhiệm Vụ Mới (!)</span>`;
        }

        return `
          <div class="npc-card" onclick="window.engine.talkToNpc('${n.id}')">
            <div class="npc-avatar">🧙</div>
            <div class="npc-info">
              <div style="display: flex; justify-content: space-between; align-items: center; gap: 6px;">
                <div class="npc-name">${n.name} <span class="npc-title">(${n.title})</span></div>
                ${badgeHtml}
              </div>
              <div class="npc-desc">${n.description}</div>
            </div>
          </div>
        `;
      })
      .join('');
  }

  talkToNpc(npcId) {
    const npc = this.npcs.find(n => n.id === npcId);
    if (!npc) return;

    const modal = document.getElementById('event-modal');
    if (!modal) return;

    document.getElementById('modal-event-title').textContent = `🧙 [ĐỐI THOẠI] ${npc.name} (${npc.title})`;
    modal.classList.add('open');

    const dialogues = npc.dialogues.idle;
    const randomIdle = dialogues[Math.floor(Math.random() * dialogues.length)];

    const lines = [
      `"${npc.dialogues.greeting}"`,
      `"${randomIdle}"`,
      npc.dialogues.quest_hint
        ? `[Chỉ Điểm Tiên Cơ] "${npc.dialogues.quest_hint}"`
        : `Lão nhân khẽ vuốt râu mỉm cười, ánh mắt thâm thúy nhìn Đạo Hữu chờ đợi.`
    ];

    this.log(`[Hội thoại] Bái phỏng ${npc.name}.`, 'info');

    // Tìm các nhiệm vụ liên quan đến NPC này
    const readyQuests = this.quests.filter(q => q.turnin_npc_id === npc.id && q.status === 'READY_TO_TURN_IN');
    const inProgressQuests = this.quests.filter(
      q => q.status === 'IN_PROGRESS' && q.objectives && q.objectives.some(o => o.target_id === npc.id)
    );
    const availableQuests = this.quests.filter(q => q.giver_npc_id === npc.id && q.status === 'AVAILABLE');

    // Chuyến tiêu thám hiểm Tiêu Cục (nếu có)
    const activeAgency = this.agencyData?.activeMission;
    const hasAgencyDelivery =
      activeAgency &&
      activeAgency.destination_zone_id === npc.zone_id &&
      (activeAgency.status === 'READY_TO_REPORT' || activeAgency.status === 'READY_TO_DELIVER');

    this.streamNarrativeLines(lines, () => {
      const choicesContainer = document.getElementById('modal-event-choices');
      let choicesHtml = '';

      // 1. NHIỆM VỤ SẴN SÀNG TRẢ BÁO CÁO CHO NPC NÀY
      for (const q of readyQuests) {
        choicesHtml += `
          <div class="event-choice-card" style="border-color: rgba(16, 185, 129, 0.5); background: rgba(16, 185, 129, 0.12);" onclick="window.engine.turnInQuest('${q.id}')">
            <div class="choice-title" style="color: #6ee7b7;">🎁 Báo Cáo Hoàn Thành: ${q.title}</div>
            <div class="choice-desc">Bàn giao kết quả thám hiểm cho ${npc.name} và lĩnh thưởng EXP, Tu vi, Ngân lượng.</div>
          </div>
        `;
      }

      // 2. MỤC TIÊU ĐANG CẦN THỰC HIỆN VỚI NPC NÀY
      for (const q of inProgressQuests) {
        const obj = q.objectives.find(o => o.target_id === npc.id);
        if (!obj) continue;

        if (obj.type === 'TALK_NPC') {
          choicesHtml += `
            <div class="event-choice-card" style="border-color: rgba(59, 130, 246, 0.4); background: rgba(59, 130, 246, 0.08);" onclick="window.engine.interactQuest('${q.id}', 'TALK_NPC', '${obj.target_id}')">
              <div class="choice-title" style="color: #93c5fd;">💬 Đàm Đạo Dẫn Dắt Thế Giới: ${q.title}</div>
              <div class="choice-desc">${obj.description}</div>
            </div>
          `;
        } else if (obj.type === 'GATHER_INTEL') {
          choicesHtml += `
            <div class="event-choice-card" style="border-color: rgba(59, 130, 246, 0.4); background: rgba(59, 130, 246, 0.08);" onclick="window.engine.interactQuest('${q.id}', 'GATHER_INTEL', '${obj.target_id}')">
              <div class="choice-title" style="color: #93c5fd;">👂 Thám Thính Dị Tượng Rừng Sâu: ${q.title}</div>
              <div class="choice-desc">Hỏi thăm ${npc.name} về dấu vết dị thường của yêu khí.</div>
            </div>
          `;
        } else if (obj.type === 'TRACK_PERSON') {
          choicesHtml += `
            <div class="event-choice-card" style="border-color: rgba(59, 130, 246, 0.4); background: rgba(59, 130, 246, 0.08);" onclick="window.engine.interactQuest('${q.id}', 'TRACK_PERSON', '${obj.target_id}')">
              <div class="choice-title" style="color: #93c5fd;">🔍 Dò Tìm Tung Tích Nạn Nhân: ${q.title}</div>
              <div class="choice-desc">Dò hỏi ${npc.name} về người thợ thuốc mất tích bí ẩn.</div>
            </div>
          `;
        } else if (obj.type === 'DELIVER_MESSAGE') {
          choicesHtml += `
            <div class="event-choice-card" style="border-color: rgba(59, 130, 246, 0.4); background: rgba(59, 130, 246, 0.08);" onclick="window.engine.interactQuest('${q.id}', 'DELIVER_MESSAGE', '${obj.target_id}')">
              <div class="choice-title" style="color: #93c5fd;">✉️ Chuyển Giao Mật Thư Cơ Mật: ${q.title}</div>
              <div class="choice-desc">Giao tận tay phong thư cảnh báo cho ${npc.name}.</div>
            </div>
          `;
        } else if (obj.type === 'ANSWER_QUIZ') {
          choicesHtml += `
            <div class="event-choice-card" style="border-color: rgba(245, 158, 11, 0.4); background: rgba(245, 158, 11, 0.08);" onclick="window.engine.openQuizModal('${q.id}')">
              <div class="choice-title" style="color: #fde047;">❓ Tham Gia Khảo Nghiệm Dược Đạo: ${q.title}</div>
              <div class="choice-desc">Trả lời câu hỏi kiểm tra hiểu biết dược lý từ ${npc.name}.</div>
            </div>
          `;
        } else if (obj.type === 'MAKE_CHOICE') {
          choicesHtml += `
            <div class="event-choice-card" style="border-color: rgba(168, 85, 247, 0.4); background: rgba(168, 85, 247, 0.08);" onclick="window.engine.openChoiceModal('${q.id}')">
              <div class="choice-title" style="color: #c084fc;">⚖️ Đưa Ra Phán Quyết Đạo Tâm: ${q.title}</div>
              <div class="choice-desc">Đưa ra lựa chọn đạo tâm trước mặt ${npc.name}.</div>
            </div>
          `;
        } else if (obj.type === 'DELIVER_ITEM') {
          choicesHtml += `
            <div class="event-choice-card" style="border-color: rgba(56, 189, 248, 0.4); background: rgba(56, 189, 248, 0.08);" onclick="window.engine.checkDeliverQuest('${q.id}')">
              <div class="choice-title" style="color: #38bdf8;">📦 Bàn Giao Vật Phẩm Tiếp Tế: ${q.title}</div>
              <div class="choice-desc">Kiểm tra túi đồ và bàn giao cho ${npc.name}.</div>
            </div>
          `;
        }
      }

      // 3. BÀN GIAO TIÊU CỤC THÁM HIỂM TẠI ĐÂY (NẾU CÓ)
      if (hasAgencyDelivery) {
        choicesHtml += `
          <div class="event-choice-card" style="border-color: rgba(16, 185, 129, 0.6); background: rgba(16, 185, 129, 0.15);" onclick="window.engine.deliverOrReportAgencyMission('${activeAgency.id}')">
            <div class="choice-title" style="color: #6ee7b7;">🛡️ Giao Tiêu Thám Hiểm: ${activeAgency.name}</div>
            <div class="choice-desc">Giao hàng / mật thư hỏa tốc hoàn tất chuyến tiêu và nhận Tiêu Cục Tệ.</div>
          </div>
        `;
      }

      // 4. NHIỆM VỤ MỚI NPC ĐANG CÓ SẴN (AVAILABLE)
      for (const q of availableQuests) {
        choicesHtml += `
          <div class="event-choice-card" style="border-color: rgba(245, 158, 11, 0.35); background: rgba(245, 158, 11, 0.06);" onclick="window.engine.acceptQuest('${q.id}')">
            <div class="choice-title" style="color: #fbbf24;">📜 Tiếp Nhận: ${q.title}</div>
            <div class="choice-desc">${q.summary} (Thưởng: ${q.rewards.cultivation ? `+${q.rewards.cultivation} Tu vi` : ''} ${q.rewards.silver ? `+${q.rewards.silver} Bạc` : ''})</div>
          </div>
        `;
      }

      // 5. CÁC TÙY CHỌN CƠ BẢN
      choicesHtml += `
        <div class="event-choice-card" onclick="window.engine.askNpcService('${npc.id}')">
          <div class="choice-title">ℹ️ Hỏi thăm chức năng &amp; việc cần làm</div>
          <div class="choice-desc">${npc.description}</div>
        </div>
        <div class="event-choice-card" onclick="window.engine.closeEventModal()">
          <div class="choice-title">🚪 Cúi chào cáo từ</div>
          <div class="choice-desc">Rời khỏi đàm đạo, tiếp tục rèn luyện tiên lộ.</div>
        </div>
      `;

      choicesContainer.innerHTML = choicesHtml;
    });
  }

  askNpcService(npcId) {
    const npc = this.npcs.find(n => n.id === npcId);
    if (!npc) return;
    const services = npc.related_services?.length ? npc.related_services.join(', ') : 'Chỉ dẫn đàm đạo';
    const lines = [
      `[Dịch vụ Tiên Gia]: ${services}`,
      `"${npc.name} sẵn lòng trợ giúp Đạo Hữu khi gặp khó khăn tại ${this.worldData.currentZone?.name || 'phân khu'}."`
    ];
    this.streamNarrativeLines(lines, () => {
      const choicesContainer = document.getElementById('modal-event-choices');
      choicesContainer.innerHTML = `
        <button class="btn-primary-glow" onclick="window.engine.closeEventModal()">
          Đã hiểu, đa tạ tiền bối!
        </button>
      `;
    });
  }

  renderCraftingView() {
    const view = document.getElementById('main-tab-view');
    view.innerHTML = `
      <div class="crafting-container">
        <h3>Tiên Môn Chế Tác Viện (Luyện Đan & Luyện Khí)</h3>
        <p class="section-hint">Tự tay ngưng tụ đan dược hồi thiên hoặc tôi rèn thần binh hộ thể để nâng cao thực lực chiến đấu.</p>

        <div class="recipe-grid">
          ${this.recipes
            .map(r => {
              const hasMats = r.required_materials.every(mat => {
                const slot = this.player.inventory.find(s => s.item_id === mat.item_id);
                return slot && slot.quantity >= mat.quantity;
              });

              return `
              <div class="recipe-card ${hasMats ? 'ready' : 'unmet'}">
                <div class="recipe-header">
                  <span class="discipline-badge ${r.discipline}">${r.discipline === 'ALCHEMY' ? 'Luyện Đan' : 'Luyện Khí'}</span>
                  <span class="recipe-name">${r.name}</span>
                </div>
                <div class="recipe-desc">${r.description}</div>
                
                <div class="mats-list">
                  <strong>Nguyên liệu cần:</strong>
                  ${r.required_materials
                    .map(m => {
                      const cur = this.player.inventory.find(s => s.item_id === m.item_id)?.quantity || 0;
                      const ok = cur >= m.quantity;
                      return `<span class="mat-item ${ok ? 'ok' : 'missing'}">${m.item_name} (${cur}/${m.quantity})</span>`;
                    })
                    .join(' + ')}
                </div>

                <div class="recipe-costs">
                  <span>Chi phí: ${r.silver_cost} Bạc, ${r.fatigue_cost} Thể lực</span>
                  <span>Tỉ lệ: ${Math.floor(r.base_success_rate * 100)}%</span>
                </div>

                <button class="btn-craft ${hasMats ? '' : 'disabled'}" onclick="window.engine.craftRecipe('${r.id}')">
                  ${r.discipline === 'ALCHEMY' ? '🔥 Khai Lò Luyện Đan' : '⚒️ Đập Búa Rèn Binh'}
                </button>
              </div>
            `;
            })
            .join('')}
        </div>
      </div>
    `;
  }

  renderGatheringView() {
    const view = document.getElementById('main-tab-view');
    const zoneNodes = this.gatheringNodes.filter(n => n.zone_id === this.player.zone_id);

    view.innerHTML = `
      <div class="gathering-container">
        <h3>Khai Thác Khoáng Mạch & Thu Hái Linh Thảo</h3>
        <p class="section-hint">Điểm tài nguyên tự nhiên tại [${this.worldData.currentZone?.name}].</p>

        <div class="gathering-grid">
          ${
            zoneNodes.length === 0
              ? '<div class="empty-hint">Khu vực này không có điểm thu thập nào.</div>'
              : zoneNodes
                  .map(
                    n => `
                <div class="node-card">
                  <div class="node-header">
                    <span class="node-type">${n.type === 'HERB_PATCH' ? '🌿 Bãi Thảo Dược' : '⛏️ Mỏ Khoáng'}</span>
                    <span class="node-name">${n.name}</span>
                  </div>
                  <div class="node-desc">${n.description}</div>
                  <div class="node-info">
                    <span>Yêu cầu: ${this.getRealmName(n.min_realm)}</span> | <span>Hao tổn: ${n.fatigue_cost} Thể lực</span>
                  </div>
                  <button class="btn-gather" onclick="window.engine.gatherAtNode('${n.id}')">
                    Thu Thập Tài Nguyên
                  </button>
                </div>
              `
                  )
                  .join('')
          }
        </div>
      </div>
    `;
  }

  renderBestiaryView() {
    const view = document.getElementById('main-tab-view');
    if (!view) return;

    if (!this.bestiarySelectedZoneId) {
      this.bestiarySelectedZoneId = this.player.zone_id;
    }

    const zones = this.worldData.zones || [];
    const currentZoneId = this.player.zone_id;
    const selectedZone = zones.find(z => z.id === this.bestiarySelectedZoneId) || this.worldData.currentZone;
    const zoneMonsters = (this.monsters || []).filter(m => m.zone_id === this.bestiarySelectedZoneId);

    // Zone selector buttons
    const zoneTabsHtml = zones
      .map(z => {
        const isSelected = z.id === this.bestiarySelectedZoneId;
        const isPlayerHere = z.id === currentZoneId;
        return `
          <button class="tab-btn ${isSelected ? 'active' : ''}" style="padding: 6px 14px; font-size: 0.8rem;" onclick="window.engine.setBestiaryZone('${z.id}')">
            ${isPlayerHere ? '📍 ' : ''}${z.name}
          </button>
        `;
      })
      .join('');

    let monstersGridHtml = '';
    if (zoneMonsters.length === 0) {
      monstersGridHtml = '<div class="empty-hint" style="grid-column: 1 / -1;">Không có yêu thú nào tại phân khu an toàn này.</div>';
    } else {
      monstersGridHtml = zoneMonsters
        .map(m => {
          let actionBtn = '';
          if (this.bestiarySelectedZoneId === currentZoneId) {
            actionBtn = `
              <button class="btn-hunt" onclick="window.engine.huntMonster('${m.id}')">
                ⚔️ Trảm Yêu Đoạt Bảo (-12 Thể lực)
              </button>
            `;
          } else {
            actionBtn = `
              <button class="btn-hunt" style="background: linear-gradient(135deg, #0284c7, #0369a1); border-color: #38bdf8;" onclick="window.engine.travelToZone('${m.zone_id}')">
                🧭 Di Chuyển Đến ${selectedZone?.name || 'Vùng'} Để Săn (-${selectedZone?.travel_fatigue_base || 5} Thể Lực)
              </button>
            `;
          }

          return `
            <div class="monster-card ${m.tier}">
              <div class="mon-header">
                <span class="mon-tier">${this.getMonsterTierName(m.tier)}</span>
                <span class="mon-name">${m.name}</span>
              </div>
              <div class="mon-title">${m.title}</div>
              <div class="mon-stats">
                <span>HP: ${m.max_health}</span> | <span>Công: ${m.attack}</span> | <span>Thủ: ${m.defense}</span>
              </div>
              ${actionBtn}
            </div>
          `;
        })
        .join('');
    }

    view.innerHTML = `
      <div class="bestiary-container">
        <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 10px; margin-bottom: 12px;">
          <div>
            <h3 style="margin-bottom: 4px;">Danh Lục Dị Thú Phân Khu</h3>
            <p class="section-hint" style="margin-bottom: 0;">
              Yêu thú dị biến lộng hành tại bát hoang. Hãy chọn phân khu để xem dị thú phân bố và chuẩn bị thực lực trước khi trảm yêu đoạt bảo!
            </p>
          </div>
          <div style="display: flex; gap: 6px; flex-wrap: wrap;">
            ${zoneTabsHtml}
          </div>
        </div>

        <div class="monster-grid">
          ${monstersGridHtml}
        </div>
      </div>
    `;
  }

  setBestiaryZone(zoneId) {
    this.bestiarySelectedZoneId = zoneId;
    this.renderBestiaryView();
  }

  renderInventory() {
    const list = document.getElementById('inventory-grid');
    if (!list) return;

    if (this.player.inventory.length === 0) {
      list.innerHTML = '<div class="empty-hint">Túi trữ vật trống không.</div>';
      return;
    }

    let html = '';
    for (const slot of this.player.inventory) {
      const def = this.items.get(slot.item_id);
      const name = def ? def.name : slot.item_id;
      const rarity = def ? def.rarity : 'COMMON';
      const typeName = this.getItemTypeName(def?.type);

      html += `
        <div class="inv-slot rarity-${rarity}" title="${def ? `[${typeName}] ${def.description}` : ''}" onclick="window.engine.useItem('${slot.item_id}')">
          <div class="inv-icon">
            ${def?.type === 'PILL' ? '💊' : def?.type === 'HERB' ? '🌿' : def?.type === 'ORE' ? '💎' : def?.type === 'EQUIPMENT' ? '⚔️' : '📦'}
          </div>
          <div class="inv-name">${name}</div>
          <div class="inv-qty">x${slot.quantity}</div>
        </div>
      `;
    }
    list.innerHTML = html;
  }

  renderChronicleLogs() {
    const logBox = document.getElementById('chronicle-logs');
    if (!logBox) return;

    logBox.innerHTML = this.player.logs
      .slice(-30)
      .reverse()
      .map(
        log => `
      <div class="log-entry log-${log.type}">
        <span class="log-time">[${log.time}]</span> ${log.text}
      </div>
    `
      )
      .join('');
  }

  log(text, type = 'info') {
    const entry = {
      time: new Date().toLocaleTimeString(),
      text,
      type,
    };
    this.player.logs.push(entry);
    this.renderChronicleLogs();
  }

  notify(msg, type = 'info') {
    try {
      if (typeof navigator !== 'undefined' && navigator.vibrate) {
        navigator.vibrate(type === 'error' ? [40, 40, 40] : 25);
      }
    } catch (e) {}
    const toast = document.createElement('div');
    toast.className = `toast-msg toast-${type}`;
    toast.textContent = msg;
    document.body.appendChild(toast);
    setTimeout(() => {
      toast.classList.add('show');
    }, 10);
    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => toast.remove(), 400);
    }, 3200);
  }

  // ====================================================
  // 10. PROGRESSIVE NARRATIVE STREAMER (BÍ QUYẾT UI GIANG HỒ)
  // ====================================================

  /**
   * Truyền và hiển thị từng dòng chữ lần lượt (Progressive Stream)
   * Kèm 3 chấm nhịp thở (animate-dot-pulse), sau khi xong trượt hiện các lựa chọn bên dưới
   */
  streamNarrativeLines(lines, onFinish, delayMs = 450) {
    if (this.streamTimer) {
      clearTimeout(this.streamTimer);
      this.streamTimer = null;
    }

    const linesContainer = document.getElementById('modal-event-lines');
    const indicator = document.getElementById('modal-typing-indicator');
    const choicesContainer = document.getElementById('modal-event-choices');

    if (!linesContainer || !indicator || !choicesContainer) return;

    // Reset vùng hiển thị
    linesContainer.innerHTML = '';
    indicator.style.display = 'inline-flex';
    choicesContainer.className = 'event-choices choices-deferred'; // Ẩn và trượt xuống
    choicesContainer.innerHTML = '';

    this.pendingLines = [...lines];
    this.onStreamFinishCallback = onFinish;

    const step = () => {
      if (this.pendingLines.length === 0) {
        indicator.style.display = 'none';
        this.streamTimer = null;
        if (this.onStreamFinishCallback) {
          this.onStreamFinishCallback();
          this.onStreamFinishCallback = null;
        }
        // Trượt nhẹ khối lựa chọn lên bên dưới nội dung
        choicesContainer.classList.add('revealed');
        return;
      }

      const nextLine = this.pendingLines.shift();
      const div = document.createElement('div');
      div.className = 'narrative-line';
      div.textContent = nextLine;
      linesContainer.appendChild(div);

      // Tự động cuộn xuống theo dòng mới nhất
      const parent = linesContainer.parentElement;
      if (parent) parent.scrollTop = parent.scrollHeight;

      this.streamTimer = setTimeout(step, delayMs);
    };

    // Bắt đầu dòng đầu tiên sau 120ms
    this.streamTimer = setTimeout(step, 120);
  }

  /**
   * Bỏ qua hiệu ứng gõ / hiện chữ, hiển thị ngay lập tức toàn bộ
   */
  skipStream() {
    if (!this.streamTimer && this.pendingLines.length === 0) return;

    if (this.streamTimer) {
      clearTimeout(this.streamTimer);
      this.streamTimer = null;
    }

    const linesContainer = document.getElementById('modal-event-lines');
    const indicator = document.getElementById('modal-typing-indicator');
    const choicesContainer = document.getElementById('modal-event-choices');

    if (linesContainer && indicator && choicesContainer) {
      while (this.pendingLines.length > 0) {
        const nextLine = this.pendingLines.shift();
        const div = document.createElement('div');
        div.className = 'narrative-line';
        div.textContent = nextLine;
        linesContainer.appendChild(div);
      }

      indicator.style.display = 'none';

      if (this.onStreamFinishCallback) {
        this.onStreamFinishCallback();
        this.onStreamFinishCallback = null;
      }

      choicesContainer.classList.add('revealed');
    }
  }

  // ====================================================
  // 11. MODAL SỰ KIỆN KỲ NGỘ & KẾT QUẢ
  // ====================================================
  renderActiveEventModal() {
    const modal = document.getElementById('event-modal');
    if (!modal || !this.activeEventData) return;

    const ev = this.activeEventData.event;
    const choices = this.activeEventData.available_choices;

    document.getElementById('modal-event-title').textContent = `✨ [KỲ NGỘ] ${ev.title}`;
    modal.classList.add('open');

    // Tách văn phong thành từng câu mạch lạc để hiển thị dần
    const rawSentences = ev.description
      .split(/(?<=[.!?—])\s+/)
      .map(s => s.trim())
      .filter(s => s.length > 0);

    const lines = rawSentences.length > 0 ? rawSentences : [ev.description];

    this.streamNarrativeLines(lines, () => {
      const choicesContainer = document.getElementById('modal-event-choices');
      choicesContainer.innerHTML = choices
        .map(
          c => `
        <div class="event-choice-card ${c.can_choose ? '' : 'disabled'}" 
             onclick="${c.can_choose ? `window.engine.resolveActiveEvent('${c.choice_id}')` : ''}">
          <div class="choice-title">${c.text}</div>
          <div class="choice-desc">${c.description}</div>
          ${c.unmet_reason ? `<div class="choice-unmet">⚠️ ${c.unmet_reason}</div>` : ''}
        </div>
      `
        )
        .join('');
    });
  }

  renderEventResult(result) {
    const modal = document.getElementById('event-modal');
    if (!modal) return;

    document.getElementById('modal-event-title').textContent = result.success ? '🏆 THÀNH CÔNG VƯỢT QUA' : '⚠️ GẶP PHẢI TRẮC TRỞ';

    const rawSentences = result.narrative
      .split(/(?<=[.!?])\s+/)
      .map(s => s.trim())
      .filter(s => s.length > 0);
    const lines = rawSentences.length > 0 ? rawSentences : [result.narrative];

    // Thêm các dòng hiệu ứng tài nguyên vào sau
    const effectLines = [];
    if (result.effects.cultivation_gained) effectLines.push(`✦ Tu vi gia tăng: +${result.effects.cultivation_gained}`);
    if (result.effects.silver_change) effectLines.push(`✦ Ngân lượng biến động: ${result.effects.silver_change > 0 ? '+' : ''}${result.effects.silver_change} Lượng`);
    if (result.effects.health_change) effectLines.push(`✦ Khí huyết tổn hao: ${result.effects.health_change} HP`);
    if (result.effects.karma_change) effectLines.push(`✦ Đạo tâm thay đổi: ${result.effects.karma_change > 0 ? '+' : ''}${result.effects.karma_change}`);
    for (const it of result.effects.items_gained) {
      effectLines.push(`✦ Thu được bảo vật: [${it.item_name} x${it.quantity}]`);
    }

    const allLines = [...lines, ...effectLines];

    this.streamNarrativeLines(allLines, () => {
      const choicesContainer = document.getElementById('modal-event-choices');
      choicesContainer.innerHTML = `
        <button class="btn-primary-glow" onclick="window.engine.closeEventModal()">
          Thu Nhận Kết Quả & Tiếp Tục Tiên Lộ
        </button>
      `;
    });
  }

  closeEventModal() {
    if (this.streamTimer) {
      clearTimeout(this.streamTimer);
      this.streamTimer = null;
    }
    const modal = document.getElementById('event-modal');
    if (modal) modal.classList.remove('open');
    this.activeEventData = null;
  }

  // ====================================================
  // 12. HỆ THỐNG NHIỆM VỤ TU CHÂN (QUEST SYSTEM)
  // ====================================================
  async fetchQuests() {
    try {
      const invParam = encodeURIComponent(JSON.stringify(this.player.inventory));
      const res = await fetch(
        `${this.apiBase}/api/xianxia/quests/player?userId=${encodeURIComponent(this.player.name)}&realm=${this.player.realm}&level=1&inventory=${invParam}`
      );
      const json = await res.json();
      if (json.success && Array.isArray(json.data)) {
        this.quests = json.data;
        // Tự động chọn 1 quest theo dõi (ưu tiên READY_TO_TURN_IN, rồi IN_PROGRESS, rồi AVAILABLE của Chính Tuyến)
        this.trackedQuest =
          this.quests.find(q => q.status === 'READY_TO_TURN_IN') ||
          this.quests.find(q => q.status === 'IN_PROGRESS') ||
          this.quests.find(q => q.category === 'CHINH_TUYEN' && q.status === 'AVAILABLE') ||
          this.quests.find(q => q.status === 'AVAILABLE') ||
          null;
        this.renderQuestTrackerHud();
        if (this.activeMainTab === 'quests') {
          this.renderQuestBoard();
        }
      }
    } catch (err) {
      console.warn('Lỗi tải danh sách nhiệm vụ:', err);
    }
  }

  async notifyMonsterKill(monsterId, count = 1) {
    try {
      await fetch(`${this.apiBase}/api/xianxia/quests/monster-kill`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: this.player.name, monsterId, count }),
      });
    } catch (e) {}
  }

  async notifyLootAcquired(itemId, quantity = 1) {
    try {
      await fetch(`${this.apiBase}/api/xianxia/quests/loot-acquired`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: this.player.name, itemId, quantity }),
      });
    } catch (e) {}
  }

  renderQuestTrackerHud() {
    const hud = document.getElementById('quest-tracker-hud');
    if (!hud) return;

    const journeyLine = document.getElementById('journey-line-progress');
    const navBadge = document.getElementById('nav-quest-badge');

    // Kiểm tra nếu có bất kỳ nhiệm vụ nào sẵn sàng trả thưởng
    const hasReadyToTurnIn = this.quests.some(q => q.status === 'READY_TO_TURN_IN');
    if (navBadge) {
      navBadge.style.display = hasReadyToTurnIn ? 'flex' : 'none';
    }

    if (!this.trackedQuest) {
      document.getElementById('tracker-quest-badge').textContent = 'CHÍNH TUYẾN';
      document.getElementById('tracker-quest-title').textContent = 'Không có nhiệm vụ nào đang nhận';
      document.getElementById('tracker-quest-progress').textContent = 'Nhấp "Mở Bảng" để tiếp nhận';
      if (journeyLine) journeyLine.style.flexGrow = '5';
      return;
    }

    const q = this.trackedQuest;
    const isMain = q.category === 'CHINH_TUYEN';
    const badgeEl = document.getElementById('tracker-quest-badge');
    badgeEl.textContent = isMain ? 'CHÍNH TUYẾN' : 'CÀY CUỐC';
    badgeEl.style.color = isMain ? '#fbbf24' : '#34d399';
    badgeEl.style.borderColor = isMain ? 'rgba(245, 158, 11, 0.4)' : 'rgba(16, 185, 129, 0.4)';

    document.getElementById('tracker-quest-title').textContent = q.title;

    let progText = '';
    let pct = 10;
    if (q.status === 'READY_TO_TURN_IN') {
      progText = '🎉 ĐÃ HOÀN THÀNH - SẴN SÀNG TRẢ BẢNG!';
      pct = 100;
    } else if (q.status === 'IN_PROGRESS') {
      const obj = q.objectives[0];
      if (obj) {
        const cur = q.current_objectives?.[obj.id] || 0;
        pct = Math.min(100, Math.floor((cur / obj.required_count) * 100));
        progText = `Tiến độ: ${cur}/${obj.required_count} (${obj.description})`;
      }
    } else if (q.status === 'AVAILABLE') {
      progText = 'Sẵn sàng tiếp nhận!';
      pct = 15;
    }
    document.getElementById('tracker-quest-progress').textContent = progText;
    if (journeyLine) {
      journeyLine.style.flexGrow = `${Math.max(5, pct)}`;
    }
  }

  renderQuestBoard() {
    const view = document.getElementById('main-tab-view');
    if (!view) return;

    const mainQuests = this.quests.filter(q => q.category === 'CHINH_TUYEN');
    const sideQuests = this.quests.filter(q => q.category === 'CAY_CUOC');

    let html = `
      <div style="margin-bottom: 14px;">
        <h3 style="font-family: 'Noto Serif TC', serif; color: #f8fafc; font-size: 1.25rem;">
          📜 Bảng Nhiệm Vụ Tu Chân &amp; Bát Hoang Giang Hồ
        </h3>
        <p style="font-size: 0.82rem; color: #94a3b8; margin-top: 4px;">
          Lũ yêu thú Chính Tuyến có sức mạnh thâm hậu khôn lường. Tu sĩ bắt buộc phải cày cuốc hoàn thành các thỉnh cầu trong thôn để tích lũy tu vi, ngân lượng và rèn trang bị mới đủ sức nghênh chiến!
        </p>
      </div>

      <!-- NHIỆM VỤ CHÍNH TUYẾN -->
      <div class="quest-category-title main">
        <span>🌟 NHIỆM VỤ CHÍNH TUYẾN (BẮT BUỘC ĐỘT PHÁ CẢNH GIỚI)</span>
      </div>
      <div class="quest-grid">
        ${mainQuests.map(q => this.buildQuestCardHtml(q)).join('')}
      </div>

      <!-- NHIỆM VỤ CÀY CUỐC GIANG HỒ -->
      <div class="quest-category-title side">
        <span>⚔️ 10 NHIỆM VỤ CÀY CUỐC GIANG HỒ (TIẾP LŨY BẢO VẬT &amp; ĐẠO TÂM)</span>
      </div>
      <div class="quest-grid">
        ${sideQuests.map(q => this.buildQuestCardHtml(q)).join('')}
      </div>
    `;

    view.innerHTML = html;
  }

  buildQuestCardHtml(q) {
    const isMain = q.category === 'CHINH_TUYEN';
    const status = q.status;
    const isCompleted = status === 'COMPLETED';

    // Badge text
    let badgeLabel = status;
    if (status === 'LOCKED') badgeLabel = '🔒 Chưa Mở';
    if (status === 'AVAILABLE') badgeLabel = '📜 Khả Dụng';
    if (status === 'IN_PROGRESS') badgeLabel = '⏳ Đang Làm';
    if (status === 'READY_TO_TURN_IN') badgeLabel = '🎁 Sẵn Sàng Trả';
    if (status === 'COMPLETED') badgeLabel = '✨ Đã Xong';

    // Action button
    let actionBtnHtml = '';
    if (status === 'AVAILABLE') {
      actionBtnHtml = `<button class="btn-quest-action" onclick="window.engine.acceptQuest('${q.id}')">Tiếp Nhận Nhiệm Vụ 📜</button>`;
    } else if (status === 'READY_TO_TURN_IN') {
      actionBtnHtml = `<button class="btn-quest-action turn-in" onclick="window.engine.turnInQuest('${q.id}')">Trả Nhiệm Vụ &amp; Nhận Thưởng 🎁</button>`;
    } else if (status === 'IN_PROGRESS') {
      const obj = q.objectives[0];
      if (obj) {
        if (obj.type === 'TALK_NPC') {
          actionBtnHtml = `<button class="btn-quest-action" onclick="window.engine.interactQuest('${q.id}', 'TALK_NPC', '${obj.target_id}')">💬 Đàm Đạo Với ${obj.target_name || 'NPC'}</button>`;
        } else if (obj.type === 'GATHER_INTEL') {
          actionBtnHtml = `<button class="btn-quest-action" onclick="window.engine.interactQuest('${q.id}', 'GATHER_INTEL', '${obj.target_id}')">👂 Thám Thính Dị Tượng</button>`;
        } else if (obj.type === 'TRACK_PERSON') {
          actionBtnHtml = `<button class="btn-quest-action" onclick="window.engine.interactQuest('${q.id}', 'TRACK_PERSON', '${obj.target_id}')">🔍 Dò Tìm Tung Tích Nạn Nhân</button>`;
        } else if (obj.type === 'DELIVER_MESSAGE') {
          actionBtnHtml = `<button class="btn-quest-action" onclick="window.engine.interactQuest('${q.id}', 'DELIVER_MESSAGE', '${obj.target_id}')">✉️ Chuyển Giao Mật Thư</button>`;
        } else if (obj.type === 'ANSWER_QUIZ') {
          actionBtnHtml = `<button class="btn-quest-action" onclick="window.engine.openQuizModal('${q.id}')">❓ Tham Gia Khảo Nghiệm Dược Đạo</button>`;
        } else if (obj.type === 'MAKE_CHOICE') {
          actionBtnHtml = `<button class="btn-quest-action" onclick="window.engine.openChoiceModal('${q.id}')">⚖️ Đưa Ra Phán Quyết Đạo Tâm</button>`;
        } else if (obj.type === 'KILL_MONSTER') {
          actionBtnHtml = `<button class="btn-quest-action" onclick="window.engine.setTab('bestiary')">⚔️ Đi Săn ${obj.target_name || 'Quái Vật'}</button>`;
        } else if (obj.type === 'GATHER_ITEM') {
          actionBtnHtml = `<button class="btn-quest-action" onclick="window.engine.setTab('gathering')">🌿 Đi Hái ${obj.target_name || 'Linh Thảo'}</button>`;
        } else if (obj.type === 'LOOT_DROP') {
          actionBtnHtml = `<button class="btn-quest-action" onclick="window.engine.setTab('bestiary')">🐺 Săn Tìm ${obj.target_name || 'Vật Phẩm'}</button>`;
        } else if (obj.type === 'DELIVER_ITEM') {
          actionBtnHtml = `<button class="btn-quest-action" onclick="window.engine.checkDeliverQuest('${q.id}')">📦 Giao Nộp Vật Phẩm</button>`;
        }
      }
    } else if (status === 'LOCKED') {
      const minR = q.requirements.min_realm ? `Cảnh giới: ${this.getRealmName(q.requirements.min_realm)}` : '';
      const minL = q.requirements.min_level ? `Cấp ${q.requirements.min_level}` : '';
      actionBtnHtml = `<button class="btn-quest-action locked" disabled>🔒 Yêu cầu: ${minR} ${minL}</button>`;
    } else if (status === 'COMPLETED') {
      actionBtnHtml = `<div style="text-align: center; color: #34d399; font-weight: 700; font-size: 0.82rem; padding: 6px;">✨ ĐÃ HOÀN TẤT</div>`;
    }

    return `
      <div class="quest-card ${isMain ? 'main-story' : ''} ${isCompleted ? 'completed' : ''}">
        <div class="quest-card-header">
          <div>
            <div class="quest-title-text">${q.title}</div>
            <div class="quest-giver">Người giao: ${q.giver_npc_name} → Trả: ${q.turnin_npc_name}</div>
          </div>
          <span class="quest-status-badge ${status}">${badgeLabel}</span>
        </div>

        <div class="quest-desc">${q.summary}</div>

        <!-- MỤC TIÊU -->
        <div style="display: flex; flex-direction: column; gap: 6px;">
          ${q.objectives
            .map(obj => {
              const current = q.current_objectives?.[obj.id] || 0;
              const req = obj.required_count;
              const pct = Math.min(100, Math.floor((current / req) * 100));
              return `
                <div class="quest-objective-box">
                  <div class="quest-objective-desc">
                    <span>${obj.description}</span>
                    <span style="font-weight: 700; color: ${pct >= 100 ? '#34d399' : '#38bdf8'};">${current}/${req}</span>
                  </div>
                  <div class="quest-progress-bar">
                    <div class="quest-progress-fill" style="width: ${pct}%;"></div>
                  </div>
                </div>
              `;
            })
            .join('')}
        </div>

        <!-- PHẦN THƯỞNG -->
        <div class="quest-rewards-row">
          ${q.rewards.exp ? `<span class="reward-pill exp">EXP +${q.rewards.exp}</span>` : ''}
          ${q.rewards.cultivation ? `<span class="reward-pill cult">Tu vi +${q.rewards.cultivation}</span>` : ''}
          ${q.rewards.silver ? `<span class="reward-pill silver">Bạc +${q.rewards.silver}</span>` : ''}
          ${q.rewards.title ? `<span class="reward-pill title">Danh hiệu: ${q.rewards.title}</span>` : ''}
          ${(q.rewards.items || []).map(it => `<span class="reward-pill item">${it.item_name} x${it.quantity}</span>`).join('')}
        </div>

        <div style="margin-top: auto; padding-top: 6px;">
          ${actionBtnHtml}
        </div>
      </div>
    `;
  }

  // TƯƠNG TÁC NHẬN / NỘP / KHẢO NGHIỆM / LỰA CHỌN
  async acceptQuest(questId) {
    try {
      const res = await fetch(`${this.apiBase}/api/xianxia/quests/${questId}/accept`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: this.player.name,
          realm: this.player.realm,
          level: 1,
          inventory: this.player.inventory,
        }),
      });
      const json = await res.json();
      if (!json.success) {
        this.notify(json.message || 'Không thể tiếp nhận nhiệm vụ!', 'error');
        return;
      }

      await this.fetchQuests();
      this.notify(json.message, 'success');
      this.log(`[Nhiệm Vụ] ${json.message}`, 'info');

      // Mở modal đối thoại typewriter giới thiệu nhiệm vụ
      if (json.narrative_lines && json.narrative_lines.length > 0) {
        this.openQuestNarrativeModal(`📜 TIẾP NHẬN: ${json.quest?.title}`, json.narrative_lines);
      }
    } catch (err) {
      this.notify('Lỗi tiếp nhận: ' + err.message, 'error');
    }
  }

  async interactQuest(questId, actionType, targetId) {
    try {
      const res = await fetch(`${this.apiBase}/api/xianxia/quests/${questId}/interact`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: this.player.name,
          actionType,
          targetId,
        }),
      });
      const json = await res.json();
      if (!json.success) {
        this.notify(json.message || 'Tương tác thất bại!', 'error');
        return;
      }

      await this.fetchQuests();
      this.notify(json.message, 'success');

      if (json.narrative_lines && json.narrative_lines.length > 0) {
        this.openQuestNarrativeModal(`💬 ĐỐI THOẠI NHIỆM VỤ: ${json.quest?.title}`, json.narrative_lines);
      }
    } catch (err) {
      this.notify('Lỗi tương tác: ' + err.message, 'error');
    }
  }

  openQuizModal(questId) {
    const q = this.quests.find(item => item.id === questId);
    if (!q) return;
    const obj = q.objectives.find(o => o.type === 'ANSWER_QUIZ');
    if (!obj) return;

    const modal = document.getElementById('event-modal');
    if (!modal) return;

    document.getElementById('modal-event-title').textContent = `❓ [KHẢO NGHIỆM] ${q.title}`;
    modal.classList.add('open');

    const lines = [
      'Trần Dược Sư nhìn ngươi với ánh mắt nghiêm nghị:',
      obj.quiz_question || 'Hãy trả lời câu hỏi khảo nghiệm dược lý dưới đây:',
    ];

    this.streamNarrativeLines(lines, () => {
      const choicesContainer = document.getElementById('modal-event-choices');
      choicesContainer.innerHTML = (obj.quiz_options || [])
        .map(
          (opt, idx) => `
            <div class="event-choice-card" onclick="window.engine.submitQuizAnswer('${q.id}', '${obj.id}', ${idx})">
              <div class="choice-title">${opt.text}</div>
            </div>
          `
        )
        .join('');
    });
  }

  async submitQuizAnswer(questId, objectiveId, selectedIndex) {
    try {
      const res = await fetch(`${this.apiBase}/api/xianxia/quests/${questId}/quiz`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: this.player.name,
          objectiveId,
          selectedIndex,
        }),
      });
      const json = await res.json();

      if (json.narrative_lines && json.narrative_lines.length > 0) {
        this.openQuestNarrativeModal(
          json.success ? '🏆 KHẢO NGHIỆM CHÍNH XÁC' : '⚠️ ĐÁP ÁN CHƯA ĐÚNG',
          json.narrative_lines
        );
      } else {
        this.notify(json.message, json.success ? 'success' : 'error');
      }

      await this.fetchQuests();
    } catch (err) {
      this.notify('Lỗi nộp khảo nghiệm: ' + err.message, 'error');
    }
  }

  openChoiceModal(questId) {
    const q = this.quests.find(item => item.id === questId);
    if (!q) return;
    const obj = q.objectives.find(o => o.type === 'MAKE_CHOICE');
    if (!obj) return;

    const modal = document.getElementById('event-modal');
    if (!modal) return;

    document.getElementById('modal-event-title').textContent = `⚖️ [PHÁN QUYẾT ĐẠO TÂM] ${q.title}`;
    modal.classList.add('open');

    const lines = [
      'Đứng trước tình cảnh éo le của thiếu niên trộm khoáng thạch:',
      obj.choice_prompt || 'Đạo hữu sẽ lựa chọn thế nào để bảo toàn Đạo Tâm?',
    ];

    this.streamNarrativeLines(lines, () => {
      const choicesContainer = document.getElementById('modal-event-choices');
      choicesContainer.innerHTML = (obj.choice_options || [])
        .map(
          opt => `
            <div class="event-choice-card" onclick="window.engine.submitMoralChoice('${q.id}', '${obj.id}', '${opt.id}')">
              <div class="choice-title">${opt.text}</div>
              <div class="choice-desc">${opt.consequence}</div>
            </div>
          `
        )
        .join('');
    });
  }

  async submitMoralChoice(questId, objectiveId, choiceOptionId) {
    try {
      const res = await fetch(`${this.apiBase}/api/xianxia/quests/${questId}/choice`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: this.player.name,
          objectiveId,
          choiceOptionId,
        }),
      });
      const json = await res.json();
      if (!json.success) {
        this.notify(json.message, 'error');
        return;
      }

      await this.fetchQuests();
      if (json.narrative_lines && json.narrative_lines.length > 0) {
        this.openQuestNarrativeModal('✨ QUYẾT ĐỊNH ĐẠO TÂM ĐÃ ĐỊNH', json.narrative_lines);
      }
    } catch (err) {
      this.notify('Lỗi gửi lựa chọn: ' + err.message, 'error');
    }
  }

  async checkDeliverQuest(questId) {
    const q = this.quests.find(item => item.id === questId);
    if (!q) return;
    const deliverObj = q.objectives.find(o => o.type === 'DELIVER_ITEM' || o.type === 'GATHER_ITEM');
    if (!deliverObj) return;

    const item = this.player.inventory.find(i => i.item_id === deliverObj.target_id);
    const count = item ? item.quantity : 0;
    if (count >= deliverObj.required_count) {
      await this.turnInQuest(questId);
    } else {
      this.notify(
        `Chưa đủ [${deliverObj.target_name || deliverObj.target_id}]! Hiện có ${count}/${deliverObj.required_count}.`,
        'warning'
      );
    }
  }

  async turnInQuest(questId) {
    try {
      const res = await fetch(`${this.apiBase}/api/xianxia/quests/${questId}/turn-in`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: this.player.name,
          inventory: this.player.inventory,
        }),
      });
      const json = await res.json();
      if (!json.success) {
        this.notify(json.message || 'Chưa đủ điều kiện hoàn thành nhiệm vụ!', 'error');
        return;
      }

      const reward = json.rewards_claimed;
      if (reward) {
        if (reward.exp) this.player.exp = (this.player.exp || 0) + reward.exp;
        if (reward.cultivation) this.addCultivation(reward.cultivation);
        if (reward.silver) this.player.silver += reward.silver;
        if (reward.karma) this.player.karma = (this.player.karma || 0) + reward.karma;
        if (reward.title) this.player.title = reward.title;
        if (reward.items && reward.items.length > 0) {
          for (const it of reward.items) {
            this.addItemToInventory(it.item_id, it.quantity);
          }
        }
      }

      this.savePlayerState();
      this.renderPlayerStats();
      this.renderInventory();
      await this.fetchQuests();

      this.notify(`Hoàn thành xuất sắc: ${json.quest?.title}!`, 'success');
      this.log(`[Đại Thắng] ${json.message}`, 'success');

      // Mở modal chúc mừng typewriter
      const turninLines = json.narrative_lines || [json.message];
      const rewardSummaryLines = [
        `✦ Phần thưởng nhận được: ${reward.exp ? `+${reward.exp} EXP` : ''} | ${reward.cultivation ? `+${reward.cultivation} Tu Vi` : ''} | ${reward.silver ? `+${reward.silver} Bạc` : ''}`,
      ];
      if (reward.title) rewardSummaryLines.push(`✦ Vinh danh Danh hiệu mới: [${reward.title}]`);
      if (reward.items && reward.items.length > 0) {
        rewardSummaryLines.push(
          `✦ Thu nhận bảo vật: ${reward.items.map(i => `[${i.item_name} x${i.quantity}]`).join(', ')}`
        );
      }

      this.openQuestNarrativeModal(
        `🏆 HOÀN THÀNH: ${json.quest?.title}`,
        [...turninLines, ...rewardSummaryLines]
      );
    } catch (err) {
      this.notify('Lỗi trả nhiệm vụ: ' + err.message, 'error');
    }
  }

  openQuestNarrativeModal(title, lines) {
    const modal = document.getElementById('event-modal');
    if (!modal) return;

    document.getElementById('modal-event-title').textContent = title;
    modal.classList.add('open');

    this.streamNarrativeLines(lines, () => {
      const choicesContainer = document.getElementById('modal-event-choices');
      choicesContainer.innerHTML = `
        <button class="btn-primary-glow" onclick="window.engine.closeEventModal()">
          Lĩnh Ý &amp; Tiếp Tục Hành Trình
        </button>
      `;
    });
  }

  // ====================================================
  // 13. HỆ THỐNG THÁM HIỂM TIÊU CỤC GIANG HỒ (AGENCY EXPLORATION SYSTEM)
  // ====================================================
  async fetchAgencyData() {
    try {
      const res = await fetch(
        `${this.apiBase}/api/xianxia/agency/view?userId=${encodeURIComponent(this.player.name)}&zoneId=${encodeURIComponent(this.player.zone_id)}&realm=${encodeURIComponent(this.player.realm)}&level=1`
      );
      const json = await res.json();
      if (json.success && json.data) {
        this.agencyData = json.data;
        this.renderAgencyMissionTrackerHud();
        this.updateAgencyBadges();
        if (this.activeMainTab === 'agency') {
          this.renderAgencyView();
        }
      }
    } catch (err) {
      console.warn('Lỗi khi tải thông tin Tiêu Cục:', err);
    }
  }

  updateAgencyBadges() {
    const navBadge = document.getElementById('nav-agency-badge');
    if (!navBadge || !this.agencyData) return;

    const isPromo = this.agencyData.promotion && this.agencyData.promotion.isEligible;
    const isReady = this.agencyData.activeMission && (
      this.agencyData.activeMission.status === 'READY_TO_REPORT' || 
      this.agencyData.activeMission.status === 'READY_TO_DELIVER'
    );
    if (isPromo || isReady) {
      navBadge.style.display = 'flex';
      navBadge.textContent = isPromo ? '★' : '!';
    } else {
      navBadge.style.display = 'none';
    }
  }

  renderAgencyMissionTrackerHud() {
    const hud = document.getElementById('agency-mission-tracker-hud');
    if (!hud) return;

    if (!this.agencyData || !this.agencyData.activeMission) {
      hud.style.display = 'none';
      return;
    }

    hud.style.display = 'flex';
    const m = this.agencyData.activeMission;
    const badgeEl = document.getElementById('tracker-agency-badge');
    const titleEl = document.getElementById('tracker-agency-title');
    const statusEl = document.getElementById('tracker-agency-status');

    const kindIcons = {
      ESCORT: '🛡️ ÁP TIÊU',
      COURIER: '✉️ PHI TIÊU',
      HUNT: '⚔️ THẢO PHẠT',
      GATHERING: '🌿 QUÂN NHU',
      EVENT: '🔮 ĐIỀU TRA',
    };

    if (badgeEl) {
      badgeEl.textContent = kindIcons[m.kind] || '🛡️ TIÊU CỤC';
      badgeEl.className = `tracker-badge kind-pill ${m.kind}`;
    }
    if (titleEl) {
      titleEl.textContent = m.name;
    }
    if (statusEl) {
      if (m.status === 'READY_TO_DELIVER') {
        statusEl.textContent = '🎉 ĐÃ ĐẾN NƠI - SẴN SÀNG GIAO HÀNG!';
        statusEl.style.color = '#34d399';
      } else if (m.status === 'READY_TO_REPORT') {
        statusEl.textContent = '🎉 ĐÃ HOÀN TẤT - SẴN SÀNG BÁO CÁO!';
        statusEl.style.color = '#34d399';
      } else {
        if (m.kind === 'ESCORT') {
          statusEl.textContent = `Hộ tống [${m.cargo_name}] → [${m.destination_name}] (Nguy cơ cướp tiêu: ${m.escort_risk_percent}%)`;
        } else if (m.kind === 'COURIER') {
          statusEl.textContent = `Chuyển thư hỏa tốc → [${m.destination_name}]`;
        } else if (m.kind === 'HUNT') {
          statusEl.textContent = `Tiến độ: Săn ${m.currentCount || 0}/${m.target?.required_count || 1} ${m.target?.monster_name || 'yêu thú'}`;
        } else if (m.kind === 'GATHERING') {
          statusEl.textContent = `Tiến độ: Giao nộp ${m.currentCount || 0}/${m.input?.quantity || 1} ${m.input?.item_name || 'nguyên liệu'}`;
        } else if (m.kind === 'EVENT') {
          statusEl.textContent = `Thám hiểm phân khu [${m.origin_name}] để điều tra dị tượng`;
        }
        statusEl.style.color = '#fde047';
      }
    }
  }

  openAgencyDrawer() {
    const modal = document.getElementById('agency-drawer-modal');
    if (!modal) return;
    modal.classList.add('open');

    const content = document.getElementById('drawer-mission-content');
    if (!content) return;

    if (!this.agencyData || !this.agencyData.activeMission) {
      content.innerHTML = `
        <div style="text-align: center; padding: 20px 10px; color: #94a3b8;">
          <div style="font-size: 2.2rem; margin-bottom: 8px;">📜</div>
          <div style="font-size: 0.95rem; font-weight: 700; color: #f8fafc; margin-bottom: 6px;">
            Hiện không có chuyến tiêu thám hiểm nào đang thực thi
          </div>
          <p style="font-size: 0.8rem; margin-bottom: 16px;">
            Đạo hữu hãy ghé thăm Bảng Ủy Thác Tiêu Cục để nhận áp tiêu, phi tiêu hỏa tốc hoặc thảo phạt dị thú.
          </p>
          <button class="btn-primary-glow" onclick="window.engine.closeAgencyDrawer(); window.engine.setTab('agency');">
            🛡️ Đến Bảng Tiêu Cục Tiếp Nhận
          </button>
        </div>
      `;
      return;
    }

    const m = this.agencyData.activeMission;
    const kindLabels = {
      ESCORT: '🛡️ ÁP TIÊU (HỘ TỐNG)',
      COURIER: '✉️ PHI TIÊU (HỎA TỐC)',
      HUNT: '⚔️ THẢO PHẠT DỊ THÚ',
      GATHERING: '🌿 QUÂN NHU TIẾP TẾ',
      EVENT: '🔮 ĐIỀU TRA KỲ NGỘ',
    };

    const isReady = m.status === 'READY_TO_REPORT' || m.status === 'READY_TO_DELIVER';

    let actionBtnHtml = '';
    if (isReady) {
      const label = m.status === 'READY_TO_DELIVER' ? 'Giao Hàng &amp; Nhận Thù Lao 🎁' : 'Báo Cáo Thành Tích &amp; Lĩnh Thưởng 🎁';
      actionBtnHtml = `
        <button class="btn-primary-glow" style="width: 100%; padding: 10px;" onclick="window.engine.deliverOrReportAgencyMission('${m.id}')">
          ${label}
        </button>
      `;
    } else {
      let guideBtn = '';
      if (m.kind === 'ESCORT' || m.kind === 'COURIER') {
        guideBtn = `
          <button class="btn-primary-glow" style="flex: 1;" onclick="window.engine.closeAgencyDrawer(); window.engine.travelToZone('${m.destination_zone_id}')">
            🧭 Lên Đường Đến ${m.destination_name}
          </button>
        `;
      } else if (m.kind === 'HUNT') {
        guideBtn = `
          <button class="btn-primary-glow" style="flex: 1;" onclick="window.engine.closeAgencyDrawer(); window.engine.setTab('bestiary')">
            ⚔️ Đến Khu Trảm Yêu
          </button>
        `;
      } else if (m.kind === 'GATHERING') {
        guideBtn = `
          <button class="btn-primary-glow" style="flex: 1;" onclick="window.engine.closeAgencyDrawer(); window.engine.setTab('gathering')">
            🌿 Đến Vùng Thu Thập
          </button>
        `;
      } else if (m.kind === 'EVENT') {
        guideBtn = `
          <button class="btn-primary-glow" style="flex: 1;" onclick="window.engine.closeAgencyDrawer(); window.engine.exploreCurrentZone()">
            🧭 Thám Hiểm Ngay
          </button>
        `;
      }

      actionBtnHtml = `
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
          ${guideBtn}
          <button class="btn-secondary" style="color: #f87171; border-color: rgba(239, 68, 68, 0.4);" onclick="window.engine.cancelAgencyMission()">
            Hủy Chuyến ✕
          </button>
        </div>
      `;
    }

    content.innerHTML = `
      <div style="display: flex; justify-content: space-between; align-items: center;">
        <span class="kind-pill ${m.kind}">${kindLabels[m.kind] || m.kind}</span>
        <span style="font-size: 0.75rem; color: #94a3b8;">Nhận lúc: ${m.acceptedAt ? new Date(m.acceptedAt).toLocaleTimeString() : 'Gần đây'}</span>
      </div>

      <div style="font-family: var(--font-serif); font-size: 1.15rem; color: #f8fafc; font-weight: 700;">
        ${m.name}
      </div>

      <p style="font-size: 0.85rem; color: #cbd5e1; line-height: 1.5; margin: 0;">
        ${m.description}
      </p>

      <!-- TIẾN ĐỘ & CHI TIẾT -->
      <div style="background: rgba(0, 0, 0, 0.3); border: 1px solid var(--border-subtle); border-radius: var(--radius-sm); padding: 10px 12px; display: flex; flex-direction: column; gap: 6px; font-size: 0.8rem;">
        <div><b>Xuất phát:</b> ${m.origin_name}</div>
        <div><b>Đích đến:</b> ${m.destination_name}</div>
        ${m.cargo_name ? `<div><b>Kiện hàng:</b> <span style="color: #fbbf24;">${m.cargo_name}</span></div>` : ''}
        ${m.escort_risk_percent ? `<div><b>Nguy cơ cướp bóc:</b> <span style="color: #f87171;">${m.escort_risk_percent}%</span></div>` : ''}
        ${m.target ? `<div><b>Mục tiêu:</b> Trảm sát ${m.currentCount || 0}/${m.target.required_count} ${m.target.monster_name}</div>` : ''}
        ${m.input ? `<div><b>Thu nạp:</b> Cung ứng ${m.currentCount || 0}/${m.input.quantity} ${m.input.item_name}</div>` : ''}
        <div style="margin-top: 4px; color: ${isReady ? '#34d399' : '#38bdf8'}; font-weight: 700;">
          Trạng thái: ${isReady ? 'ĐÃ HOÀN TẤT ĐIỀU KIỆN' : 'ĐANG THỰC HIỆN'}
        </div>
      </div>

      <!-- PHẦN THƯỞNG -->
      <div>
        <div style="font-size: 0.76rem; color: #94a3b8; text-transform: uppercase; margin-bottom: 6px; font-weight: 700;">
          Thù Lao &amp; Công Trạng:
        </div>
        <div class="quest-rewards-row" style="margin-top: 0;">
          <span class="reward-pill" style="background: rgba(16, 185, 129, 0.2); border-color: rgba(16, 185, 129, 0.5); color: #6ee7b7;">
            🎖️ Công Trạng +${m.rewards.merit}
          </span>
          <span class="reward-pill" style="background: rgba(59, 130, 246, 0.2); border-color: rgba(59, 130, 246, 0.5); color: #93c5fd;">
            🪙 Tiêu Cục Tệ +${m.rewards.credits}
          </span>
          <span class="reward-pill silver">
            Bạc +${m.rewards.silver}
          </span>
          ${m.rewards.cultivation ? `<span class="reward-pill cult">Tu vi +${m.rewards.cultivation}</span>` : ''}
          ${m.rewards.exp ? `<span class="reward-pill exp">EXP +${m.rewards.exp}</span>` : ''}
        </div>
      </div>

      <div style="margin-top: 6px;">
        ${actionBtnHtml}
      </div>
    `;
  }

  closeAgencyDrawer() {
    const modal = document.getElementById('agency-drawer-modal');
    if (modal) modal.classList.remove('open');
  }

  async advanceAgencyMission(actionType, payload = {}) {
    try {
      const res = await fetch(`${this.apiBase}/api/xianxia/agency/action`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: this.player.name,
          actionType,
          payload,
        }),
      });
      const json = await res.json();
      if (json.success && json.data) {
        if (json.data.eventTriggered) {
          const ev = json.data.eventTriggered;
          if (ev.damageTaken) {
            this.player.health = Math.max(1, this.player.health - ev.damageTaken);
          }
          if (ev.cultivationAward) {
            this.addCultivation(ev.cultivationAward);
          }
          this.log(`[Cướp Tiêu] ${ev.title}: ${ev.description}`, 'warning');
          this.notify(ev.title, 'warning');
          this.savePlayerState();
          this.renderPlayerStats();
        }
        await this.fetchAgencyData();
      }
    } catch (e) {
      console.warn('Lỗi cập nhật tiến trình thám hiểm Tiêu Cục:', e);
    }
  }

  async acceptAgencyMission(missionId) {
    try {
      const res = await fetch(`${this.apiBase}/api/xianxia/agency/accept`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: this.player.name,
          missionId,
          playerStats: this.getExplorationStats(),
        }),
      });
      const json = await res.json();
      if (!json.success) {
        this.notify(json.message || 'Không thể nhận chuyến tiêu!', 'error');
        return;
      }

      this.notify(json.message, 'success');
      this.log(`[Tiêu Cục] Tiếp nhận chuyến tiêu [${json.mission?.name || missionId}]`, 'success');
      await this.fetchAgencyData();

      if (json.intro_lines && json.intro_lines.length > 0) {
        this.openQuestNarrativeModal(`🛡️ TIẾP NHẬN: ${json.mission?.name}`, json.intro_lines);
      }
    } catch (err) {
      this.notify('Lỗi tiếp nhận: ' + err.message, 'error');
    }
  }

  async deliverOrReportAgencyMission(missionId) {
    try {
      const res = await fetch(`${this.apiBase}/api/xianxia/agency/report`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: this.player.name,
          missionId,
          currentZoneId: this.player.zone_id,
          inventory: this.player.inventory,
        }),
      });
      const json = await res.json();
      if (!json.success) {
        this.notify(json.message || 'Chưa đủ điều kiện hoàn thành!', 'error');
        return;
      }

      const rw = json.rewards;
      if (rw) {
        if (rw.silver) this.player.silver += rw.silver;
        if (rw.cultivation) this.addCultivation(rw.cultivation);
        if (rw.exp) this.player.exp = (this.player.exp || 0) + rw.exp;
        if (rw.items && rw.items.length > 0) {
          for (const it of rw.items) {
            this.addItemToInventory(it.item_id, it.quantity);
          }
        }
      }

      // Trừ vật phẩm nguyên liệu nếu là GATHERING
      if (this.agencyData?.activeMission?.kind === 'GATHERING' && this.agencyData.activeMission.input) {
        const inp = this.agencyData.activeMission.input;
        this.removeItemFromInventory(inp.item_id, inp.quantity);
      }

      this.savePlayerState();
      this.renderPlayerStats();
      this.renderInventory();
      this.closeAgencyDrawer();
      await this.fetchAgencyData();

      this.notify(json.message, 'success');
      this.log(`[Tiêu Cục] ${json.message}`, 'success');

      const narrativeLines = json.turnin_lines || [json.message];
      narrativeLines.push(
        `✦ Thù lao hoàn thành: +${rw.merit} Công Trạng | +${rw.credits} Tiêu Cục Tệ | +${rw.silver} Bạc${rw.cultivation ? ` | +${rw.cultivation} Tu Vi` : ''}`
      );

      this.openQuestNarrativeModal('🏆 HOÀN THÀNH CHUYẾN TIÊU', narrativeLines);
    } catch (err) {
      this.notify('Lỗi hoàn thành chuyến tiêu: ' + err.message, 'error');
    }
  }

  async promoteAgencyRank() {
    try {
      const res = await fetch(`${this.apiBase}/api/xianxia/agency/promote`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: this.player.name,
        }),
      });
      const json = await res.json();
      if (!json.success) {
        this.notify(json.message || 'Không thể thăng cấp Tiêu Sư!', 'error');
        return;
      }

      if (json.stipendSilver) {
        this.player.silver += json.stipendSilver;
        this.log(`Nhận bổng lộc thăng cấp: +${json.stipendSilver} Bạc.`, 'success');
      }

      this.savePlayerState();
      this.renderPlayerStats();
      await this.fetchAgencyData();

      this.notify(json.message, 'success');
      this.openQuestNarrativeModal(
        `🎖️ SẮC PHONG: ${json.newRank?.name || 'TIÊU SƯ'}`,
        json.celebration_lines || [json.message]
      );
    } catch (err) {
      this.notify('Lỗi thăng cấp: ' + err.message, 'error');
    }
  }

  async exchangeAgencySupply(supplyId) {
    try {
      const res = await fetch(`${this.apiBase}/api/xianxia/agency/exchange`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: this.player.name,
          supplyId,
        }),
      });
      const json = await res.json();
      if (!json.success) {
        this.notify(json.message || 'Không thể đổi vật phẩm!', 'error');
        return;
      }

      this.addItemToInventory(json.item.item_id, json.item.quantity);
      this.savePlayerState();
      this.renderInventory();
      await this.fetchAgencyData();

      this.notify(json.message, 'success');
      this.log(`[Kho Quân Nhu] ${json.message}`, 'success');
    } catch (err) {
      this.notify('Lỗi đổi quân nhu: ' + err.message, 'error');
    }
  }

  async cancelAgencyMission() {
    if (!confirm('Đạo hữu có chắc muốn hủy chuyến thám hiểm này không? Tiến độ hiện tại sẽ bị hủy bỏ.')) {
      return;
    }

    try {
      const res = await fetch(`${this.apiBase}/api/xianxia/agency/cancel`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: this.player.name,
        }),
      });
      const json = await res.json();
      if (!json.success) {
        this.notify(json.message || 'Không thể hủy chuyến tiêu!', 'error');
        return;
      }

      this.notify(json.message, 'info');
      this.closeAgencyDrawer();
      await this.fetchAgencyData();
    } catch (err) {
      this.notify('Lỗi hủy chuyến tiêu: ' + err.message, 'error');
    }
  }

  renderAgencyView() {
    const view = document.getElementById('main-tab-view');
    if (!view) return;

    if (!this.agencyData) {
      view.innerHTML = `
        <div style="text-align: center; padding: 40px; color: #94a3b8;">
          Đang nạp dữ liệu Tiêu Cục Giang Hồ...
        </div>
      `;
      return;
    }

    const { organization, membership, promotion, activeMission, offers, supplyHall } = this.agencyData;

    // Promotion button / card logic
    let promoCardHtml = '';
    if (promotion) {
      if (promotion.isEligible) {
        promoCardHtml = `
          <div style="display: flex; align-items: center; justify-content: space-between; background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.4); border-radius: var(--radius-sm); padding: 10px 14px;">
            <div>
              <div style="color: #6ee7b7; font-weight: 700; font-size: 0.88rem;">✨ Đủ điều kiện thăng cấp: [${promotion.targetRankName}]</div>
              <div style="font-size: 0.75rem; color: #cbd5e1;">Hoàn thành ${promotion.targetMissions} chuyến tiêu &amp; ${promotion.targetMerit} Công trạng.</div>
            </div>
            <button class="btn-agency-promote" onclick="window.engine.promoteAgencyRank()">
              🎖️ Thăng Cấp Ngay
            </button>
          </div>
        `;
      } else {
        promoCardHtml = `
          <div style="display: flex; align-items: center; justify-content: space-between; background: rgba(0, 0, 0, 0.3); border: 1px solid var(--border-subtle); border-radius: var(--radius-sm); padding: 10px 14px;">
            <div>
              <div style="color: #94a3b8; font-weight: 700; font-size: 0.82rem;">Mục tiêu tiếp theo: [${promotion.targetRankName}]</div>
              <div style="font-size: 0.74rem; color: #f87171;">Yêu cầu: ${promotion.missingReasons.join(' • ')}</div>
            </div>
            <button class="btn-agency-promote disabled" disabled title="${promotion.missingReasons.join(', ')}">
              🔒 Chưa Đủ ĐK
            </button>
          </div>
        `;
      }
    } else {
      promoCardHtml = `
        <div style="text-align: center; padding: 6px; color: #fbbf24; font-weight: 700; font-size: 0.82rem;">
          👑 Đạo Hữu đã đạt phẩm cấp Tiêu Sư Tối Cao của Thiên Cơ Các!
        </div>
      `;
    }

    // Active Mission Card (if any)
    let activeCardHtml = '';
    if (activeMission) {
      const isReady = activeMission.status === 'READY_TO_REPORT' || activeMission.status === 'READY_TO_DELIVER';
      activeCardHtml = `
        <div style="background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(6, 78, 59, 0.25)); border: 1px solid rgba(16, 185, 129, 0.5); border-radius: var(--radius-md); padding: 14px 16px; margin-bottom: 12px; display: flex; flex-direction: column; gap: 8px;">
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <div style="display: flex; align-items: center; gap: 8px;">
              <span class="kind-pill ${activeMission.kind}">${this.getMissionKindName(activeMission.kind)}</span>
              <span style="font-weight: 700; color: #f8fafc; font-family: var(--font-serif);">${activeMission.name}</span>
            </div>
            <button class="btn-tracker-open" style="background: rgba(16, 185, 129, 0.2); border-color: rgba(16, 185, 129, 0.5); color: #a7f3d0;" onclick="window.engine.openAgencyDrawer()">
              Chi Tiết / Thao Tác ↗
            </button>
          </div>
          <div style="font-size: 0.8rem; color: #cbd5e1;">${activeMission.description}</div>
          <div style="font-size: 0.78rem; font-weight: 700; color: ${isReady ? '#34d399' : '#fde047'};">
            ${isReady ? '🎉 Đã hoàn tất mục tiêu! Nhấp nút trên để báo cáo hoàn thành.' : `Đang thực thi: Từ [${activeMission.origin_name}] đến [${activeMission.destination_name}]`}
          </div>
        </div>
      `;
    }

    // Build Offers Grid
    const offersHtml = (offers || [])
      .map(o => {
        let actionBtn = '';
        if (o.status === 'ACCEPTED') {
          actionBtn = `<button class="btn-quest-action" onclick="window.engine.openAgencyDrawer()">⏳ Đang Thi Hành (Xem)</button>`;
        } else if (o.status === 'AVAILABLE') {
          actionBtn = `<button class="btn-quest-action" onclick="window.engine.acceptAgencyMission('${o.id}')">Tiếp Nhận Chuyến Tiêu 🛡️</button>`;
        } else if (o.status === 'UNAVAILABLE_RANK') {
          actionBtn = `<button class="btn-quest-action locked" disabled>🔒 ${o.reason}</button>`;
        } else if (o.status === 'ACTIVE_ELSEWHERE') {
          actionBtn = `<button class="btn-quest-action locked" disabled>Đang bận chuyến khác</button>`;
        }

        return `
          <div class="agency-offer-card">
            <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 8px;">
              <span class="kind-pill ${o.kind}">${this.getMissionKindName(o.kind)}</span>
              <span style="font-size: 0.72rem; color: #94a3b8;">${o.origin_name} → ${o.destination_name}</span>
            </div>
            <div style="font-family: var(--font-serif); font-weight: 700; color: #f8fafc; font-size: 0.95rem;">
              ${o.name}
            </div>
            <div style="font-size: 0.78rem; color: #94a3b8; line-height: 1.4;">
              ${o.description}
            </div>
            ${o.cargo_name ? `<div style="font-size: 0.75rem; color: #fbbf24;">📦 Kiện hàng: ${o.cargo_name} (${o.escort_risk_percent}% nguy cơ)</div>` : ''}
            ${o.target ? `<div style="font-size: 0.75rem; color: #fca5a5;">🎯 Yêu thú: ${o.target.monster_name} x${o.target.required_count}</div>` : ''}
            ${o.input ? `<div style="font-size: 0.75rem; color: #6ee7b7;">🌿 Quân nhu: ${o.input.item_name} x${o.input.quantity}</div>` : ''}
            
            <div class="quest-rewards-row" style="margin-top: 4px;">
              <span class="reward-pill" style="background: rgba(16, 185, 129, 0.15); color: #6ee7b7; border-color: rgba(16, 185, 129, 0.4);">
                +${o.rewards.merit} Công Trạng
              </span>
              <span class="reward-pill" style="background: rgba(59, 130, 246, 0.15); color: #93c5fd; border-color: rgba(59, 130, 246, 0.4);">
                +${o.rewards.credits} Tệ
              </span>
              <span class="reward-pill silver">+${o.rewards.silver} Bạc</span>
              ${o.rewards.cultivation ? `<span class="reward-pill cult">+${o.rewards.cultivation} Tu Vi</span>` : ''}
            </div>

            <div style="margin-top: auto; padding-top: 6px;">
              ${actionBtn}
            </div>
          </div>
        `;
      })
      .join('');

    // Build Supply Hall Grid
    const supplyHtml = (supplyHall || [])
      .map(s => {
        let btn = '';
        if (!s.isUnlocked) {
          btn = `<button class="btn-exchange disabled" disabled>🔒 Cần cấp ${this.getRankName(s.min_rank)}</button>`;
        } else if (!s.canAfford) {
          btn = `<button class="btn-exchange disabled" disabled>Thiếu Tệ (${membership.credits}/${s.credit_cost})</button>`;
        } else {
          btn = `<button class="btn-exchange" onclick="window.engine.exchangeAgencySupply('${s.id}')">Đổi Lấy (x${s.quantity_per_exchange}) 🎁</button>`;
        }

        return `
          <div class="supply-card ${s.isUnlocked ? '' : 'locked'}">
            <div style="display: flex; justify-content: space-between; align-items: center;">
              <span style="font-weight: 700; color: #f8fafc; font-size: 0.88rem;">${s.item_name}</span>
              <span style="font-size: 0.78rem; font-weight: 700; color: #93c5fd;">🪙 ${s.credit_cost} Tệ</span>
            </div>
            <div style="font-size: 0.74rem; color: #94a3b8; line-height: 1.3;">
              ${s.description}
            </div>
            <div style="font-size: 0.72rem; color: #6ee7b7;">
              Tác dụng: ${s.effects_summary}
            </div>
            <div style="margin-top: auto; padding-top: 6px;">
              ${btn}
            </div>
          </div>
        `;
      })
      .join('');

    view.innerHTML = `
      <div class="agency-container">
        <!-- BANNER TỔ CHỨC & BẬC TIÊU SƯ -->
        <div class="agency-banner-card">
          <div class="agency-header-row">
            <div>
              <div style="font-family: var(--font-serif); font-size: 1.25rem; font-weight: 700; color: #f8fafc; display: flex; align-items: center; gap: 8px;">
                <span>🛡️ ${organization.name}</span>
                <span class="agency-rank-badge">${membership.rankName}</span>
              </div>
              <div style="font-size: 0.8rem; color: #94a3b8; margin-top: 2px;">${organization.subtitle}</div>
            </div>

            <!-- STATS PILL GROUP -->
            <div class="agency-stats-pill-group">
              <div class="agency-stat-pill">🎖️ Công Trạng: <b>${membership.merit}</b></div>
              <div class="agency-stat-pill">🪙 Tiêu Cục Tệ: <b>${membership.credits}</b></div>
              <div class="agency-stat-pill">📦 Đã Giao: <b>${membership.totalCompleted}</b></div>
              <div class="agency-stat-pill">🎯 Loại: <b>${membership.distinctKinds}/5</b></div>
            </div>
          </div>

          <div style="font-size: 0.82rem; color: #cbd5e1; line-height: 1.5;">
            ${organization.description}
          </div>

          ${promoCardHtml}
        </div>

        <!-- ACTIVE EXPEDITION IF ANY -->
        ${activeCardHtml}

        <!-- DANH SÁCH ỦY THÁC TẠI PHÂN KHU -->
        <div class="section-box" style="margin-top: 0;">
          <div class="quest-category-title main" style="margin-bottom: 8px;">
            <span>📋 BẢNG ỦY THÁC THÁM HIỂM (KHU VỰC HIỆN TẠI)</span>
          </div>
          <div class="agency-offers-grid">
            ${offersHtml || '<div class="empty-hint">Hiện không có ủy thác nào tại phân khu này.</div>'}
          </div>
        </div>

        <!-- KHO QUÂN NHU TIẾP TẾ -->
        <div class="section-box" style="margin-top: 0;">
          <div class="quest-category-title side" style="margin-bottom: 8px;">
            <span>🏛️ KHO QUÂN NHU TIẾP TẾ TIÊU CỤC (QUY ĐỔI TIÊU CỤC TỆ)</span>
          </div>
          <div class="supply-hall-grid">
            ${supplyHtml}
          </div>
        </div>
      </div>
    `;
  }
}

// Khởi tạo engine toàn cục khi trang tải xong
window.addEventListener('DOMContentLoaded', () => {
  window.engine = new TienLoEngine();
  window.engine.init();
});
