/**
 * Kỳ Biến Platform Client Script (kybien-client.js)
 * Dành riêng cho kybien.blogspot.com & Replay Viewer
 * Hỗ trợ 4 Thể Loại Cờ: Cờ Thường (n), Cờ Úp Truyền Thống (t), Cờ Úp Gián Điệp (g), Cờ Kỳ Biến (kb)
 */

(function () {
  // Production Backend URL trên Render
  const SERVER_URL = 'https://kybien-backend.onrender.com';

  // FR-06: Silent Wake-up ngầm khi DOMContentLoaded
  document.addEventListener('DOMContentLoaded', () => {
    console.log('[Kỷ Biến Client] Kích hoạt Silent Wake-up tới Server Render...');
    fetch(`${SERVER_URL}/ping`, { mode: 'no-cors' }).catch(() => {});

    // Khởi tạo Widget Header Profile
    initHeaderProfileWidget();

    // Khởi tạo 3 khối động Trang Chủ: Hồ Sơ, Top ELO, Phòng Đấu Trực Tiếp
    initUserProfileSection();
    initTopEloLeaderboard();
    initLiveRoomsWidget();

    // Khởi tạo Replay Viewer
    window.KybienViewer.init();

    // Dọn dẹp đoạn trích trang chủ nếu dính chữ nút bấm bàn cờ
    cleanPostSnippets();

    // Đảm bảo responsive mobile cho các bài viết (1 cột, không cố định bàn cờ)
    applyMobilePostResponsive();
    window.addEventListener('resize', applyMobilePostResponsive);

    // Khởi tạo hiển thị số người online chân trang (Tề tựu: ... vị (... Kỳ thủ • ... Lữ khách))
    initOnlineFooterWidget();
  });

  function applyMobilePostResponsive() {
    const isMobile = window.innerWidth <= 900;
    if (isMobile) {
      document.querySelectorAll('.sticky-board-col').forEach((el) => {
        el.style.setProperty('position', 'static', 'important');
        el.style.setProperty('top', 'auto', 'important');
        el.style.setProperty('max-width', '100%', 'important');
        el.style.setProperty('width', '100%', 'important');
      });
      document.querySelectorAll('.kybien-post-layout').forEach((el) => {
        el.style.setProperty('flex-direction', 'column', 'important');
      });
      document.querySelectorAll('.scrollable-story-col').forEach((el) => {
        el.style.setProperty('width', '100%', 'important');
        el.style.setProperty('max-width', '100%', 'important');
      });
    } else {
      document.querySelectorAll('.sticky-board-col').forEach((el) => {
        el.style.removeProperty('position');
        el.style.removeProperty('top');
        el.style.removeProperty('max-width');
        el.style.removeProperty('width');
      });
      document.querySelectorAll('.kybien-post-layout').forEach((el) => {
        el.style.removeProperty('flex-direction');
      });
      document.querySelectorAll('.scrollable-story-col').forEach((el) => {
        el.style.removeProperty('width');
        el.style.removeProperty('max-width');
      });
    }
  }

  function cleanPostSnippets() {
    document.querySelectorAll('.post-card-snippet').forEach((el) => {
      let txt = (el.innerText || el.textContent || '').trim();
      const summaryIdx = txt.indexOf('Tóm tắt ván cờ:');
      if (summaryIdx !== -1) {
        txt = '🎯 ' + txt.slice(summaryIdx).trim();
      } else if (txt.includes('Vào Sàn Đấu') || txt.includes('Bí Pháp Cẩm Nang')) {
        txt = txt.replace(/^⚔️[^\n\r]+?📜\s*Bí Pháp Cẩm Nang\s*/i, '')
                 .replace(/^⚔️[^\n\r]+?➔\s*/i, '').trim();
      }
      txt = txt.replace(/⏩\s*Đầu|◀\s*Lùi|Tiến\s*▶|Cuối\s*⏩|🔴\s*Nước\s*\d+.*$/gi, '').trim();
      if (txt && txt !== '...') el.textContent = txt;
    });

    // Lấy nội dung tóm tắt đầy đủ 100% từ Blogger JSON Feed cho mọi bài viết (kể cả bài cũ)
    fetchFullPostSummaries();
  }

  function fetchFullPostSummaries() {
    const cards = document.querySelectorAll('.post-card');
    if (!cards.length) return;

    const urlToCard = {};
    cards.forEach((card) => {
      const link = card.querySelector('.post-card-title a') || card.querySelector('.btn-read-post');
      if (link && link.getAttribute('href')) {
        try {
          const u = new URL(link.getAttribute('href'), window.location.origin);
          urlToCard[u.pathname] = card;
        } catch (e) {}
      }
    });

    fetch('/feeds/posts/default?alt=json&max-results=30')
      .then((res) => res.json())
      .then((data) => {
        if (!data || !data.feed || !data.feed.entry) return;
        data.feed.entry.forEach((entry) => {
          const altLink = (entry.link || []).find((l) => l.rel === 'alternate');
          if (!altLink || !altLink.href) return;
          try {
            const postPath = new URL(altLink.href).pathname;
            const targetCard = urlToCard[postPath];
            if (targetCard) {
              const content = (entry.content && entry.content.$t) || '';
              const m = content.match(/kybien-post-summary-text[^>]*>([\s\S]*?)<\/p>/i);
              if (m && m[1]) {
                let clean = m[1].replace(/<[^>]*>/g, '').replace(/[\r\n]+/g, ' ').trim();
                if (!clean.startsWith('🎯')) clean = '🎯 Tóm tắt ván cờ: ' + clean;
                const snippetEl = targetCard.querySelector('.post-card-snippet');
                if (snippetEl) {
                  snippetEl.textContent = clean;
                }
              }
            }
          } catch (e) {}
        });
      })
      .catch(() => {});
  }

  function updateOnlineStatsUI(stats) {
    if (!stats) return;
    const textEls = document.querySelectorAll('#online-stats-text');
    const total = stats.total ?? 0;
    const members = stats.members ?? 0;
    const guests = stats.guests ?? 0;
    const htmlStr = `Tề tựu: <b>${total}</b> vị (<b>${members}</b> Kỳ thủ • <b>${guests}</b> Lữ khách)`;
    textEls.forEach((el) => {
      el.innerHTML = htmlStr;
    });
  }

  function initOnlineFooterWidget() {
    // 1. Fetch REST API để cập nhật tức thì khi tải trang
    fetch(SERVER_URL + '/api/stats/online')
      .then((res) => res.json())
      .then((data) => {
        if (data && data.success && data.data) {
          updateOnlineStatsUI(data.data);
        }
      })
      .catch(() => {});

    // 2. Lắng nghe real-time qua Socket
    if (typeof io !== 'undefined') {
      const token = localStorage.getItem('kybien_jwt_token') || '';
      try {
        const clientSocket = io(SERVER_URL, {
          auth: { token },
          transports: ['websocket', 'polling'],
        });
        clientSocket.on('online_stats', (stats) => {
          updateOnlineStatsUI(stats);
        });
        window._kybienGlobalSocket = clientSocket;
      } catch (e) {
        console.warn('[Online Tracker Socket]', e);
      }
    }
  }

  // Helper chờ phần tử DOM xuất hiện (chống Race Condition với Blogger Gadgets)
  function waitForElem(id, callback, maxRetries = 20, delayMs = 250) {
    let count = 0;
    function check() {
      const el = document.getElementById(id);
      if (el) {
        callback(el);
      } else if (count < maxRetries) {
        count++;
        setTimeout(check, delayMs);
      } else {
        console.warn(`[Kỷ Biến Client] Phần tử #${id} không tìm thấy sau ${maxRetries * delayMs}ms.`);
      }
    }
    check();
  }

  function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  // Central Auth & Profile Session Manager
  window.KybienAuth = {
    cachedUser: null,
    isFetching: false,

    getToken: function () {
      return localStorage.getItem('kybien_jwt_token');
    },

    setToken: function (token) {
      if (token) {
        localStorage.setItem('kybien_jwt_token', token);
        if (window._kybienGlobalSocket) {
          window._kybienGlobalSocket.emit('auth_identify', token);
        }
      } else {
        localStorage.removeItem('kybien_jwt_token');
      }
      this.cachedUser = null;
      this.fetchProfile();
    },

    clearToken: function () {
      localStorage.removeItem('kybien_jwt_token');
      this.cachedUser = null;
      this.renderGuestUI();
    },

    logout: function () {
      this.clearToken();
      if (typeof window.checkAuthUI === 'function') {
        window.checkAuthUI();
      }
    },

    handleLogin: async function () {
      const uEl = document.getElementById('hdr-auth-u');
      const pEl = document.getElementById('hdr-auth-p');
      const errEl = document.getElementById('hdr-auth-err');
      if (!uEl || !pEl) return;
      const username = uEl.value.trim();
      const password = pEl.value;
      if (!username || !password) {
        if (errEl) { errEl.innerText = 'Vui lòng nhập Tên và Mật khẩu!'; errEl.style.display = 'block'; }
        return;
      }
      if (errEl) { errEl.innerText = 'Đang đăng nhập...'; errEl.style.color = '#f1c40f'; errEl.style.display = 'block'; }
      try {
        const res = await fetch(`${SERVER_URL}/api/auth/login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ usernameOrEmail: username, password })
        });
        const data = await res.json();
        if (res.ok && data.token) {
          this.setToken(data.token);
          if (typeof window.checkAuthUI === 'function') window.checkAuthUI();
        } else {
          if (errEl) { errEl.innerText = data.error || 'Sai tên đăng nhập hoặc mật khẩu!'; errEl.style.color = '#ff6b6b'; errEl.style.display = 'block'; }
        }
      } catch (e) {
        if (errEl) { errEl.innerText = 'Lỗi kết nối máy chủ!'; errEl.style.color = '#ff6b6b'; errEl.style.display = 'block'; }
      }
    },

    handleRegister: async function () {
      const uEl = document.getElementById('hdr-auth-u');
      const pEl = document.getElementById('hdr-auth-p');
      const errEl = document.getElementById('hdr-auth-err');
      if (!uEl || !pEl) return;
      const username = uEl.value.trim();
      const password = pEl.value;
      if (!username || !password) {
        if (errEl) { errEl.innerText = 'Vui lòng nhập Tên và Mật khẩu!'; errEl.style.display = 'block'; }
        return;
      }
      if (errEl) { errEl.innerText = 'Đang tạo tài khoản...'; errEl.style.color = '#f1c40f'; errEl.style.display = 'block'; }
      try {
        const res = await fetch(`${SERVER_URL}/api/auth/register`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username, email: username + '@kybien.com', password })
        });
        const data = await res.json();
        if (res.ok && data.token) {
          this.setToken(data.token);
          if (typeof window.checkAuthUI === 'function') window.checkAuthUI();
        } else {
          if (errEl) { errEl.innerText = data.error || 'Đăng ký thất bại!'; errEl.style.color = '#ff6b6b'; errEl.style.display = 'block'; }
        }
      } catch (e) {
        if (errEl) { errEl.innerText = 'Lỗi kết nối máy chủ!'; errEl.style.color = '#ff6b6b'; errEl.style.display = 'block'; }
      }
    },

    renderGuestUI: function () {
      const headerElem = document.getElementById('kybien-header-profile');
      if (headerElem) {
        headerElem.innerHTML = `
          <div class="kybien-nav-auth" style="display: flex; align-items: center; gap: 6px; flex-wrap: wrap;">
            <input type="text" id="hdr-auth-u" placeholder="Tên kỳ thủ" style="background: #1e130a; border: 1px solid #5a3d22; color: #fff; padding: 5px 8px; border-radius: 5px; font-size: 0.78rem; width: 110px; outline: none;" onkeydown="if(event.key==='Enter')window.KybienAuth.handleLogin()"/>
            <input type="password" id="hdr-auth-p" placeholder="Mật khẩu" style="background: #1e130a; border: 1px solid #5a3d22; color: #fff; padding: 5px 8px; border-radius: 5px; font-size: 0.78rem; width: 100px; outline: none;" onkeydown="if(event.key==='Enter')window.KybienAuth.handleLogin()"/>
            <button type="button" onclick="window.KybienAuth.handleLogin()" style="background: linear-gradient(135deg, #a83a1f, #8b0000); color: #fff; border: 1px solid #f1c40f; padding: 5px 10px; border-radius: 5px; font-weight: bold; font-size: 0.78rem; cursor: pointer;">Đăng Nhập</button>
            <button type="button" onclick="window.KybienAuth.handleRegister()" style="background: linear-gradient(135deg, #27ae60, #1e8449); color: #fff; border: none; padding: 5px 9px; border-radius: 5px; font-weight: bold; font-size: 0.78rem; cursor: pointer;">Đăng Ký</button>
            <div id="hdr-auth-err" style="color: #ff6b6b; font-size: 0.72rem; font-weight: bold; width: 100%; display: none;"></div>
          </div>
        `;
      }

      const profileElem = document.getElementById('kybien-user-profile-section');
      if (profileElem) {
        profileElem.innerHTML = `
          <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #5a3d22; padding-bottom: 10px; margin-bottom: 14px;">
            <h3 style="color: #f1c40f; font-family: 'Noto Serif TC', serif; font-size: 1.1rem; margin: 0;">📜 HỒ SƠ HIỆP KHÁCH</h3>
            <span style="background: #4a3320; color: #a8947d; font-size: 0.75rem; padding: 3px 10px; border-radius: 6px; font-weight: bold; border: 1px solid #5a3d22;">Vô Danh Lữ Khách</span>
          </div>
          <div style="text-align: center; padding: 15px 10px;">
            <p style="color: #a8947d; font-size: 0.88rem; margin-bottom: 14px; line-height: 1.5;">
              Chư vị đang hành tẩu với danh xưng <strong>Vô Danh Lữ Khách</strong>.<br/>Đăng nhập ngay ở thanh trên để tích lũy Chiến Lực (ELO), thăng tiến Cảnh Giới &amp; lưu danh sử sách!
            </p>
          </div>
        `;
      }
    },

    renderLoadingUI: function () {
      const headerElem = document.getElementById('kybien-header-profile');
      if (headerElem) {
        headerElem.innerHTML = `<span style="font-size: 0.82rem; color: #a8947d;">⏳ Đang kiểm chứng danh xưng kỳ hữu...</span>`;
      }

      const profileElem = document.getElementById('kybien-user-profile-section');
      if (profileElem) {
        profileElem.innerHTML = `
          <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #5a3d22; padding-bottom: 10px; margin-bottom: 14px;">
            <h3 style="color: #f1c40f; font-family: 'Noto Serif TC', serif; font-size: 1.1rem; margin: 0;">📜 HỒ SƠ HIỆP KHÁCH</h3>
          </div>
          <div style="text-align: center; padding: 20px 10px; color: #a8947d; font-size: 0.88rem;">
            ⏳ Đang kiểm chứng danh xưng và nạp dữ liệu hồ sơ hiệp khách...
          </div>
        `;
      }
    },

    renderErrorUI: function (msg) {
      const headerElem = document.getElementById('kybien-header-profile');
      if (headerElem) {
        headerElem.innerHTML = `
          <div style="display: flex; align-items: center; gap: 8px;">
            <span style="font-size: 0.78rem; color: #ff6b6b;">⚠️ ${escapeHtml(msg)}</span>
            <button onclick="window.KybienAuth.fetchProfile()" style="background: #5a3d22; color: #fff; border: none; padding: 3px 8px; border-radius: 4px; cursor: pointer; font-size: 0.75rem;">Thử lại</button>
          </div>
        `;
      }

      const profileElem = document.getElementById('kybien-user-profile-section');
      if (profileElem) {
        profileElem.innerHTML = `
          <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #5a3d22; padding-bottom: 10px; margin-bottom: 14px;">
            <h3 style="color: #f1c40f; font-family: 'Noto Serif TC', serif; font-size: 1.1rem; margin: 0;">📜 HỒ SƠ HIỆP KHÁCH</h3>
          </div>
          <div style="text-align: center; padding: 15px 10px; color: #a8947d; font-size: 0.88rem;">
            <p style="color: #ff6b6b; margin-bottom: 10px;">⚠️ ${escapeHtml(msg)}</p>
            <button onclick="window.KybienAuth.fetchProfile()" style="background: #8b0000; color: #fff; border: 1px solid #a83a1f; padding: 6px 14px; border-radius: 6px; cursor: pointer; font-weight: bold; font-size: 0.82rem;">🔄 Nạp lại dữ liệu hồ sơ</button>
          </div>
        `;
      }
    },

    getExpTitle: function (level) {
      const lvl = Math.max(1, Math.floor(level));
      if (lvl <= 15) return 'Khởi Khai';
      if (lvl <= 30) return 'Đắc Thức';
      if (lvl <= 50) return 'Tri Ý';
      if (lvl <= 70) return 'Thông Biến';
      if (lvl <= 85) return 'Thần Cơ';
      if (lvl <= 99) return 'Hóa Cảnh';
      return 'Quy Chân';
    },

    getEloTitle: function (elo) {
      const rating = Number(elo) || 1200;
      if (rating < 1000) return 'Kỳ Đồng';
      if (rating <= 1199) return 'Kỳ Đồ';
      if (rating <= 1399) return 'Kỳ Hiệp';
      if (rating <= 1599) return 'Kỳ Tướng';
      if (rating <= 1799) return 'Kỳ Vương';
      if (rating <= 1999) return 'Kỳ Tông';
      if (rating <= 2199) return 'Kỳ Thánh';
      return 'Kỳ Thần';
    },

    getExpRequiredForNextLevel: function (level) {
      const lvl = Math.max(1, Math.floor(level));
      if (lvl >= 100) return 0;
      return 100 + (lvl - 1) * 35;
    },

    renderUserUI: function (user) {
      const level = Math.min(100, Math.max(1, user.level || 1));
      const elo = user.elo || 1200;
      const currentExp = Number(user.currentExp !== undefined ? user.currentExp : (user.exp || 0));
      const isMaxLevel = level >= 100;
      
      const reqExp = isMaxLevel ? 0 : this.getExpRequiredForNextLevel(level);
      const expPercent = isMaxLevel ? 100 : (reqExp > 0 ? Math.min(100, Math.max(0, Math.round((currentExp / reqExp) * 100))) : 0);

      const expTitle = this.getExpTitle(level);
      const eloTitle = this.getEloTitle(elo);
      const fullTitle = `[${expTitle}] ${eloTitle}`;

      const played = user.matches_played !== undefined ? user.matches_played : (user.matchesPlayed || 0);
      const won = user.matches_won !== undefined ? user.matches_won : (user.matchesWon || 0);
      const winRate = played > 0 ? Math.round((won / played) * 100) : 0;

      const safeUsername = escapeHtml(user.username);
      const safeFirstChar = escapeHtml((user.username || 'U')[0].toUpperCase());

      // 1. Header Profile Widget (Có Thanh EXP + Tiêu đề [Danh hiệu ELO] Danh hiệu Lv.)
      const headerElem = document.getElementById('kybien-header-profile');
      if (headerElem) {
        headerElem.innerHTML = `
          <div class="kybien-user-card" style="display: flex; align-items: center; gap: 10px; font-family: sans-serif;">
            <div class="avatar" style="width: 40px; height: 40px; border-radius: 50%; background: linear-gradient(135deg, #8b0000, #4a0000); border: 1.5px solid #f1c40f; color: #fff; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 1.15rem; flex-shrink: 0; box-shadow: 0 0 8px rgba(241,196,15,0.4);">
              ${safeFirstChar}
            </div>
            <div class="user-info" style="flex: 1; min-width: 150px;">
              <div style="font-weight: bold; font-size: 0.88rem; color: #f1c40f; display: flex; justify-content: space-between; align-items: center;">
                <span>${safeUsername} <span style="font-size: 0.8em; color: #e67e22;">(Lv.${level})</span></span>
                <a href="#" onclick="window.KybienAuth.logout(); return false;" style="color: #ff6b6b; font-size: 0.72rem; text-decoration: underline; margin-left: 6px;">Thoát</a>
              </div>
              <div style="font-size: 0.76rem; color: #e5b36a; font-weight: 600; margin-top: 1px;">${fullTitle}</div>
              <div style="font-size: 0.72rem; color: #a8947d; display: flex; justify-content: space-between; align-items: center; margin-top: 2px;">
                <span>Elo: <strong style="color: #fff;">${elo}</strong></span>
                <span style="font-family: monospace; color: #f1c40f; font-size: 0.7rem; font-weight: bold;">
                  ${isMaxLevel ? 'MAX' : `${currentExp}/${reqExp} EXP (${expPercent}%)`}
                </span>
              </div>
              <!-- Thanh EXP trong Header -->
              <div style="background: #140b05; border: 1px solid #5a3d22; height: 5px; border-radius: 3px; overflow: hidden; width: 100%; margin-top: 3px;">
                <div style="width: ${expPercent}%; height: 100%; background: ${isMaxLevel ? 'linear-gradient(90deg, #ff4757, #f1c40f)' : 'linear-gradient(90deg, #e67e22, #f1c40f)'}; transition: width 0.4s ease;"></div>
              </div>
            </div>
          </div>
        `;
      }

      // 2. Main Profile Card Section (Có Thanh EXP số thực + Danh hiệu dạng [Danh hiệu ELO] Danh hiệu Lv.)
      const profileElem = document.getElementById('kybien-user-profile-section');
      if (profileElem) {
        profileElem.innerHTML = `
          <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #5a3d22; padding-bottom: 10px; margin-bottom: 14px;">
            <h3 style="color: #f1c40f; font-family: 'Noto Serif TC', serif; font-size: 1.05rem; margin: 0;">
              📜 HỒ SƠ HIỆP KHÁCH: <span style="color: #fff;">${safeUsername}</span>
            </h3>
            <span style="background: linear-gradient(135deg, #8b0000, #500000); color: #f1c40f; font-size: 0.75rem; padding: 3px 10px; border-radius: 6px; font-weight: bold; border: 1px solid #a83a1f;">
              ${fullTitle}
            </span>
          </div>

          <div style="display: flex; gap: 14px; align-items: center;">
            <div style="width: 54px; height: 54px; border-radius: 50%; background: linear-gradient(135deg, #8b0000, #4a0000); border: 2px solid #f1c40f; color: #fff; font-size: 1.6rem; font-weight: bold; display: flex; align-items: center; justify-content: center; font-family: 'Noto Serif TC', serif; flex-shrink: 0; box-shadow: 0 0 10px rgba(241,196,15,0.35);">
              ${safeFirstChar}
            </div>

            <div style="flex: 1;">
              <div style="font-size: 0.9rem; margin-bottom: 4px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap;">
                <div>Cảnh giới: <strong style="color: #f1c40f;">${fullTitle}</strong> <span style="font-size: 0.8em; color: #e67e22;">(Cấp ${level})</span></div>
                <div>Chiến Lực: <strong style="color: #2ecc71;">${elo} ELO</strong></div>
              </div>

              <div style="font-size: 0.78rem; color: #a8947d; margin-bottom: 4px; display: flex; justify-content: space-between; align-items: center;">
                <span>Chiến tích: <strong style="color: #2ecc71;">${winRate}%</strong> thắng (${won}/${played} trận)</span>
                <span style="font-family: monospace; color: #f1c40f; font-weight: bold;">
                  ${isMaxLevel ? 'Cực Hạn (MAX)' : `${currentExp} / ${reqExp} EXP (${expPercent}%)`}
                </span>
              </div>

              <!-- Thanh EXP Hồ sơ Hiệp khách -->
              <div style="background: #140b05; border: 1px solid #5a3d22; height: 10px; border-radius: 5px; overflow: hidden; width: 100%; position: relative; box-shadow: inset 0 1px 3px rgba(0,0,0,0.8);">
                <div style="width: ${expPercent}%; height: 100%; background: ${isMaxLevel ? 'linear-gradient(90deg, #ff4757, #f1c40f)' : 'linear-gradient(90deg, #e67e22, #f1c40f)'}; transition: width 0.5s ease;"></div>
              </div>
            </div>
          </div>

          <div style="margin-top: 12px; display: flex; justify-content: space-between; align-items: center;">
            <span style="font-size: 0.75rem; color: #888;">Danh xưng: <strong style="color: #e5b36a;">${fullTitle}</strong></span>
            <a href="/p/arena.html" style="font-size: 0.82rem; color: #2ecc71; font-weight: bold; text-decoration: underline;">Tiến vào Sàn Đấu khiêu chiến ➔</a>
          </div>
        `;
      }
    },

    fetchProfile: async function () {
      const token = this.getToken();
      if (!token) {
        this.renderGuestUI();
        return;
      }

      if (this.cachedUser) {
        this.renderUserUI(this.cachedUser);
      } else {
        this.renderLoadingUI();
      }

      if (this.isFetching) return;
      this.isFetching = true;

      try {
        const res = await fetch(`${SERVER_URL}/api/auth/me`, {
          headers: { Authorization: `Bearer ${token}` },
        });

        if (res.ok) {
          const user = await res.json();
          this.cachedUser = user;
          this.renderUserUI(user);
          if (typeof window.checkAuthUI === 'function') window.checkAuthUI();
        } else if (res.status === 401 || res.status === 403) {
          console.warn('[Kỷ Biến Auth] Token không hợp lệ hoặc đã hết hạn (401/403).');
          this.clearToken();
        } else {
          console.warn('[Kỷ Biến Auth] Máy chủ phản hồi lỗi tạm thời:', res.status);
          this.renderErrorUI('Không thể nạp hồ sơ từ máy chủ.');
        }
      } catch (e) {
        console.warn('[Kỷ Biến Auth] Lỗi kết nối tới máy chủ Render:', e);
        this.renderErrorUI('Đang chờ kết nối tới máy chủ Render...');
      } finally {
        this.isFetching = false;
      }
    }
  };

  // FR-02: Header Profile Widget
  function initHeaderProfileWidget() {
    waitForElem('kybien-header-profile', () => {
      window.KybienAuth.fetchProfile();
    });
  }

  // Inter-tab & page visibility listeners
  window.addEventListener('storage', (e) => {
    if (e.key === 'kybien_jwt_token') {
      window.KybienAuth.cachedUser = null;
      window.KybienAuth.fetchProfile();
    }
  });

  window.addEventListener('pageshow', () => {
    window.KybienAuth.fetchProfile();
  });

  // Window global viewer controller cho các bài đăng Blogger (Interactive Xiangqi Board)
  window.KybienViewer = {
    _inited: false,
    currentStep: 0,
    moves: [],
    variant: 'kb',
    canvas: null,
    ctx: null,

    pieceNames: {
      k: { r: '帥', b: '將' },
      a: { r: '仕', b: '士' },
      b: { r: '相', b: '象' },
      n: { r: '馬', b: '馬' },
      r: { r: '車', b: '車' },
      c: { r: '砲', b: '砲' },
      p: { r: '兵', b: '卒' }
    },

    spellIcons: {
      CANNON_2: { icon: '🔥', name: 'Bích Lịch Hỏa (Nổ Lan 4 Ô)', color: '#ff4757' },
      KNIGHT_2: { icon: '☠️', name: 'Tuyệt Mệnh Cổ (Đồng Thọ Thương Tử)', color: '#a55eea' },
      KING_4: { icon: '🌀', name: 'Càn Khôn Di Vị (Hoán Đổi Tướng)', color: '#f1c40f' },
      ROOK_1: { icon: '⚡', name: 'Bão Thần (Càn Quét Hàng Dọc)', color: '#2ecc71' }
    },

    init: function () {
      if (this._inited) return;
      const viewerElem = document.getElementById('kybien-board-viewer');
      if (!viewerElem) return;
      this._inited = true;

      try {
        this.variant = viewerElem.getAttribute('data-variant') || 'kb';
        const rawMoves = viewerElem.getAttribute('data-moves');
        if (rawMoves) {
          this.moves = JSON.parse(rawMoves);
        }
        console.log('[Kỳ Biến Replay Viewer] Đã tải ván cờ (Variant:', this.variant, ') với', this.moves.length, 'nước đi.');
        
        const canvasContainer = document.getElementById('chess-board-canvas');
        if (canvasContainer) {
          canvasContainer.innerHTML = `
            <canvas id="kybien-replay-canvas" width="500" height="550" style="width:100%; max-width:500px; height:auto; background:#f0d9b5; border-radius:8px; box-shadow:0 4px 15px rgba(0,0,0,0.5); display:block; margin:0 auto;"></canvas>
          `;
          this.canvas = document.getElementById('kybien-replay-canvas');
          if (this.canvas) this.ctx = this.canvas.getContext('2d');
        }

        let stepInfo = document.getElementById('kybien-step-info');
        if (!stepInfo && viewerElem) {
          stepInfo = document.createElement('div');
          stepInfo.id = 'kybien-step-info';
          stepInfo.style.cssText = 'text-align:center; margin-top:12px; font-weight:bold; color:#f1c40f; font-size:0.95rem; font-family:sans-serif; background:rgba(0,0,0,0.5); padding:8px 12px; border-radius:6px; border:1px solid #5a3d22; min-height:42px; display:flex; align-items:center; justify-content:center;';
          viewerElem.appendChild(stepInfo);
        }
        this.render();
      } catch (e) {
        console.error('[Kỳ Biến Viewer Error]', e);
      }
    },

    getInitialBoard: function() {
      const board = Array(10).fill(null).map(() => Array(9).fill(null));

      // CỜ TƯỚNG THƯỜNG HOẶC CỜ KỲ BIẾN
      if (this.variant === 'n' || this.variant === 'kb') {
        const bk = ['r','n','b','a','k','a','b','n','r'];
        for (let c = 0; c < 9; c++) {
          board[0][c] = { t: bk[c], col: 'b', hd: false };
          board[9][c] = { t: bk[c], col: 'r', hd: false };
        }
        board[2][1] = { t: 'c', col: 'b', hd: false }; board[2][7] = { t: 'c', col: 'b', hd: false };
        board[7][1] = { t: 'c', col: 'r', hd: false }; board[7][7] = { t: 'c', col: 'r', hd: false };
        for (let c = 0; c < 9; c += 2) {
          board[3][c] = { t: 'p', col: 'b', hd: false };
          board[6][c] = { t: 'p', col: 'r', hd: false };
        }
      } else {
        // CỜ ÚP TRUYỀN THỐNG (t) HOẶC GIÁN ĐIỆP (g): Các quân ngoài Tướng mặc định úp (hd: true)
        board[0][4] = { t: 'k', col: 'b', hd: false };
        board[9][4] = { t: 'k', col: 'r', hd: false };
        const upPositions = [
          [0,0],[0,1],[0,2],[0,3],[0,5],[0,6],[0,7],[0,8],
          [2,1],[2,7],[3,0],[3,2],[3,4],[3,6],[3,8],
          [9,0],[9,1],[9,2],[9,3],[9,5],[9,6],[9,7],[9,8],
          [7,1],[7,7],[6,0],[6,2],[6,4],[6,6],[6,8]
        ];
        upPositions.forEach(([r, c]) => {
          const col = r < 5 ? 'b' : 'r';
          board[r][c] = { t: '?', col, hd: true };
        });
      }

      return board;
    },

    computeBoardAtStep: function(step) {
      const board = this.getInitialBoard();
      let lastMove = null;
      let moveNote = '';
      let activeSpell = null;

      for (let i = 0; i < step && i < this.moves.length; i++) {
        const mStr = this.moves[i];
        if (!mStr) continue;

        // XỬ LÝ SỰ KIỆN BÍ PHÁP (CARD:spellId->r,c)
        if (mStr.startsWith('CARD:')) {
          const content = mStr.replace('CARD:', '');
          const cardParts = content.split('->');
          const spellId = cardParts[0];
          const targetStr = cardParts[1];

          const spellInfo = this.spellIcons[spellId] || { icon: '✨', name: spellId, color: '#f1c40f' };
          moveNote = `✨ Thi triển Bí Pháp [${spellInfo.name}]!`;
          activeSpell = { spellId, spellInfo, targetStr };

          if (targetStr && targetStr.includes(',')) {
            const [tr, tc] = targetStr.split(',').map(Number);
            if (board[tr] && board[tr][tc]) {
              board[tr][tc].spell = spellInfo;
            }
          }
          continue;
        }

        // XỬ LÝ SỰ KIỆN LẬT QUÂN CỜ ÚP (FLIP:r,c->realType)
        if (mStr.startsWith('FLIP:')) {
          const flipParts = mStr.replace('FLIP:', '').split('->');
          if (flipParts.length === 2) {
            const [fr, fc] = flipParts[0].split(',').map(Number);
            const realType = flipParts[1];
            if (board[fr] && board[fr][fc]) {
              board[fr][fc].hd = false;
              board[fr][fc].t = realType;
              const sideStr = board[fr][fc].col === 'r' ? '🔴 Đỏ' : '⚫ Đen';
              const realName = this.pieceNames[realType]?.[board[fr][fc].col] || realType;
              moveNote = `🕵️ ${sideStr} Lật ngửa quân Úp thành ${realName}!`;
            }
          }
          continue;
        }

        // XỬ LÝ SỰ KIỆN KÍCH ĐỘC TỰU TỬ (POISON_KILL:r,c)
        if (mStr.startsWith('POISON_KILL:')) {
          const posStr = mStr.replace('POISON_KILL:', '');
          const [pr, pc] = posStr.split(',').map(Number);
          if (board[pr] && board[pr][pc]) {
            const victim = board[pr][pc];
            board[pr][pc] = null; // Xóa quân cờ vừa ăn Mã độc khỏi bàn cờ
            const sideStr = victim.col === 'r' ? '🔴 Đỏ' : '⚫ Đen';
            const vName = victim.hd ? 'Quân Úp' : ((this.pieceNames[victim.t] && this.pieceNames[victim.t][victim.col]) || victim.t);
            moveNote = `☠️ [Tuyệt Mệnh Cổ] Độc phát tác! ${sideStr} ${vName} tại (${pr},${pc}) đồng thọ tử bị loại khỏi bàn cờ!`;
          }
          continue;
        }

        // XỬ LÝ NƯỚC ĐI TỌA ĐỘ CHUẨN (r1,c1-r2,c2)
        const parts = mStr.split('-');
        if (parts.length === 2) {
          const from = parts[0].split(',').map(Number);
          const to = parts[1].split(',').map(Number);
          if (from.length === 2 && to.length === 2 && !isNaN(from[0]) && !isNaN(from[1]) && !isNaN(to[0]) && !isNaN(to[1])) {
            const p = board[from[0]][from[1]];
            const cap = board[to[0]][to[1]];
            board[from[0]][from[1]] = null;
            board[to[0]][to[1]] = p;

            if (p) {
              // Tự động ngửa quân cờ úp nếu đi nước đầu
              if (p.hd) p.hd = false;

              const sideStr = p.col === 'r' ? '🔴 Đỏ' : '⚫ Đen';
              const pName = p.hd ? 'Quân Úp' : ((this.pieceNames[p.t] && this.pieceNames[p.t][p.col]) || p.t);
              const capStr = cap ? ` ⚔️ ăn quân ${cap.hd ? 'Úp' : (this.pieceNames[cap.t]?.[cap.col] || cap.t)}` : ' di chuyển';
              moveNote = `${sideStr}: ${pName} (${from[0]},${from[1]}) ➔ (${to[0]},${to[1]})${capStr}`;
            }

            lastMove = { from, to, piece: p, captured: cap, note: moveNote };
          }
        }
      }
      return { board, lastMove, note: moveNote, activeSpell };
    },

    render: function () {
      if (!this.ctx || !this.canvas) return;
      const ctx = this.ctx;
      const W = 500;
      const H = 550;
      this.canvas.width = W;
      this.canvas.height = H;

      const OX = 45, OY = 45, CS = 51;

      const { board, lastMove, note, activeSpell } = this.computeBoardAtStep(this.currentStep);

      // 1. Nền bàn cờ màu gỗ ấm
      ctx.fillStyle = '#f0d9b5';
      ctx.fillRect(0, 0, W, H);

      // 2. Đường viền khung ngoài
      ctx.strokeStyle = '#5a3d22';
      ctx.lineWidth = 4;
      ctx.strokeRect(10, 10, W - 20, H - 20);

      // 3. Kẻ lưới bàn cờ (Grid lines)
      ctx.lineWidth = 1.8;
      ctx.strokeStyle = '#5a3d22';

      // Ngang (10 hàng)
      for (let r = 0; r < 10; r++) {
        ctx.beginPath();
        ctx.moveTo(OX, OY + r * CS);
        ctx.lineTo(OX + 8 * CS, OY + r * CS);
        ctx.stroke();
      }

      // Dọc (9 cột)
      for (let c = 0; c < 9; c++) {
        ctx.beginPath();
        ctx.moveTo(OX + c * CS, OY);
        ctx.lineTo(OX + c * CS, OY + 4 * CS);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(OX + c * CS, OY + 5 * CS);
        ctx.lineTo(OX + c * CS, OY + 9 * CS);
        ctx.stroke();
      }

      // Đường biên Sông
      ctx.beginPath();
      ctx.moveTo(OX, OY + 4 * CS); ctx.lineTo(OX, OY + 5 * CS);
      ctx.moveTo(OX + 8 * CS, OY + 4 * CS); ctx.lineTo(OX + 8 * CS, OY + 5 * CS);
      ctx.stroke();

      // Chữ Sông (楚 河 - 漢 界)
      ctx.fillStyle = '#8b4513';
      ctx.font = 'bold 22px serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('楚 河', OX + 2 * CS, OY + 4.5 * CS);
      ctx.fillText('漢 界', OX + 6 * CS, OY + 4.5 * CS);

      // Cung Tướng (Palaces)
      ctx.beginPath();
      ctx.moveTo(OX + 3 * CS, OY); ctx.lineTo(OX + 5 * CS, OY + 2 * CS);
      ctx.moveTo(OX + 5 * CS, OY); ctx.lineTo(OX + 3 * CS, OY + 2 * CS);
      ctx.moveTo(OX + 3 * CS, OY + 7 * CS); ctx.lineTo(OX + 5 * CS, OY + 9 * CS);
      ctx.moveTo(OX + 5 * CS, OY + 7 * CS); ctx.lineTo(OX + 3 * CS, OY + 9 * CS);
      ctx.stroke();

      // Highlight Nước đi vừa đi
      if (lastMove) {
        ctx.fillStyle = 'rgba(241, 196, 15, 0.45)';
        ctx.fillRect(OX + lastMove.from[1] * CS - 20, OY + lastMove.from[0] * CS - 20, 40, 40);
        ctx.fillStyle = 'rgba(46, 204, 113, 0.55)';
        ctx.fillRect(OX + lastMove.to[1] * CS - 20, OY + lastMove.to[0] * CS - 20, 40, 40);
      }

      // 4. Vẽ Quân Cờ (Pieces) Hỗ trợ cả 4 Thể loại (Thường, Úp, Gián Điệp, Bí Pháp)
      for (let r = 0; r < 10; r++) {
        for (let c = 0; c < 9; c++) {
          const p = board[r][c];
          if (!p) continue;
          const x = OX + c * CS;
          const y = OY + r * CS;
          const rad = 20;

          // Vòng Hào Quang Hiệu Ứng Bí Pháp (Glow Aura Ring for Spells)
          if (p.spell) {
            ctx.beginPath();
            ctx.arc(x, y, rad + 5, 0, Math.PI * 2);
            ctx.fillStyle = p.spell.color || '#f1c40f';
            ctx.globalAlpha = 0.4;
            ctx.fill();
            ctx.globalAlpha = 1.0;
          }

          // CỜ ÚP (FACE-DOWN HIDDEN PIECES)
          if (p.hd) {
            ctx.beginPath();
            ctx.arc(x, y, rad, 0, Math.PI * 2);
            ctx.fillStyle = '#3a2416';
            ctx.fill();
            ctx.lineWidth = 2.5;
            ctx.strokeStyle = '#d4af37';
            ctx.stroke();

            // Vòng chỉ trong quân úp
            ctx.beginPath();
            ctx.arc(x, y, rad - 4, 0, Math.PI * 2);
            ctx.lineWidth = 1;
            ctx.strokeStyle = '#8b5a2b';
            ctx.stroke();

            // Icon Nắp Úp 🎴
            ctx.fillStyle = '#d4af37';
            ctx.font = '16px serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('🎴', x, y + 1);
          } else {
            // QUÂN CỜ NGỬA CHUẨN
            ctx.beginPath();
            ctx.arc(x, y, rad, 0, Math.PI * 2);
            ctx.fillStyle = '#fffdfa';
            ctx.fill();
            ctx.lineWidth = 2;
            ctx.strokeStyle = p.col === 'r' ? '#c62828' : '#222222';
            ctx.stroke();

            // Vòng chỉ trong
            ctx.beginPath();
            ctx.arc(x, y, rad - 3, 0, Math.PI * 2);
            ctx.lineWidth = 1;
            ctx.stroke();

            // Chữ Quân Cờ Hán Tự
            const char = (this.pieceNames[p.t] && this.pieceNames[p.t][p.col]) || p.t;
            ctx.fillStyle = p.col === 'r' ? '#c62828' : '#222222';
            ctx.font = 'bold 20px serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(char, x, y + 1);
          }

          // Badge Icon Bí Pháp trên đầu quân cờ (nếu có)
          if (p.spell) {
            ctx.font = '14px serif';
            ctx.fillText(p.spell.icon, x + 12, y - 12);
          }
        }
      }

      // 5. Cập nhật Thanh Tóm tắt Nước đi bên dưới
      const stepInfo = document.getElementById('kybien-step-info');
      if (stepInfo) {
        if (this.currentStep === 0) {
          stepInfo.innerHTML = `🔴 <strong>Nước 0 / ${this.moves.length}</strong>: Khai cuộc trận đấu (${this.variant === 'kb' ? 'Cờ Kỳ Biến' : this.variant === 't' ? 'Cờ Úp Truyền Thống' : this.variant === 'g' ? 'Cờ Úp Gián Điệp' : 'Cờ Tiêu Chuẩn'})`;
        } else {
          stepInfo.innerHTML = `<strong>Nước ${this.currentStep} / ${this.moves.length}</strong>: ${note || 'Di chuyển quân'}`;
        }
      }
    },

    nextMove: function () {
      if (this.currentStep < this.moves.length) {
        this.currentStep++;
        this.render();
      }
    },
    prevMove: function () {
      if (this.currentStep > 0) {
        this.currentStep--;
        this.render();
      }
    },
    firstMove: function () {
      this.currentStep = 0;
      this.render();
    },
    lastMove: function () {
      this.currentStep = this.moves.length;
      this.render();
    },
  };

  // KHỐI HỒ SƠ CÁ NHÂN KỲ THỦ TRANG CHỦ
  function initUserProfileSection() {
    waitForElem('kybien-user-profile-section', () => {
      window.KybienAuth.fetchProfile();
    });
  }

  // KHỐI BẢNG XẾP HẠNG TOP ELO TRANG CHỦ
  function initTopEloLeaderboard() {
    waitForElem('kybien-top-elo-section', async (container) => {
      container.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #5a3d22; padding-bottom: 10px; margin-bottom: 14px;">
          <h3 style="color: #f1c40f; font-family: 'Noto Serif TC', serif; font-size: 1.15rem;">🏆 BẢNG VÀNG MINH CHỦ KỲ ĐẠO</h3>
          <span style="font-size: 0.78rem; color: #a8947d;">Tuyệt Đỉnh Cao Thủ</span>
        </div>
        <div id="kybien-elo-list" style="display: flex; flex-direction: column; gap: 8px;">
          <div style="text-align: center; color: #a8947d; font-size: 0.85rem; padding: 15px;">Đang thỉnh bảng vàng minh chủ...</div>
        </div>
      `;

      try {
        const res = await fetch(`${SERVER_URL}/api/auth/leaderboard`);
        if (!res.ok) throw new Error('API Error');
        const list = await res.json();
        const listContainer = document.getElementById('kybien-elo-list');
        if (!listContainer) return;

        if (!list || !list.length) {
          listContainer.innerHTML = '<div style="text-align:center; color:#a8947d; font-size:0.85rem;">Chưa có danh tính trên bảng vàng...</div>';
          return;
        }

        const rankIcons = ['🥇', '🥈', '🥉'];
        listContainer.innerHTML = list.slice(0, 5).map((u, i) => {
          const rankStr = rankIcons[i] || `#${i + 1}`;
          const played = u.matchesPlayed !== undefined ? u.matchesPlayed : (u.matches_played !== undefined ? u.matches_played : 0);
          const won = u.matchesWon !== undefined ? u.matchesWon : (u.matches_won !== undefined ? u.matches_won : 0);
          const winRate = u.winRate !== undefined ? u.winRate : (played > 0 ? Math.round((won / played) * 100) : 0);

          const safeName = escapeHtml(u.username);
          const getEloT = (window.KybienAuth && window.KybienAuth.getEloTitle) ? window.KybienAuth.getEloTitle : (r => (r<1000?'Kỳ Đồng':r<=1199?'Kỳ Đồ':r<=1399?'Kỳ Hiệp':r<=1599?'Kỳ Tướng':r<=1799?'Kỳ Vương':r<=1999?'Kỳ Tông':r<=2199?'Kỳ Thánh':'Kỳ Thần'));
          const getExpT = (window.KybienAuth && window.KybienAuth.getExpTitle) ? window.KybienAuth.getExpTitle : (l => (l<=15?'Khởi Khai':l<=30?'Đắc Thức':l<=50?'Tri Ý':l<=70?'Thông Biến':l<=85?'Thần Cơ':l<=99?'Hóa Cảnh':'Quy Chân'));
          
          const eloTitle = getEloT(u.elo);
          const expTitle = getExpT(u.level || 1);
          const fullTitle = `[${eloTitle}] ${expTitle}`;

          return `
            <div style="display: flex; justify-content: space-between; align-items: center; background: rgba(34,21,12,0.7); border: 1px solid #5a3d22; padding: 8px 12px; border-radius: 8px;">
              <div style="display: flex; align-items: center; gap: 10px;">
                <span style="font-size: 1.1rem; width: 25px; text-align: center;">${rankStr}</span>
                <div>
                  <div style="display: flex; align-items: center; gap: 6px;">
                    <b style="color: #e8dcc6; font-size: 0.9rem;">${safeName}</b>
                    <span style="font-size: 0.75rem; color: #e67e22;">(Lv.${u.level || 1})</span>
                  </div>
                  <div style="font-size: 0.74rem; color: #f1c40f; font-weight: 600; margin-top: 2px;">
                    ${fullTitle}
                  </div>
                </div>
              </div>
              <div style="text-align: right;">
                <strong style="color: #f1c40f; font-size: 0.95rem;">${u.elo || 1200} ELO</strong>
                <div style="font-size: 0.72rem; color: #2ecc71;">${winRate}% thắng (${won}/${played})</div>
              </div>
            </div>
          `;
        }).join('');
      } catch (e) {
        const listContainer = document.getElementById('kybien-elo-list');
        if (listContainer) listContainer.innerHTML = '<div style="text-align:center; color:#a8947d; font-size:0.85rem;">Không thể nạp dữ liệu xếp hạng. <button onclick="initTopEloLeaderboard()" style="background:#5a3d22;color:#fff;border:none;padding:2px 8px;border-radius:4px;cursor:pointer;font-size:0.75rem;margin-left:5px;">Tải lại</button></div>';
      }
    });
  }

  // KHỐI KỲ ĐÀI LUẬN KIẾM TRANG CHỦ
  function initLiveRoomsWidget() {
    waitForElem('kybien-live-rooms-section', (container) => {
      const variantNames = { kb: 'Cờ Bí Pháp', t: 'Cờ Úp', g: 'Gián Điệp', n: 'Truyền Thống' };

      container.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #5a3d22; padding-bottom: 10px; margin-bottom: 14px;">
          <h3 style="color: #f1c40f; font-family: 'Noto Serif TC', serif; font-size: 1.15rem;">⚔️ KỲ ĐÀI LUẬN KIẾM</h3>
          <a href="/p/arena.html" style="font-size: 0.8rem; color: #2ecc71; font-weight: bold;">+ Lập Kỳ Đài</a>
        </div>
        <div id="kybien-rooms-list" style="display: flex; flex-direction: column; gap: 8px;">
          <div style="text-align: center; color: #a8947d; font-size: 0.85rem; padding: 12px; background: rgba(34,21,12,0.4); border-radius: 8px; border: 1px dashed #5a3d22;">
            Đang kết nối sảnh luận kiếm...
          </div>
        </div>
      `;

      const renderRooms = (rooms) => {
        const listContainer = document.getElementById('kybien-rooms-list');
        if (!listContainer) return;
        if (!rooms || !rooms.length) {
          listContainer.innerHTML = `
            <div style="text-align: center; color: #a8947d; font-size: 0.85rem; padding: 12px; background: rgba(34,21,12,0.4); border-radius: 8px; border: 1px dashed #5a3d22;">
              Chưa có kỳ đài công khai nào đang chờ nghênh chiến. <br/>
              <a href="/p/arena.html" style="color: #f1c40f; font-weight: bold; text-decoration: underline; margin-top: 4px; display: inline-block;">Lập kỳ đài ngay để chờ kỳ hữu nghênh chiến! ➔</a>
            </div>
          `;
          return;
        }
        listContainer.innerHTML = rooms.slice(0, 4).map(r => {
          const safeRoomCode = escapeHtml(r.roomCode);
          const safeHostName = escapeHtml(r.hostName);
          return `
          <div style="display: flex; justify-content: space-between; align-items: center; background: rgba(34,21,12,0.7); border: 1px solid #5a3d22; padding: 8px 12px; border-radius: 8px;">
            <div>
              <b style="color: #f1c40f; font-size: 0.88rem;">${safeRoomCode}</b>
              <span style="font-size: 0.75rem; color: #2ecc71; margin-left: 6px;">[${variantNames[r.variant] || 'Cờ Tướng'}]</span>
              <div style="font-size: 0.78rem; color: #a8947d;">Đài chủ: ${safeHostName}</div>
            </div>
            <a href="/p/arena.html" style="background: #8b0000; color: #fff; font-size: 0.8rem; padding: 5px 12px; border-radius: 6px; font-weight: bold; border: 1px solid #a83a1f;">Nghênh Chiến ➔</a>
          </div>
        `;
        }).join('');
      };

      // 1. Lấy dữ liệu nhanh qua HTTP REST API
      const fetchRoomsViaHttp = async () => {
        try {
          const res = await fetch(`${SERVER_URL}/api/match/public-rooms`);
          if (res.ok) {
            const rooms = await res.json();
            renderRooms(rooms);
          }
        } catch (e) {}
      };

      fetchRoomsViaHttp();

      // 2. Lắng nghe real-time qua Socket.io nếu có
      if (typeof io !== 'undefined') {
        try {
          const token = localStorage.getItem('kybien_jwt_token') || '';
          const socket = io(SERVER_URL, { auth: { token } });
          socket.on('connect', () => socket.emit('get_public_rooms'));
          socket.on('public_rooms_list', (rooms) => renderRooms(rooms));
          socket.on('match_found', () => {
            if (window.location.pathname.indexOf('/p/arena.html') === -1) {
              alert('⚔️ Đã có kỳ hữu tiếp chiến trên kỳ đài! Đang chuyển vào Sàn Đấu...');
              window.location.href = '/p/arena.html';
            }
          });
        } catch (e) {}
      }

      // 3. Heartbeat polling 10 giây/lần
      setInterval(fetchRoomsViaHttp, 10000);
    });
  }

  // Tự động khởi tạo Replay Viewer nếu bài viết có bàn cờ
  if (document.readyState === 'complete') {
    window.KybienViewer.init();
  } else {
    window.addEventListener('load', () => window.KybienViewer.init());
  }
})();
